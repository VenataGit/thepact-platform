/* The Pact Tools — функция „Важно за всички".
 *
 * Закачен коментар, който виждат ВСИЧКИ с разширението: малко прозорче в ъгъла,
 * което се мести по екрана и се разгъва само когато трябва. Свито е една лентичка
 * („📢 Важно"), за да не пречи — както прозорчето за времето.
 *
 * Къде живее: същият канал на екипа, който ползва „кой редактира" (Firebase REST,
 * без SDK). Затова работи веднага за всеки с разширението, без вход и без токен.
 * Няма бележки → няма прозорче. Така никой не гледа празна кутия.
 */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__notesLoaded) return;
  PT.__notesLoaded = true;

  const MAX_NOTES = 10;
  const MAX_TEXT = 1200;
  const REFRESH_MS = 60000;
  const POS_KEY = 'ptnote:pos';
  const OPEN_KEY = 'ptnote:open';

  let notes = {};       /* id -> запис */
  let building = false;

  /* ---------- дребни помощници ---------- */

  const clean = (s, max) => String(s === undefined || s === null ? '' : s)
    .replace(/\s+/g, ' ').trim().slice(0, max || MAX_TEXT);

  const readJSON = (k) => {
    try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; }
  };
  const writeJSON = (k, v) => {
    try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ }
  };

  function when(ts) {
    const mins = Math.floor((Date.now() - Number(ts || 0)) / 60000);
    if (!ts || mins < 0) return '';
    if (mins < 1) return 'току-що';
    if (mins < 60) return 'преди ' + mins + ' мин';
    const h = Math.floor(mins / 60);
    if (h < 24) return 'преди ' + h + ' ч';
    const d = Math.floor(h / 24);
    return d === 1 ? 'вчера' : 'преди ' + d + ' дни';
  }

  const notesUrl = (id) => PT.dbRoot + '/notices' + (id ? '/' + encodeURIComponent(id) : '') + '.json';

  /* ---------- за коя задача се отнася бележката ----------
     Закаченото важи САМО за задачата, в която е сложено: иначе човек, който рови
     из съвсем друго нещо, гледа чужда бележка и тя губи смисъла си на акцент. */

  function ridOf(any) {
    let p = String(any || '');
    try { p = new URL(p, location.origin).pathname; } catch (e) { /* вече е път */ }
    const m = p.match(/\/buckets\/(\d+)\/((?:[a-z_]+\/)*[a-z_]+)\/(\d+)(?:\/edit)?$/);
    return m ? m[3] : '';
  }

  const pageRid = () => ridOf(location.pathname);

  /* Бележките отпреди тази промяна нямат записан rid — вади се от линка, който
     и без това пазим. Затова нищо не се губи и нищо не трябва да се мигрира. */
  const noteRid = (n) => String((n && n.rid) || '') || ridOf(n && n.url);

  /* ---------- четене и писане в канала ---------- */

  function load() {
    if (!PT.dbRoot) return Promise.resolve();
    return fetch(notesUrl(''))
      .then((r) => (r.ok ? r.text() : undefined))
      .then((txt) => {
        if (txt === undefined) return;
        let data = null;
        try { data = JSON.parse(txt); } catch (e) { return; }
        notes = (data && typeof data === 'object') ? data : {};
        render();
      })
      .catch(() => {});
  }

  function publish(note) {
    if (!PT.dbRoot) return;
    const id = 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    notes[id] = note;
    render();
    fetch(notesUrl(id) + '?print=silent', { method: 'PUT', body: JSON.stringify(note) })
      .then(() => load())
      .catch(() => {});
  }

  function remove(id) {
    if (!PT.dbRoot || !id) return;
    delete notes[id];
    render();
    fetch(notesUrl(id), { method: 'DELETE' }).then(() => load()).catch(() => {});
  }

  /* ---------- бутонът „за всички" върху коментарите ---------- */

  const COMMENT_SELECTORS = [
    'article[data-recording-id]',
    'article[id^="recording_"]',
    'article[id^="comment_"]',
    '.thread-entry'
  ];

  function commentText(el) {
    /* без нашите собствени бутони вътре в текста */
    const clone = el.cloneNode(true);
    clone.querySelectorAll('button, .bcpin-btn, .bcpin-compose-bar, .ptnote-btn').forEach((n) => n.remove());
    return clean(clone.textContent, MAX_TEXT);
  }

  function authorOf(el) {
    for (const s of ['[class*="author"] a', '[class*="author"]', 'a[href*="/people/"]', 'header strong']) {
      try {
        const n = el.querySelector(s);
        const t = clean(n && n.textContent, 60);
        if (t.length >= 2) return t;
      } catch (e) { /* ignore */ }
    }
    return '';
  }

  function injectButtons() {
    if (!document.body || !PT.dbRoot) return;
    const seen = new Set();
    for (const sel of COMMENT_SELECTORS) {
      let nodes;
      try { nodes = document.querySelectorAll(sel); } catch (e) { continue; }
      for (const el of nodes) {
        if (seen.has(el) || el.closest('#pt-layer, .bcpin-panel')) continue;
        seen.add(el);
        if (el.querySelector(':scope > .ptnote-btn')) continue;
        if (clean(el.textContent).length < 8) continue;
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'ptnote-btn';
        b.title = 'Покажи това на всички от екипа като важна информация';
        b.setAttribute('aria-label', b.title);
        b.textContent = '📢';
        if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
        el.appendChild(b);
      }
    }
  }

  function shareComment(el) {
    const text = commentText(el);
    if (!text) return;
    const author = authorOf(el);
    publish({
      title: 'Важна информация',
      text: text,
      from: author,
      url: location.href,
      rid: pageRid(),
      by: PT.myName ? PT.myName() : '',
      pid: PT.pid || '',
      at: Date.now()
    });
    open(true);
  }

  /* ---------- прозорчето ---------- */

  const host = () => PT.sub('pt-note', 'ptnote');

  const isOpen = () => readJSON(OPEN_KEY) === true;
  function open(v) {
    writeJSON(OPEN_KEY, !!v);
    render();
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  /* показваме само закаченото за ТАЗИ задача (виж noteRid по-горе) */
  function list() {
    const here = pageRid();
    if (!here) return [];
    return Object.keys(notes)
      .map((id) => Object.assign({ id: id }, notes[id]))
      .filter((n) => n && typeof n === 'object' && n.text && noteRid(n) === here)
      .sort((a, b) => Number(b.at || 0) - Number(a.at || 0))
      .slice(0, MAX_NOTES);
  }

  function place(box) {
    const pos = readJSON(POS_KEY);
    /* по подразбиране долу вляво — прозорчето на таймера стои вдясно */
    const left = pos && Number.isFinite(pos.x) ? pos.x : 20;
    const top = pos && Number.isFinite(pos.y) ? pos.y : Math.max(20, window.innerHeight - 120);
    const w = box.offsetWidth || 260;
    box.style.left = Math.max(8, Math.min(left, window.innerWidth - Math.min(w, window.innerWidth - 16))) + 'px';
    box.style.top = Math.max(8, Math.min(top, window.innerHeight - 60)) + 'px';
  }

  function drag(box, handle) {
    handle.addEventListener('mousedown', (e) => {
      if (e.button !== 0 || (e.target.closest && e.target.closest('button'))) return;
      const r = box.getBoundingClientRect();
      const offX = e.clientX - r.left;
      const offY = e.clientY - r.top;
      let moved = false;
      const onMove = (ev) => {
        moved = true;
        box.style.left = Math.max(8, Math.min(ev.clientX - offX, window.innerWidth - 60)) + 'px';
        box.style.top = Math.max(8, Math.min(ev.clientY - offY, window.innerHeight - 40)) + 'px';
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        if (!moved) return;
        /* пазим това, което сме задали, а не измерено — без излишно четене на
           подредбата и без изненади, ако страницата има свои трансформации */
        writeJSON(POS_KEY, {
          x: Math.round(parseFloat(box.style.left) || 0),
          y: Math.round(parseFloat(box.style.top) || 0)
        });
        box.__ptDragged = Date.now();
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  function render() {
    if (building) return;
    building = true;
    try {
      const items = list();
      const box = document.getElementById('pt-note');

      /* няма бележки → няма прозорче */
      if (!items.length) {
        if (box) box.remove();
        return;
      }

      const card = host();
      card.innerHTML = '';
      card.classList.toggle('ptnote--open', isOpen());

      const head = el('div', 'ptnote__head');

      /* Ясна дръжка за местене. Дотук цялата лентичка беше бутон „разгъни", а за
         влачене оставаше само процепът до ✕ — не се хващаше. */
      const grip = el('span', 'ptnote__grip', '⠿');
      grip.title = 'Влачи, за да преместиш прозорчето';
      head.appendChild(grip);

      const pill = el('button', 'ptnote__pill');
      pill.type = 'button';
      pill.textContent = '📢 Важно' + (items.length > 1 ? ' (' + items.length + ')' : '');
      pill.title = isOpen() ? 'Свий' : 'Виж какво е важно';
      pill.addEventListener('click', () => {
        if (Date.now() - (card.__ptDragged || 0) < 250) return;   /* току-що влачено */
        open(!isOpen());
      });
      head.appendChild(pill);

      if (isOpen()) {
        const close = el('button', 'ptnote__x', '✕');
        close.type = 'button';
        close.title = 'Свий';
        close.addEventListener('click', () => open(false));
        head.appendChild(close);
      }
      card.appendChild(head);

      if (isOpen()) {
        const body = el('div', 'ptnote__body');
        for (const n of items) {
          const item = el('div', 'ptnote__item');
          const meta = el('div', 'ptnote__meta');
          const parts = [];
          if (n.from) parts.push('от ' + clean(n.from, 60));
          if (n.by) parts.push('закачил: ' + clean(n.by, 60));
          const w = when(n.at);
          if (w) parts.push(w);
          meta.textContent = parts.join(' · ');
          item.appendChild(el('div', 'ptnote__title', clean(n.title, 80) || 'Важна информация'));
          item.appendChild(meta);
          item.appendChild(el('div', 'ptnote__text', clean(n.text, MAX_TEXT)));

          const row = el('div', 'ptnote__row');
          if (n.url) {
            const a = el('a', 'ptnote__link', 'Отвори в Basecamp');
            a.href = n.url;
            a.target = '_blank';
            a.rel = 'noopener noreferrer';
            row.appendChild(a);
          }
          const del = el('button', 'ptnote__del', 'Махни за всички');
          del.type = 'button';
          del.addEventListener('click', () => {
            if (window.confirm('Да махна ли това от прозорчето на целия екип?')) remove(n.id);
          });
          row.appendChild(del);
          item.appendChild(row);
          body.appendChild(item);
        }
        card.appendChild(body);
      }

      drag(card, head);
      place(card);
    } finally {
      building = false;
    }
  }

  /* ---------- старт ---------- */

  PT.start(() => {
    if (PT.cfg.features.teamNotes === false) return;
    if (!PT.dbRoot) return;   /* без канал няма как да е „за всички" */

    document.addEventListener('click', (e) => {
      const b = e.target.closest ? e.target.closest('.ptnote-btn') : null;
      if (!b) return;
      e.preventDefault();
      e.stopPropagation();
      const art = b.parentElement;
      if (art) shareComment(art);
    }, true);

    const guard = PT.safe ? PT.safe(injectButtons) : injectButtons;
    guard();
    PT.onDomChange(guard);
    PT.onNav(() => { guard(); load(); });
    PT.onVisibility((visible) => { if (visible) load(); });
    window.addEventListener('resize', () => {
      const box = document.getElementById('pt-note');
      if (box) place(box);
    });
    if (PT.onOrphan) {
      PT.onOrphan(() => {
        const box = document.getElementById('pt-note');
        if (box) box.remove();
      });
    }

    load();
    setInterval(PT.safe ? PT.safe(load) : load, REFRESH_MS);
  });
})();
