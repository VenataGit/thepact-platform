/* The Pact Tools — бутон „✓ Готово".
 * Отделно от таймера: не мери време, само пази кой САМ е казал „аз я
 * направих тази задача" и кога. Захранва отчета в платформата (по човек/ден/
 * седмица/месец/custom, и по отдел — според позицията на човека в Настройки
 * → Екип и роли). Заявките минават през service worker-а (виж background.js),
 * както при таймера — content скриптовете нямат право на cross-origin заявки.
 *
 * Собствена лента долу в средата на екрана — нарочно НЕ в ъглите, за да не се
 * застъпва с прозорчето на таймера (то стои в br/bl/tr/tl/лента горе). */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__doneLoaded) return;
  PT.__doneLoaded = true;

  const TRACKABLE = new Set(['todos', 'cards']);

  /* Осиротял content скрипт (разширението е обновено/презаредено) — виж
     time-tracker.js за пълното обяснение защо точно chrome.runtime.id е
     единственият надежден признак. */
  let dead = false;
  const orphaned = () => {
    try { return !(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return true; }
  };

  const send = (msg) => new Promise((resolve) => {
    if (dead) { resolve(null); return; }
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        const err = chrome.runtime.lastError;
        if (err) { if (orphaned()) dead = true; resolve(null); return; }
        resolve(r || null);
      });
    } catch (e) {
      if (orphaned()) dead = true;
      resolve(null);
    }
  });

  const state = { connected: null, done: false, busy: false };

  function pageTask() {
    const m = location.pathname.match(/\/buckets\/(\d+)\/((?:[a-z_]+\/)*[a-z_]+)\/(\d+)(?:\/edit)?$/);
    if (!m) return null;
    const segs = m[2].split('/');
    const type = segs[segs.length - 1];
    if (!TRACKABLE.has(type)) return null;
    return { bucket: m[1], type, rid: m[3] };
  }

  /* Виж time-tracker.js#TITLE_SKIP за защо точно тези изключения — Basecamp
     държи скрито h1 на банера „isn't fully functional" ПРЕДИ истинското
     заглавие на задачата в DOM реда. */
  const TITLE_SKIP = '#pt-layer, .system-degradations-banner, [class*="degradation"], [role="alert"], [role="status"]';
  function pickTitle(sel) {
    let nodes;
    try { nodes = document.querySelectorAll(sel); } catch (e) { return ''; }
    for (const el of nodes) {
      try {
        if (el.closest(TITLE_SKIP)) continue;
        if (!el.getClientRects().length) continue;
      } catch (e) { continue; }
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (t.length >= 2) return t;
    }
    return '';
  }
  function taskTitle() {
    let t = pickTitle('main h1, [data-recording-id] h1, article h1, .recording h1');
    if (!t) t = pickTitle('h1');
    if (!t) t = (document.title || '').split(/\s*[—|•|·]\s*/)[0].trim();
    return t.slice(0, 300);
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function panel() { return PT.sub('pt-done', 'pt-done'); }

  let lastRid = '';

  async function loadStatus(task) {
    const r = await send({ type: 'pt-done', action: 'status', bc_card_id: task.rid });
    if (!r) return;
    state.connected = r.connected !== false;
    if (state.connected && r.done !== null && r.done !== undefined) state.done = r.done;
    render();
  }

  async function toggle() {
    const task = pageTask();
    if (!task || state.busy) return;
    state.busy = true;
    render();
    const r = await send({
      type: 'pt-done', action: 'toggle',
      bc_project_id: task.bucket, bc_card_id: task.rid,
      title: taskTitle(), url: location.href.split('#')[0]
    });
    state.busy = false;
    if (!r) { render(); return; }
    if (r.connected === false) { state.connected = false; render(); return; }
    if (typeof r.done === 'boolean') state.done = r.done;
    render();
  }

  function render() {
    if (PT.cfg.features.taskDone === false) return;
    if (dead) {
      const old = document.getElementById('pt-done');
      if (old) old.remove();
      return;
    }
    const box = panel();
    const task = pageTask();
    if (!task || !state.connected) { box.style.display = 'none'; return; }
    box.style.display = '';
    box.innerHTML = '';

    const btn = el('button', 'pt-done__btn' + (state.done ? ' pt-done__btn--on' : ''));
    btn.type = 'button';
    btn.disabled = state.busy;
    btn.textContent = state.busy ? '…' : (state.done ? '✓ Готово (ти)' : '✓ Отбележи като готово');
    btn.title = state.done
      ? 'Ти отбеляза тази задача като готова — цъкни пак, за да махнеш отметката'
      : 'Готов си с тази задача — цъкни, за да се преброи на теб в отчета';
    btn.addEventListener('click', () => { toggle().catch(() => {}); });
    box.append(btn);
  }

  PT.start(() => {
    if (PT.cfg.features.taskDone === false) return;

    let lastPath = '';
    const onChange = () => {
      if (location.pathname === lastPath) return;
      lastPath = location.pathname;
      const task = pageTask();
      if (task && task.rid !== lastRid) {
        lastRid = task.rid;
        state.done = false;
        state.connected = null;
        loadStatus(task).catch(() => {});
      } else if (!task) {
        state.connected = null;
      }
      render();
    };
    PT.onNav(() => { lastPath = ''; onChange(); });
    PT.onDomChange(onChange);
    PT.onVisibility((visible) => {
      if (!visible) return;
      const task = pageTask();
      if (task) loadStatus(task).catch(() => {});
    });

    if (PT.onOrphan) PT.onOrphan(() => { dead = true; });

    onChange();
  });
})();
