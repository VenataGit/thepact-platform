/* The Pact Tools — функция „Закачане на коментари“.
 * Закача коментари от Basecamp в плаващи панели, които остават на екрана при скролване. */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__pinLoaded) return;
  PT.__pinLoaded = true;

  const HOST_ATTR = 'data-bcpin-host';
  const PINNED_ATTR = 'data-bcpin-pinned';
  const COMPOSE_BTN = 'bcpin-compose-btn';
  const MIN_W = 280;
  const MIN_H = 150;

  let zCounter = 10;
  let cascadeIdx = 0;

  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  const readJSON = (key) => {
    try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; }
  };
  const writeJSON = (key, val) => {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* ignore */ }
  };

  const panelsHost = () => PT.sub('pt-pin-panels');

  /* ---------- обхват на пина: конкретна страница vs. всички страници ----------
     По подразбиране пинът е закачен за страницата, от която е направен: показва
     се само там и изчезва при преминаване на друга; при връщане се появява пак.
     Бутонът 📍 до „✕“ го прави глобален (виждан на всеки Basecamp таб/страница). */

  const pageKey = () => location.pathname;
  const visibleHere = (s) => !!s && (s.global || (s.page || '') === pageKey());

  /* Стари пинове (без полета page/global) са се показвали навсякъде — оставяме ги
     глобални, за да не изчезнат неочаквано; новите тръгват като „само тази страница". */
  function normalizeSaved(s) {
    if (s && !('global' in s) && !('page' in s)) {
      return Object.assign({}, s, { global: true, page: '' });
    }
    return s;
  }

  /* ---------- намиране на коментарите ---------- */

  const SELECTORS = [
    'article[data-recording-id]',
    'article[id^="recording_"]',
    'article[id^="comment_"]',
    'article.thread-entry',
    '.thread-entry',
    'article.thread-post'
  ];

  function findCandidates() {
    const set = new Set();
    for (const sel of SELECTORS) {
      try { document.querySelectorAll(sel).forEach((el) => set.add(el)); } catch (e) { /* ignore */ }
    }
    if (!set.size) {
      document.querySelectorAll('main article').forEach((el) => set.add(el));
    }
    const arr = [...set];
    return arr.filter((el) =>
      (el.textContent || '').trim().length >= 8 &&
      !arr.some((other) => other !== el && el.contains(other))
    );
  }

  function injectButtons() {
    if (!document.body) return;
    for (const el of findCandidates()) {
      el.setAttribute(HOST_ATTR, '1');
      if (el.querySelector(':scope > .bcpin-btn')) continue;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'bcpin-btn';
      btn.title = 'Закачи коментара в плаващ прозорец';
      btn.setAttribute('aria-label', 'Закачи коментара');
      btn.textContent = '📌';
      if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
      el.appendChild(btn);
    }
  }

  /* ---------- закачане ---------- */

  function titleFor(el) {
    const sels = [
      '[class*="author"] a',
      '[class*="author"]',
      'header a[href*="/people"]',
      'a[href*="/people/"]',
      '.thread-entry__header a',
      'header strong',
      '[class*="header"] strong'
    ];
    for (const s of sels) {
      try {
        const n = el.querySelector(s);
        const t = n && n.textContent.trim().replace(/\s+/g, ' ');
        if (t && t.length >= 2 && t.length <= 60) return t;
      } catch (e) { /* ignore */ }
    }
    return 'Закачен коментар';
  }

  function sanitizeClone(root) {
    root.querySelectorAll('img').forEach((img) => {
      const lazy = img.getAttribute('data-src');
      if (lazy && !img.getAttribute('src')) img.setAttribute('src', lazy);
    });
    root.querySelectorAll(
      'script, iframe, object, embed, details, button, input, textarea, select, form, dialog, template, turbo-frame, .bcpin-btn, .bcedit-chip'
    ).forEach((n) => n.remove());
    for (const el of [root, ...root.querySelectorAll('*')]) {
      el.removeAttribute('id');
      el.removeAttribute('contenteditable');
      for (const attr of [...el.attributes]) {
        const name = attr.name.toLowerCase();
        /* on* = инлайн скриптове; data-* = кукички на Basecamp-ския JS (Stimulus),
           които не бива да се активират повторно върху копието */
        if (name.indexOf('on') === 0 || name.indexOf('data-') === 0) el.removeAttribute(attr.name);
      }
    }
    root.querySelectorAll('a[href]').forEach((a) => {
      a.setAttribute('target', '_blank');
      a.setAttribute('rel', 'noopener noreferrer');
    });
  }

  function pinComment(srcEl) {
    const srcKey = srcEl.id && /^(recording|comment)_/.test(srcEl.id) ? srcEl.id : '';
    if (srcKey) {
      const existing = document.querySelector('.bcpin-panel[data-src-key="' + CSS.escape(srcKey) + '"]');
      if (existing) { attn(existing); return; }
    }
    const prevId = srcEl.getAttribute(PINNED_ATTR);
    if (prevId) {
      const existing = document.getElementById(prevId);
      if (existing) { attn(existing); return; }
    }

    const clone = srcEl.cloneNode(true);
    sanitizeClone(clone);

    const id = 'bcpin-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    srcEl.setAttribute(PINNED_ATTR, id);

    const panel = buildPanel(id, titleFor(srcEl), clone, srcKey, srcEl, { page: pageKey(), global: false });
    panelsHost().appendChild(panel);
    placePanel(panel);
    attn(panel);
    saveSoon();

    /* fixed/sticky елементи в копието биха "избягали" от панела върху целия екран */
    requestAnimationFrame(() => {
      panel.querySelectorAll('.bcpin-body *').forEach((el) => {
        const pos = getComputedStyle(el).position;
        if (pos === 'fixed' || pos === 'sticky') el.style.position = 'relative';
      });
    });
  }

  function attn(panel) {
    panel.style.zIndex = ++zCounter;
    panel.classList.remove('bcpin-attn');
    void panel.offsetWidth; /* рестартира анимацията */
    panel.classList.add('bcpin-attn');
    setTimeout(() => panel.classList.remove('bcpin-attn'), 1100);
  }

  /* ---------- панелът ---------- */

  function buildPanel(id, title, clone, srcKey, srcEl, meta) {
    const panel = document.createElement('section');
    panel.className = 'bcpin-panel';
    panel.id = id;
    panel.tabIndex = -1;
    if (srcKey) panel.setAttribute('data-src-key', srcKey);

    meta = meta || { page: pageKey(), global: false };
    panel.__bcpinMeta = meta;

    /* „жив" панел = самото поле за коментар е преместено вътре (не копие),
       затова тук не пипаме съдържанието и не го пазим в localStorage */
    const live = !!meta.live;
    if (live) panel.classList.add('bcpin-live');

    const frame = document.createElement('div');
    frame.className = 'bcpin-frame';

    const header = document.createElement('header');
    header.className = 'bcpin-header';

    const ico = document.createElement('button');
    ico.type = 'button';
    ico.className = 'bcpin-ico';
    ico.title = live ? 'Покажи мястото му в задачата' : 'Покажи оригинала на страницата';
    ico.setAttribute('aria-label', ico.title);
    ico.textContent = live ? '✍️' : '📌';

    const titleEl = document.createElement('span');
    titleEl.className = 'bcpin-title';
    titleEl.textContent = title;
    titleEl.title = 'Влачи за местене • Двоен клик: свий/разгъни';

    const pinAllBtn = document.createElement('button');
    pinAllBtn.type = 'button';
    pinAllBtn.className = 'bcpin-globe';
    pinAllBtn.textContent = '📍';
    const syncPinAll = () => {
      pinAllBtn.classList.toggle('bcpin-globe--on', !!meta.global);
      pinAllBtn.title = meta.global
        ? 'Показва се на всяка страница — цъкни за само тази'
        : 'Закачи за всички прозорци';
      pinAllBtn.setAttribute('aria-label', pinAllBtn.title);
    };
    syncPinAll();

    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'bcpin-close';
    closeBtn.title = live ? 'Върни полето долу в задачата' : 'Откачи коментара';
    closeBtn.setAttribute('aria-label', closeBtn.title);
    closeBtn.textContent = '✕';

    const body = document.createElement('div');
    body.className = 'bcpin-body';
    body.style.backgroundColor = PT.pageBackground();
    if (clone) body.appendChild(clone);
    if (!live) body.addEventListener('scroll', saveSoon, { passive: true });

    header.append(ico, titleEl);
    if (!live) header.append(pinAllBtn);
    if (live) {
      const swapBtn = document.createElement('button');
      swapBtn.type = 'button';
      swapBtn.className = 'bcpin-swap';
      swapBtn.title = 'Другият начин на закачане (полето остава на място)';
      swapBtn.setAttribute('aria-label', swapBtn.title);
      swapBtn.textContent = '⇄';
      swapBtn.addEventListener('click', (e) => { e.stopPropagation(); switchComposerMode(); });
      header.append(makeReportBtn('bcpin-swap'), swapBtn);
    }
    header.append(closeBtn);
    frame.append(header, body);
    panel.append(frame);

    pinAllBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      meta.global = !meta.global;
      /* при връщане към „само тази страница" го закачаме за текущата */
      if (!meta.global) meta.page = pageKey();
      syncPinAll();
      attn(panel);
      saveSoon();
    });

    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (live) { unpinComposer(true); return; }
      try { if (srcEl && srcEl.isConnected) srcEl.removeAttribute(PINNED_ATTR); } catch (err) { /* ignore */ }
      if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
      panel.remove();
      removePin(panel.id);
    });

    ico.addEventListener('click', (e) => {
      e.stopPropagation();
      if (Date.now() - (panel.__bcpinDragEnd || 0) < 250) return;
      const target = live
        ? (liveState && liveState.slot && liveState.slot.isConnected ? liveState.slot : null)
        : ((srcEl && srcEl.isConnected) ? srcEl : (srcKey ? document.getElementById(srcKey) : null));
      if (!target) return;
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      target.classList.add('bcpin-src-flash');
      setTimeout(() => target.classList.remove('bcpin-src-flash'), 1600);
    });

    panel.addEventListener('pointerdown', () => { panel.style.zIndex = ++zCounter; });
    /* при живия панел вътре се пише — Escape и спирането на кликовете биха пречили
       на самия Basecamp (редактор, прикачени файлове, изпращане) */
    if (!live) {
      panel.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeBtn.click(); });
      panel.addEventListener('click', (e) => e.stopPropagation());
    }

    /* скрол върху заглавката/ръбовете да не мърда страницата отдолу;
       вътре в тялото скролът е нативен и запазва позицията си */
    panel.addEventListener('wheel', (e) => {
      if (!(e.target.closest && e.target.closest('.bcpin-body'))) e.preventDefault();
    }, { passive: false });

    /* в тялото: линковете се отварят в нов таб, останалите интерактивни елементи са изключени
       (само за копията — в живия панел всичко трябва да работи) */
    if (!live) body.addEventListener('click', (e) => {
      const a = e.target.closest && e.target.closest('a[href]');
      if (a) {
        a.setAttribute('target', '_blank');
        a.setAttribute('rel', 'noopener noreferrer');
        return;
      }
      const interactive = e.target.closest &&
        e.target.closest('button, summary, input, select, textarea, label, [role="button"]');
      if (interactive) { e.preventDefault(); e.stopPropagation(); }
    }, true);

    header.addEventListener('dblclick', (e) => {
      if (e.target.closest('.bcpin-close') || e.target.closest('.bcpin-ico') ||
          e.target.closest('.bcpin-globe') || e.target.closest('.bcpin-swap')) return;
      toggleCollapse(panel);
    });

    makeDraggable(panel, header);
    addResizeHandles(panel);
    return panel;
  }

  function toggleCollapse(panel) {
    if (panel.classList.contains('bcpin-collapsed')) {
      panel.classList.remove('bcpin-collapsed');
      panel.style.height = panel.getAttribute('data-prev-h') || '';
      panel.removeAttribute('data-prev-h');
    } else {
      if (panel.style.height) panel.setAttribute('data-prev-h', panel.style.height);
      panel.style.height = '';
      panel.classList.add('bcpin-collapsed');
    }
    if (!panel.classList.contains('bcpin-live')) saveSoon();
  }

  /* ---------- запомняне на размер/позиция (живият панел си има свои) ---------- */

  function saveGeom(panel, what) {
    const r = panel.getBoundingClientRect();
    if (panel.classList.contains('bcpin-live')) {
      const cur = readJSON('bcpin:live') || {};
      writeJSON('bcpin:live', Object.assign(cur, what === 'pos'
        ? { x: Math.round(r.left), y: Math.round(r.top) }
        : { w: Math.round(r.width), h: Math.round(r.height) }));
      return;
    }
    if (what === 'pos') {
      writeJSON('bcpin:pos', { x: Math.round(r.left), y: Math.round(r.top) });
    } else {
      writeJSON('bcpin:size', { w: Math.round(r.width), h: panel.style.height ? Math.round(r.height) : null });
    }
    saveSoon();
  }

  function placePanel(panel) {
    const savedSize = readJSON('bcpin:size') || {};
    const w = clamp(
      Math.round(savedSize.w || clamp(window.innerWidth * 0.28, 340, 480)),
      MIN_W,
      Math.round(window.innerWidth * 0.94)
    );
    panel.style.width = w + 'px';
    if (savedSize.h) {
      panel.style.height = clamp(Math.round(savedSize.h), MIN_H, Math.round(window.innerHeight * 0.92)) + 'px';
    } else {
      /* по подразбиране не по-висок от ~70% от екрана — да се вижда и задачата отдолу */
      panel.style.maxHeight = Math.round(window.innerHeight * 0.72) + 'px';
    }
    const savedPos = readJSON('bcpin:pos');
    const cascade = (cascadeIdx++ % 7) * 28;
    const left = (savedPos && Number.isFinite(savedPos.x) ? savedPos.x : window.innerWidth - w - 20) - cascade;
    const top = (savedPos && Number.isFinite(savedPos.y) ? savedPos.y : 84) + cascade;
    panel.style.left = clamp(left, 8, Math.max(8, window.innerWidth - w - 8)) + 'px';
    panel.style.top = clamp(top, 8, Math.max(8, window.innerHeight - 140)) + 'px';
    panel.style.zIndex = ++zCounter;
  }

  /* ---------- влачене ---------- */

  function makeDraggable(panel, header) {
    header.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      if (e.target.closest('.bcpin-close') || e.target.closest('.bcpin-ico') ||
          e.target.closest('.bcpin-globe') || e.target.closest('.bcpin-swap')) return;
      const rect = panel.getBoundingClientRect();
      const offX = e.clientX - rect.left;
      const offY = e.clientY - rect.top;
      const startX = e.clientX;
      const startY = e.clientY;
      let dragging = false;
      const onMove = (ev) => {
        if (!dragging && Math.abs(ev.clientX - startX) + Math.abs(ev.clientY - startY) < 4) return;
        if (!dragging) {
          dragging = true;
          panel.classList.add('bcpin-dragging');
          try { header.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        }
        const w = panel.offsetWidth;
        panel.style.left = clamp(ev.clientX - offX, 60 - w, window.innerWidth - 60) + 'px';
        panel.style.top = clamp(ev.clientY - offY, 0, window.innerHeight - 44) + 'px';
      };
      const onUp = () => {
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', onUp);
        panel.classList.remove('bcpin-dragging');
        if (dragging) {
          panel.__bcpinDragEnd = Date.now();
          saveGeom(panel, 'pos');
        }
      };
      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', onUp);
    });
  }

  /* ---------- преоразмеряване ---------- */

  function addResizeHandles(panel) {
    for (const dir of ['r', 'l', 'b', 'br', 'bl']) {
      const h = document.createElement('div');
      h.className = 'bcpin-rz bcpin-rz-' + dir;
      h.addEventListener('pointerdown', (e) => startResize(panel, dir, e, h));
      panel.appendChild(h);
    }
  }

  function startResize(panel, dir, e, handle) {
    if (e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    const start = panel.getBoundingClientRect();
    const sx = e.clientX;
    const sy = e.clientY;
    const onMove = (ev) => {
      if (dir.indexOf('r') >= 0 || dir.indexOf('l') >= 0) {
        let w = dir.indexOf('r') >= 0
          ? start.width + (ev.clientX - sx)
          : start.width - (ev.clientX - sx);
        w = clamp(w, MIN_W, Math.round(window.innerWidth * 0.94));
        panel.style.width = Math.round(w) + 'px';
        if (dir.indexOf('l') >= 0) panel.style.left = Math.round(start.right - w) + 'px';
      }
      if (dir.indexOf('b') >= 0) {
        panel.style.maxHeight = '';
        const h = clamp(start.height + (ev.clientY - sy), MIN_H, Math.round(window.innerHeight * 0.92));
        panel.style.height = Math.round(h) + 'px';
      }
    };
    const onUp = () => {
      handle.removeEventListener('pointermove', onMove);
      handle.removeEventListener('pointerup', onUp);
      handle.removeEventListener('pointercancel', onUp);
      saveGeom(panel, 'size');
    };
    try { handle.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    handle.addEventListener('pointermove', onMove);
    handle.addEventListener('pointerup', onUp);
    handle.addEventListener('pointercancel', onUp);
  }

  /* ---------- закачане на САМОТО поле за коментар ----------
     Копие тук не върши работа: полето е форма с Trix редактор и бутон „Изпрати",
     а копието е мъртво (затова излизаше празен прозорец).

     Основен вариант: полето си остава ТОЧНО КЪДЕТО Е в DOM-а — само го заковаваме
     към екрана с position: fixed и отгоре му рисуваме лента за влачене и ръбове за
     оразмеряване. Нищо не се мести → Trix, контролерите на Basecamp, разгъването
     на полето и изпращането работят точно както преди, а полето на страницата е
     едно-единствено (няма как да пишеш „в другото" долу).

     Резервен вариант: ако страницата не позволява fixed (родител с transform),
     местим самия елемент в плаващ панел — по-крехко, затова е второ. */

  let liveState = null;   /* { panel, slot, page } — резервният вариант */
  let wantLive = false;   /* Basecamp пресъздаде полето → закачаме го пак */
  let repins = 0;

  const liveHost = () => {
    let el = document.getElementById('pt-pin-live');
    if (!el) {
      el = document.createElement('div');
      el.id = 'pt-pin-live';
      (document.body || document.documentElement).appendChild(el);
    }
    return el;
  };

  /* видим редактор в елемента (скритите форми за редакция не се броят) */
  function visibleEditor(root) {
    if (!root || !root.querySelectorAll) return null;
    const eds = (root.matches && root.matches('trix-editor')) ? [root] : [...root.querySelectorAll('trix-editor')];
    for (const ed of eds) {
      if (ed.closest('.bcpin-panel')) continue;
      try { if (ed.getClientRects().length) return ed; } catch (e) { /* ignore */ }
    }
    return null;
  }

  /* цялата форма около редактора — с лентата с бутони и „Изпрати".
     Пазим се да не завлечем половината страница: формата трябва да е само полето. */
  function composerRoot(ed) {
    const form = ed.closest('form');
    if (form &&
        form.querySelectorAll('trix-editor').length === 1 &&
        !form.querySelector('article')) return form;
    let node = ed.parentElement;
    for (let i = 0; i < 3 && node && node.parentElement; i++) {
      if (node.querySelector('trix-toolbar') && node.querySelector('input[type="submit"], button[type="submit"]')) break;
      node = node.parentElement;
    }
    return node || ed;
  }

  /* Полетата за коментар на страницата — и когато редакторът още е свит/скрит
     (тогава се хващаме за самата форма, а разгъването си работи вътре в закаченото). */
  const COMPOSER_SELECTORS = [
    'form[action*="/comments"]',
    'form[action*="comment"]',
    'form.new_comment',
    '#new_comment',
    '.comment-form',
    '#comment-form',
    '[class*="comment"][class*="form"]'
  ];

  function tooBigForComposer(el) {
    if (!el) return true;
    if (el.querySelector('article')) return true;                  /* завлякло е коментари */
    if (el.querySelectorAll('trix-editor').length > 1) return true; /* повече от едно поле */
    const h = el.getBoundingClientRect().height;
    return h > 0 && h > Math.max(window.innerHeight, 400) * 1.6;
  }

  function findComposerTargets() {
    const out = [];
    const add = (el) => {
      if (!el || !el.isConnected || out.indexOf(el) >= 0) return;
      if (el.closest('.bcpin-panel, .bcpin-float-chrome, #' + PT.LAYER_ID)) return;
      if (tooBigForComposer(el)) return;
      out.push(el);
    };
    document.querySelectorAll('trix-editor').forEach((ed) => {
      if (!ed.closest('.bcpin-panel')) add(composerRoot(ed));
    });
    if (!out.length) {
      for (const sel of COMPOSER_SELECTORS) {
        try { document.querySelectorAll(sel).forEach(add); } catch (e) { /* ignore */ }
        if (out.length) break;
      }
    }
    return out;
  }

  /* полето, което да закачим: видимият редактор, иначе първото намерено поле */
  function findComposer() {
    const ed = visibleEditor(document.body);
    if (ed) return composerRoot(ed);
    const targets = findComposerTargets();
    for (const el of targets) {
      try { if (el.getClientRects().length) return el; } catch (e) { /* ignore */ }
    }
    return targets[0] || null;
  }

  const composerBarFor = (el) => {
    const prev = el.previousElementSibling;
    return (prev && prev.classList && prev.classList.contains('bcpin-compose-bar')) ? prev : null;
  };

  /* Бутонът е лентичка НАД полето — и когато полето е свито, за да се вижда, без
     да си стигнал до долу. Нарочно не е вътре в полето: това щеше да иска
     position: relative върху формата на Basecamp, а оттам се разместват техните
     собствени абсолютно позиционирани елементи. */
  function injectComposerButtons() {
    if (!document.body) return;
    for (const el of findComposerTargets()) {
      if (floatState && floatState.el === el) continue;
      const prev = el.previousElementSibling;
      if (prev && prev.classList &&
          (prev.classList.contains('bcpin-compose-bar') || prev.classList.contains('bcpin-slot'))) continue;
      const bar = document.createElement('div');
      bar.className = 'bcpin-compose-bar';
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = COMPOSE_BTN;
      btn.title = 'Закачи полето за коментар — остава на екрана, докато скролваш';
      btn.setAttribute('aria-label', 'Закачи полето за коментар');
      btn.textContent = '📌 Закачи полето';
      bar.append(btn, makeReportBtn('bcpin-diag-btn'));
      try { el.parentNode.insertBefore(bar, el); } catch (e) { /* ignore */ }
    }
  }

  /* ---------- основен вариант: заковаваме полето на място ---------- */

  const BAR_H = 30;
  let floatState = null;   /* { el, chrome, spacer, css, page, at, x, y, w, h } */

  /* position: fixed се чупи, ако родител има transform/filter/contain —
     тогава „закованото" всъщност пътува със страницата */
  function transformedAncestor(el) {
    for (let n = el.parentElement; n && n !== document.documentElement; n = n.parentElement) {
      let s;
      try { s = getComputedStyle(n); } catch (e) { return null; }
      if (!s) return null;
      if ((s.transform && s.transform !== 'none') ||
          (s.perspective && s.perspective !== 'none') ||
          (s.filter && s.filter !== 'none') ||
          (s.contain && /paint|layout|strict|content/.test(s.contain)) ||
          (s.willChange && /transform|filter|perspective/.test(s.willChange))) return n;
    }
    return null;
  }

  /* Нарочно НЕ налагаме height на формата на Basecamp: вътре в нея има елементи,
     които се разчитат на естествената ѝ височина, и при твърда височина полето за
     писане оставаше извън видимото (пишеш, а текста го няма). Затова само подът
     (min-height, колкото е оразмерена) и таванът (max-height), а рамката отгоре
     следва реалния размер през syncChrome(). */

  const setImp = (s, prop, val) => {
    if (s.getPropertyValue(prop) !== val) s.setProperty(prop, val, 'important');
  };

  /* Таванът е спрямо ЕКРАНА, а не спрямо текущото място на кутията. Ако беше
     спрямо мястото, при кутия долу таванът излизаше по-малък от пода — а в CSS
     min-height бие max-height, тоест таванът се обезсилва и кутията расте
     безкрайно надолу извън екрана: дългият коментар не се вижда и няма какво да
     се скролва (кутията не прелива — просто е извън екрана). */
  const floatMaxH = () => Math.max(MIN_H, window.innerHeight - 16 - BAR_H);

  function applyFloatGeom(x, y, w, h) {
    const st = floatState;
    if (!st) return;
    st.x = x; st.y = y; st.w = w; st.h = h;
    const s = st.el.style;
    /* important, за да надвием стиловете на Basecamp за същия елемент */
    setImp(s, 'position', 'fixed');
    setImp(s, 'left', Math.round(x) + 'px');
    setImp(s, 'top', Math.round(y + BAR_H) + 'px');
    setImp(s, 'width', Math.round(w) + 'px');
    setImp(s, 'max-width', 'none');
    setImp(s, 'margin', '0');
    setImp(s, 'z-index', '2147483100');
    refitFloat();
  }

  /* Полето расте, докато пишеш. Затова:
     1) подът никога не надвишава тавана (иначе таванът не важи);
     2) ако кутията е опряла долния ръб, вдига се нагоре, докъдето има място;
     3) чак когато и това свърши — таванът я спира и вътре се скролва. */
  function refitFloat() {
    const st = floatState;
    if (!st || !st.el.isConnected) return;
    const s = st.el.style;
    const maxH = floatMaxH();
    setImp(s, 'height', 'auto');
    setImp(s, 'max-height', Math.round(maxH) + 'px');
    setImp(s, 'min-height', Math.round(Math.min(st.h, maxH)) + 'px');

    const r = st.el.getBoundingClientRect();
    let top = r.top;
    if (r.bottom > window.innerHeight - 8) top = window.innerHeight - 8 - r.height;
    if (top < 8 + BAR_H) top = 8 + BAR_H;
    if (Math.abs(top - r.top) > 1) {
      setImp(s, 'top', Math.round(top) + 'px');
      st.y = Math.round(top - BAR_H);
    }
    syncChrome();
  }

  /* рамката се лепи за реалните размери на полето (то расте, докато пишеш) */
  function syncChrome() {
    const st = floatState;
    if (!st || !st.el.isConnected) return;
    const r = st.el.getBoundingClientRect();
    if (!r.width && !r.height) return;
    st.chrome.style.left = Math.round(r.left) + 'px';
    st.chrome.style.top = Math.round(r.top - BAR_H) + 'px';
    st.chrome.style.width = Math.round(r.width) + 'px';
    st.chrome.style.height = Math.round(r.height + BAR_H) + 'px';
  }

  function saveFloatGeom() {
    const st = floatState;
    if (!st) return;
    writeJSON('bcpin:float', { x: Math.round(st.x), y: Math.round(st.y), w: Math.round(st.w), h: Math.round(st.h) });
  }

  /* полето за писане вътре (Trix, contenteditable или textarea) */
  function editableIn(el) {
    const ed = el.querySelector('trix-editor, [contenteditable="true"], textarea');
    if (!ed) return null;
    try { return ed.getClientRects().length ? ed : null; } catch (e) { return null; }
  }

  /* вижда ли се наистина полето за писане вътре в закованата кутия */
  function editableShows(el, only) {
    const ed = only || editableIn(el);
    if (!ed) return false;
    const b = el.getBoundingClientRect();
    const r = ed.getBoundingClientRect();
    if (r.width < 8 || r.height < 8) return false;
    return (Math.min(b.right, r.right) - Math.max(b.left, r.left)) > 8 &&
           (Math.min(b.bottom, r.bottom) - Math.max(b.top, r.top)) > 8;
  }

  function buildFloatChrome() {
    const chrome = document.createElement('div');
    chrome.className = 'bcpin-float-chrome';

    const header = document.createElement('header');
    header.className = 'bcpin-header';

    const ico = document.createElement('button');
    ico.type = 'button';
    ico.className = 'bcpin-ico';
    ico.title = 'Покажи мястото му в задачата';
    ico.setAttribute('aria-label', ico.title);
    ico.textContent = '✍️';
    ico.addEventListener('click', (e) => {
      e.stopPropagation();
      const st = floatState;
      if (!st || !st.spacer.isConnected) return;
      st.spacer.scrollIntoView({ behavior: 'smooth', block: 'center' });
      st.spacer.classList.add('bcpin-src-flash');
      setTimeout(() => st.spacer.classList.remove('bcpin-src-flash'), 1600);
    });

    const titleEl = document.createElement('span');
    titleEl.className = 'bcpin-title';
    titleEl.textContent = 'Коментар · v' + PT.version;
    titleEl.title = 'Влачи за местене';

    const swapBtn = document.createElement('button');
    swapBtn.type = 'button';
    swapBtn.className = 'bcpin-swap';
    swapBtn.title = 'Другият начин на закачане (ако тук нещо не се вижда)';
    swapBtn.setAttribute('aria-label', swapBtn.title);
    swapBtn.textContent = '⇄';
    swapBtn.addEventListener('click', (e) => { e.stopPropagation(); switchComposerMode(); });

    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'bcpin-close';
    closeBtn.title = 'Върни полето долу в задачата';
    closeBtn.setAttribute('aria-label', closeBtn.title);
    closeBtn.textContent = '✕';
    closeBtn.addEventListener('click', (e) => { e.stopPropagation(); unpinComposerAny(true); });

    header.append(ico, titleEl, makeReportBtn('bcpin-swap'), swapBtn, closeBtn);
    chrome.appendChild(header);

    for (const dir of ['r', 'l', 'b', 'br', 'bl']) {
      const h = document.createElement('div');
      h.className = 'bcpin-rz bcpin-rz-' + dir;
      h.addEventListener('pointerdown', (e) => startFloatResize(dir, e, h));
      chrome.appendChild(h);
    }
    makeFloatDraggable(chrome, header);
    return chrome;
  }

  function makeFloatDraggable(chrome, header) {
    header.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || (e.target.closest && e.target.closest('button'))) return;
      const st = floatState;
      if (!st) return;
      const offX = e.clientX - st.x;
      const offY = e.clientY - st.y;
      const startX = e.clientX;
      const startY = e.clientY;
      let dragging = false;
      const onMove = (ev) => {
        if (!dragging && Math.abs(ev.clientX - startX) + Math.abs(ev.clientY - startY) < 4) return;
        if (!dragging) {
          dragging = true;
          chrome.classList.add('bcpin-dragging');
          try { header.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        }
        const cur = floatState;
        if (!cur) return;
        applyFloatGeom(
          clamp(ev.clientX - offX, 60 - cur.w, window.innerWidth - 60),
          clamp(ev.clientY - offY, 0, window.innerHeight - BAR_H - 20),
          cur.w,
          cur.h
        );
      };
      const onUp = () => {
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', onUp);
        chrome.classList.remove('bcpin-dragging');
        if (dragging) saveFloatGeom();
      };
      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', onUp);
    });
  }

  function startFloatResize(dir, e, handle) {
    const st = floatState;
    if (!st || e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    const sx = e.clientX;
    const sy = e.clientY;
    const x0 = st.x;
    const w0 = st.w;
    const h0 = st.h;
    const y0 = st.y;
    const onMove = (ev) => {
      if (!floatState) return;
      let w = w0;
      let x = x0;
      let h = h0;
      if (dir.indexOf('r') >= 0) w = w0 + (ev.clientX - sx);
      if (dir.indexOf('l') >= 0) w = w0 - (ev.clientX - sx);
      w = clamp(w, MIN_W, Math.round(window.innerWidth * 0.94));
      if (dir.indexOf('l') >= 0) x = x0 + (w0 - w);
      if (dir.indexOf('b') >= 0) h = clamp(h0 + (ev.clientY - sy), MIN_H, Math.round(window.innerHeight * 0.9));
      applyFloatGeom(x, y0, w, h);
    };
    const onUp = () => {
      handle.removeEventListener('pointermove', onMove);
      handle.removeEventListener('pointerup', onUp);
      handle.removeEventListener('pointercancel', onUp);
      saveFloatGeom();
    };
    try { handle.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    handle.addEventListener('pointermove', onMove);
    handle.addEventListener('pointerup', onUp);
    handle.addEventListener('pointercancel', onUp);
  }

  /* ---------- „пиша, а не виждам текста" ----------
     Каквото и да е подредил Basecamp, важи едно: полето, в което реално пишеш,
     трябва да е ВЪТРЕ в закаченото и да се вижда. Тук го налагаме, без да
     гадаем по тяхната структура. */

  const EDITABLE_SEL = 'trix-editor, [contenteditable="true"], textarea';
  const OUR_UI_SEL = '.bcpin-panel, .bcpin-float-chrome, .bcpin-report, #pt-layer';
  let retargets = 0;

  /* казваме му, когато сме сменили начина сами — иначе изглежда като магия */
  function sayModeSwitch() {
    PT.upsertBanner(
      'bcpin-mode',
      'info',
      'Заковаването на място не се получи тук — минах на отделен прозорец. Бутонът ⇄ в лентата връща другия начин.'
    );
    setTimeout(() => PT.dropBanner('bcpin-mode'), 9000);
  }

  function ensureEditableVisible(ed) {
    if (!ed) return;
    try { ed.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (e) { /* ignore */ }
  }

  /* фокусът отиде в поле за писане — в закаченото ли е? */
  function onEditableFocus(target) {
    if (!floatState || !target || !target.closest) return;
    if (target.closest(OUR_UI_SEL)) return;
    const ed = target.closest(EDITABLE_SEL);
    if (!ed) return;

    if (floatState.el.contains(ed)) {
      ensureEditableVisible(ed);
      /* и ако въпреки това остава извън кутията — минаваме на режима, чиято
         подредба е наша (отделен прозорец), вместо да се пише на сляпо */
      requestAnimationFrame(() => {
        if (!floatState || !floatState.el.contains(ed)) return;
        if (editableShows(floatState.el, ed)) return;
        const el = floatState.el;
        undoFloat();
        pinComposer(el, { silent: true });
        sayModeSwitch();
        setTimeout(() => { try { ed.focus(); } catch (err) { /* ignore */ } }, 0);
      });
      return;
    }

    /* Пишеш в поле извън закаченото — значи сме закачили погрешния елемент.
       Закачаме този, в който реално се пише. */
    const root = composerRoot(ed);
    if (retargets >= 2 || !root || root === floatState.el || tooBigForComposer(root)) {
      PT.upsertBanner(
        'bcpin-wrong',
        'amber',
        'Пишеш в поле, което не е в закаченото. Цъкни 🔎 в лентата на закаченото и прати доклада на Клод.'
      );
      return;
    }
    retargets++;
    PT.dropBanner('bcpin-wrong');
    undoFloat();
    pinComposerAuto(root, { silent: true });
    setTimeout(() => { try { ed.focus(); } catch (e) { /* ignore */ } }, 0);
  }

  /* ---------- доклад за структурата (за да не се гадае) ---------- */

  function describeNode(el) {
    if (!el) return '(няма)';
    let s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    const cls = (el.getAttribute('class') || '').trim().split(/\s+/).filter(Boolean).slice(0, 3);
    if (cls.length) s += '.' + cls.join('.');
    return s;
  }

  function rectStr(el) {
    if (!el) return '';
    const r = el.getBoundingClientRect();
    return '[' + Math.round(r.left) + ',' + Math.round(r.top) + ' ' +
      Math.round(r.width) + 'x' + Math.round(r.height) + ']';
  }

  function styleStr(el) {
    let s;
    try { s = getComputedStyle(el); } catch (e) { return ''; }
    const bits = ['pos:' + s.position, 'disp:' + s.display, 'ovf:' + s.overflow];
    if (s.height && s.height !== 'auto') bits.push('h:' + s.height);
    if (s.transform && s.transform !== 'none') bits.push('transform!');
    if (s.visibility !== 'visible') bits.push('vis:' + s.visibility);
    if (s.opacity !== '1') bits.push('op:' + s.opacity);
    return bits.join(' ');
  }

  function skeleton(el, depth, maxDepth, out) {
    if (!el || depth > maxDepth || out.length > 40) return out;
    out.push('  '.repeat(depth) + describeNode(el) + ' ' + rectStr(el) + ' ' + styleStr(el));
    for (const child of el.children) {
      if (child.closest && child.matches(OUR_UI_SEL)) continue;
      skeleton(child, depth + 1, maxDepth, out);
    }
    return out;
  }

  function composerReport() {
    const pinned = floatState ? floatState.el
      : (liveState ? (liveState.panel.querySelector('.bcpin-body') || {}).firstElementChild : null);
    const target = pinned || findComposer();
    const lines = [];
    lines.push('The Pact Tools v' + PT.version + ' — доклад за полето за коментар');
    lines.push('страница: ' + location.pathname + '  екран: ' + window.innerWidth + 'x' + window.innerHeight);
    lines.push('режим: ' + (floatState ? 'заковано на място' : (liveState ? 'отделен прозорец' : 'незакачено')));
    lines.push('закачен елемент: ' + describeNode(target) + ' ' + rectStr(target) + ' ' + styleStr(target));

    const eds = document.querySelectorAll(EDITABLE_SEL);
    lines.push('полета за писане на страницата: ' + eds.length);
    let i = 0;
    for (const ed of eds) {
      if (ed.closest(OUR_UI_SEL) && !(target && target.contains(ed))) continue;
      i++;
      const focused = document.activeElement === ed || ed.contains(document.activeElement);
      lines.push('  #' + i + ' ' + describeNode(ed) + ' ' + rectStr(ed) + ' ' + styleStr(ed) +
        ' | видимо:' + (ed.getClientRects().length ? 'да' : 'не') +
        ' | в закаченото:' + (target && target.contains(ed) ? 'да' : 'НЕ') +
        ' | фокус:' + (focused ? 'ДА' : 'не') +
        ' | текст:' + String((ed.textContent || ed.value || '').trim().length) + ' зн.');
    }
    if (target) {
      lines.push('структура на закачения елемент:');
      skeleton(target, 0, 3, lines);
      const anc = [];
      for (let n = target.parentElement; n && n !== document.documentElement && anc.length < 6; n = n.parentElement) {
        anc.push(describeNode(n) + ' (' + styleStr(n) + ')');
      }
      lines.push('родители: ' + anc.join(' < '));
    }
    return lines.join('\n').slice(0, 4000);
  }

  function showReport() {
    const text = composerReport();
    const old = document.getElementById('pt-pin-report');
    if (old) old.remove();
    const box = document.createElement('div');
    box.id = 'pt-pin-report';
    box.className = 'bcpin-report';
    const info = document.createElement('div');
    info.className = 'bcpin-report-info';
    info.textContent = 'Копирай текста (Ctrl+C) и го пусни като коментар — точно това ми трябва.';
    const ta = document.createElement('textarea');
    ta.readOnly = true;
    ta.value = text;
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'bcpin-close';
    close.title = 'Затвори';
    close.textContent = '✕';
    close.addEventListener('click', () => box.remove());
    box.append(info, ta, close);
    PT.layer().appendChild(box);
    try { ta.focus(); ta.select(); } catch (e) { /* ignore */ }
    try {
      navigator.clipboard.writeText(text).then(
        () => { info.textContent = 'Копирано! Пусни го като коментар (Ctrl+V).'; },
        () => { /* ръчното копиране си остава */ }
      );
    } catch (e) { /* ignore */ }
  }

  function makeReportBtn(cls) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = cls;
    b.title = 'Доклад за полето за коментар (за Клод)';
    b.setAttribute('aria-label', b.title);
    b.textContent = '🔎';
    b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); showReport(); });
    return b;
  }

  function focusComposer(el) {
    const ed = el.querySelector('trix-editor');
    if (!ed) return;
    try { if (!ed.getClientRects().length) return; } catch (e) { return; }
    setTimeout(() => { try { ed.focus(); } catch (err) { /* ignore */ } }, 60);
  }

  function makeSlot(text) {
    const slot = document.createElement('div');
    slot.className = 'bcpin-slot';
    slot.setAttribute('role', 'button');
    slot.tabIndex = 0;
    slot.textContent = text;
    slot.addEventListener('click', () => unpinComposerAny(true));
    slot.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); unpinComposerAny(true); }
    });
    return slot;
  }

  function tryFloat(el, opts) {
    if (floatState) { return true; }
    if (transformedAncestor(el)) return false;

    const r = el.getBoundingClientRect();
    const saved = readJSON('bcpin:float') || {};
    /* по подразбиране колкото си е широко на страницата — вътрешната му подредба
       е смятана за тази ширина и не бива да я мачкаме */
    const w = clamp(
      Math.round(saved.w || r.width || 520),
      MIN_W,
      Math.round(window.innerWidth * 0.94)
    );
    const h = clamp(Math.round(saved.h || Math.min(360, Math.max(200, r.height || 260))), MIN_H, Math.round(window.innerHeight * 0.86));
    const x = clamp(
      Number.isFinite(saved.x) ? saved.x : Math.round(window.innerWidth - w - 24),
      8,
      Math.max(8, window.innerWidth - w - 8)
    );
    /* по подразбиране долу вдясно, но малко над прозорчето на таймера */
    const y = clamp(
      Number.isFinite(saved.y) ? saved.y : Math.round(window.innerHeight - h - BAR_H - 72),
      8,
      Math.max(8, window.innerHeight - BAR_H - 60)
    );

    const spacer = makeSlot('📌 Полето за коментар е закачено на екрана — цъкни тук, за да го върнеш на място.');
    spacer.style.minHeight = Math.max(40, Math.round(r.height)) + 'px';

    /* ако полето за писане се е виждало преди закачането, длъжни сме да се
       вижда и след него — иначе се пише „на сляпо" */
    const hadEditable = !!editableIn(el);

    floatState = {
      el: el,
      chrome: buildFloatChrome(),
      spacer: spacer,
      bar: composerBarFor(el),
      css: el.getAttribute('style'),
      page: pageKey(),
      at: Date.now(),
      ro: null,
      x: x, y: y, w: w, h: h
    };
    try {
      if (floatState.bar) floatState.bar.style.display = 'none';
      el.parentNode.insertBefore(spacer, el);
      el.classList.add('bcpin-float');
      liveHost().appendChild(floatState.chrome);
      applyFloatGeom(x, y, w, h);
      /* прозрачно поле върху текста отдолу е нечетимо */
      const bg = getComputedStyle(el).backgroundColor;
      if (!bg || bg === 'transparent' || bg === 'rgba(0, 0, 0, 0)') {
        el.style.setProperty('background-color', PT.pageBackground(), 'important');
      }
    } catch (e) {
      undoFloat();
      return false;
    }

    /* Наистина ли се закачи за екрана? (ако не — връщаме всичко и пробваме другия
       вариант.) Сверява се спрямо floatState, а не спрямо подадените x/y: refitFloat
       може съвсем законно да е вдигнал кутията, за да не излиза под екрана. */
    const after = el.getBoundingClientRect();
    if (Math.abs(after.left - floatState.x) > 2 || Math.abs(after.top - (floatState.y + BAR_H)) > 2) {
      undoFloat();
      return false;
    }

    wantLive = true;

    /* полето расте, докато пишеш — рамката отгоре го следва */
    if (typeof ResizeObserver === 'function') {
      try {
        floatState.ro = new ResizeObserver(() => refitFloat());
        floatState.ro.observe(el);
      } catch (e) { /* ignore */ }
    }

    requestAnimationFrame(() => {
      if (!floatState || floatState.el !== el) return;
      syncChrome();
      const ed = editableIn(el);
      if (ed) { try { ed.scrollIntoView({ block: 'nearest' }); } catch (e) { /* ignore */ } }
      /* Полето за писане остана извън видимото? Тогава заковаването не върши работа
         за тази страница — връщаме всичко и минаваме на местене в панел. */
      if (hadEditable && !editableShows(el)) {
        undoFloat();
        pinComposer(el, opts);
        sayModeSwitch();
        return;
      }
      if (!(opts && opts.silent)) focusComposer(el);
    });
    return true;
  }

  function undoFloat() {
    const st = floatState;
    if (!st) return;
    floatState = null;
    try { if (st.ro) st.ro.disconnect(); } catch (e) { /* ignore */ }
    try {
      st.el.classList.remove('bcpin-float');
      if (st.css === null) st.el.removeAttribute('style');
      else st.el.setAttribute('style', st.css);
    } catch (e) { /* ignore */ }
    try { if (st.spacer) st.spacer.remove(); } catch (e) { /* ignore */ }
    try { if (st.chrome) st.chrome.remove(); } catch (e) { /* ignore */ }
    try { if (st.bar && st.bar.isConnected) st.bar.style.display = ''; } catch (e) { /* ignore */ }
  }

  /* закачаме както е най-безопасно: първо на място, после (ако не става) с местене.
     Ако човекът е избрал ръчно другия режим (бутон ⇄), уважаваме избора му. */
  function pinComposerAuto(el, opts) {
    if (!el || !el.isConnected || !el.parentNode) return;
    if (floatState || liveState) return;
    if (readJSON('bcpin:mode') === 'panel') { pinComposer(el, opts); return; }
    if (tryFloat(el, opts)) return;
    pinComposer(el, opts);
  }

  /* ⇄ — превключва двата начина на закачане и помни избора.
     Аварийният изход, ако на нечия страница единият изглежда счупен. */
  function switchComposerMode() {
    if (floatState) {
      const el = floatState.el;
      writeJSON('bcpin:mode', 'panel');
      undoFloat();
      wantLive = false;
      if (el && el.isConnected) pinComposer(el);
      return;
    }
    if (liveState) {
      const body = liveState.panel.querySelector('.bcpin-body');
      const el = body && body.firstElementChild;
      writeJSON('bcpin:mode', 'float');
      unpinComposer(true);
      if (el && el.isConnected && !tryFloat(el)) pinComposer(el);
    }
  }

  function unpinComposerAny(restore) {
    PT.dropBanner('bcpin-wrong');
    if (restore !== false) retargets = 0;
    if (floatState) {
      undoFloat();
      if (restore !== false) { wantLive = false; repins = 0; }
      injectComposerButtons();
      return;
    }
    unpinComposer(restore);
  }

  /* ---------- резервен вариант: местене на полето в плаващ панел ---------- */

  function pinComposer(form, opts) {
    if (!form || !form.isConnected || !form.parentNode) return;
    if (liveState) { attn(liveState.panel); return; }

    const slot = makeSlot('📌 Полето за коментар е закачено в плаващия прозорец — цъкни тук, за да го върнеш.');

    const bar = composerBarFor(form);
    let panel = null;
    try {
      if (bar) bar.style.display = 'none';
      form.parentNode.insertBefore(slot, form);
      panel = buildPanel(
        'bcpin-live-' + Date.now().toString(36),
        'Коментар · v' + PT.version,
        form,
        '',
        null,
        { page: pageKey(), global: false, live: true }
      );
      liveHost().appendChild(panel);
    } catch (e) {
      /* нещо се обърка — връщаме полето обратно, все едно нищо не е било */
      try {
        if (slot.isConnected && slot.parentNode) slot.parentNode.insertBefore(form, slot);
        slot.remove();
        if (panel) panel.remove();
        if (bar) bar.style.display = '';
      } catch (err) { /* ignore */ }
      return;
    }

    liveState = { panel: panel, slot: slot, bar: bar, page: pageKey(), at: Date.now() };
    wantLive = true;
    placeLivePanel(panel);
    attn(panel);
    if (!(opts && opts.silent)) {
      setTimeout(() => {
        const ed = panel.querySelector('trix-editor');
        if (ed) { try { ed.focus(); } catch (err) { /* ignore */ } }
      }, 60);
    }
  }

  function unpinComposer(restore) {
    const st = liveState;
    if (!st) return;
    liveState = null;
    if (restore !== false) { wantLive = false; repins = 0; }
    const body = st.panel.querySelector('.bcpin-body');
    try {
      if (restore !== false && body && st.slot && st.slot.isConnected && st.slot.parentNode) {
        while (body.firstChild) st.slot.parentNode.insertBefore(body.firstChild, st.slot);
      }
    } catch (e) { /* ignore */ }
    try { if (st.slot) st.slot.remove(); } catch (e) { /* ignore */ }
    try { st.panel.remove(); } catch (e) { /* ignore */ }
    try { if (st.bar && st.bar.isConnected) st.bar.style.display = ''; } catch (e) { /* ignore */ }
    injectComposerButtons();
  }

  function placeLivePanel(panel) {
    const saved = readJSON('bcpin:live') || {};
    const w = clamp(
      Math.round(saved.w || Math.min(620, Math.max(360, window.innerWidth * 0.44))),
      MIN_W,
      Math.round(window.innerWidth * 0.94)
    );
    const h = clamp(Math.round(saved.h || 320), MIN_H, Math.round(window.innerHeight * 0.9));
    panel.style.width = w + 'px';
    panel.style.height = h + 'px';
    const left = Number.isFinite(saved.x) ? saved.x : Math.round(window.innerWidth - w - 24);
    const top = Number.isFinite(saved.y) ? saved.y : Math.round(window.innerHeight - h - 24);
    panel.style.left = clamp(left, 8, Math.max(8, window.innerWidth - w - 8)) + 'px';
    panel.style.top = clamp(top, 8, Math.max(8, window.innerHeight - 80)) + 'px';
    panel.style.zIndex = ++zCounter;
  }

  /* Basecamp пресъздава секцията с коментари (напр. след изпращане на коментар) →
     закаченото изчезва. Тогава го пускаме и се закачаме наново за новото поле. */
  function checkLive() {
    if (floatState) {
      if (pageKey() !== floatState.page) {
        undoFloat();
        wantLive = false;
        repins = 0;
        retargets = 0;
        PT.dropBanner('bcpin-wrong');
        return;
      }
      if (floatState.el.isConnected && floatState.spacer.isConnected && floatState.chrome.isConnected) {
        /* държи се от известно време → броячът за презакачане може да се нулира */
        if (repins && Date.now() - floatState.at > 5000) repins = 0;
        refitFloat();   /* втора застраховка, ако ResizeObserver липсва/не е усетил */
        return;
      }
      undoFloat();   /* полето/мястото го няма → закачаме наново долу (wantLive остава) */
    } else if (liveState) {
      if (!liveState.panel.isConnected) {   /* Turbo смени <body> — панелът си отиде с него */
        liveState = null;
        wantLive = false;
        repins = 0;
        return;
      }
      if (pageKey() !== liveState.page) {
        unpinComposer(false);
        wantLive = false;
        repins = 0;
        return;
      }
      if (liveState.slot.isConnected) {
        if (repins && Date.now() - liveState.at > 5000) repins = 0;
        return;
      }
      unpinComposer(false);
    }
    if (!wantLive || repins >= 3) return;
    const form = findComposer();
    if (!form) return;
    repins++;
    pinComposerAuto(form, { silent: true });
  }

  /* ---------- пиновете са общи за табовете и преживяват презареждане ----------
     Пазим ги в localStorage: F5, нов таб, дори рестарт на браузъра ги връщат.
     storage събитието синхронизира на живо между отворените табове. */

  let saveTimer = null;
  let applyingRemote = false;

  function saveSoon() {
    if (saveTimer) return;
    saveTimer = setTimeout(() => { saveTimer = null; savePins(); }, 600);
  }

  function savePins() {
    if (applyingRemote) return;
    const live = [];
    const liveIds = new Set();
    /* живият панел (истинското поле за коментар) не се записва — той не е копие */
    document.querySelectorAll('.bcpin-panel:not(.bcpin-live)').forEach((p) => {
      const body = p.querySelector('.bcpin-body');
      if (!body) return;
      const meta = p.__bcpinMeta || {};
      live.push({
        id: p.id,
        srcKey: p.getAttribute('data-src-key') || '',
        title: ((p.querySelector('.bcpin-title') || {}).textContent || ''),
        html: body.innerHTML,
        bg: body.style.backgroundColor || '',
        left: p.style.left || '',
        top: p.style.top || '',
        width: p.style.width || '',
        height: p.style.height || '',
        maxHeight: p.style.maxHeight || '',
        collapsed: p.classList.contains('bcpin-collapsed'),
        scroll: body.scrollTop || 0,
        page: meta.page || '',
        global: !!meta.global
      });
      liveIds.add(p.id);
    });
    /* панелите от другите страници сега не са в DOM-а — запазваме ги както са */
    const others = readSaved().filter((s) => s && s.id && !liveIds.has(s.id));
    try {
      localStorage.setItem('bcpin:panels', JSON.stringify(live.concat(others).slice(0, 16)));
    } catch (e) { /* квота — пропускаме тихо */ }
  }

  function removePin(id) {
    if (!id) return;
    const arr = readSaved().filter((s) => s && s.id !== id);
    try { localStorage.setItem('bcpin:panels', JSON.stringify(arr)); } catch (e) { /* ignore */ }
  }

  function readSaved() {
    try {
      const arr = JSON.parse(localStorage.getItem('bcpin:panels'));
      return Array.isArray(arr) ? arr.map(normalizeSaved) : [];
    } catch (e) {
      return [];
    }
  }

  function buildFromSaved(s) {
    if (!s || !s.html || (s.id && document.getElementById(s.id))) return null;
    const wrap = document.createElement('div');
    try { wrap.innerHTML = s.html; } catch (e) { return null; } /* съдържанието е санитизирано при закачането */
    const panel = buildPanel(
      s.id || ('bcpin-r' + Math.random().toString(36).slice(2, 8)),
      s.title || 'Закачен коментар',
      wrap,
      s.srcKey || '',
      null,
      { page: s.page || '', global: !!s.global }
    );
    const body = panel.querySelector('.bcpin-body');
    if (s.bg && body) body.style.backgroundColor = s.bg;
    panelsHost().appendChild(panel);
    if (s.width) panel.style.width = s.width;
    if (s.height) panel.style.height = s.height;
    if (s.maxHeight) panel.style.maxHeight = s.maxHeight;
    panel.style.left = s.left || '20px';
    panel.style.top = s.top || '84px';
    panel.style.zIndex = ++zCounter;
    if (s.collapsed) panel.classList.add('bcpin-collapsed');
    requestAnimationFrame(() => { if (body) body.scrollTop = Number(s.scroll) || 0; });
    return panel;
  }

  function restorePins() {
    const arr = readSaved();
    if (!arr.length) return;
    applyingRemote = true;
    try {
      for (const s of arr) if (visibleHere(s)) buildFromSaved(s);
    } finally {
      applyingRemote = false;
    }
    /* прибираме ги в екрана, ако междувременно резолюцията се е сменила */
    window.dispatchEvent(new Event('resize'));
  }

  /* синхронизация на живо: промяна от друг таб */
  function reconcilePins() {
    const arr = readSaved();
    applyingRemote = true;
    try {
      const wanted = new Map(arr.filter((s) => s && s.id && s.html && visibleHere(s)).map((s) => [s.id, s]));
      document.querySelectorAll('.bcpin-panel:not(.bcpin-live)').forEach((p) => {
        if (!wanted.has(p.id)) p.remove();
      });
      for (const s of wanted.values()) {
        const existing = document.getElementById(s.id);
        if (!existing) {
          buildFromSaved(s);
        } else if (!existing.classList.contains('bcpin-dragging')) {
          if (existing.__bcpinMeta) {
            existing.__bcpinMeta.page = s.page || '';
            existing.__bcpinMeta.global = !!s.global;
          }
          if (s.left) existing.style.left = s.left;
          if (s.top) existing.style.top = s.top;
          if (s.width) existing.style.width = s.width;
          existing.style.height = s.height || '';
          if (s.maxHeight) existing.style.maxHeight = s.maxHeight;
          existing.classList.toggle('bcpin-collapsed', !!s.collapsed);
        }
      }
    } finally {
      applyingRemote = false;
    }
  }

  /* ---------- старт ---------- */

  PT.ready.then(() => {
    if (PT.cfg.features.pinComments === false) return;

    /* Кликовете върху 📌 се хващат делегирано на document — така бутоните работят
       и след като Turbo възстанови страница от кеша си (кешът пази DOM без слушатели). */
    document.addEventListener('click', (e) => {
      if (!e.target.closest) return;
      const compose = e.target.closest('.' + COMPOSE_BTN);
      if (compose) {
        e.preventDefault();
        e.stopPropagation();
        const bar = compose.closest('.bcpin-compose-bar');
        const target = (bar && bar.nextElementSibling) || findComposer();
        if (target) pinComposerAuto(target);
        return;
      }
      const btn = e.target.closest('.bcpin-btn');
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      const host = btn.closest('[' + HOST_ATTR + ']') || btn.parentElement;
      if (!host) return;
      /* 📌 върху областта с полето за коментар: копие няма смисъл (излиза празен
         прозорец) — закачаме самото поле, за да може да се пише в него */
      const ed = visibleEditor(host);
      if (ed) { pinComposerAuto(composerRoot(ed)); return; }
      if (host.querySelector('trix-editor') || COMPOSER_SELECTORS.some((s) => {
        try { return host.matches(s) || !!host.querySelector(s); } catch (err) { return false; }
      })) {
        const target = findComposer();
        if (target) { pinComposerAuto(target); return; }
      }
      pinComment(host);
    }, true);

    /* самокоригиране: ако пишеш в поле извън закаченото, закачаме правилното;
       ако е вътре, но е излязло от видимото — прибираме го обратно */
    document.addEventListener('focusin', (e) => onEditableFocus(e.target));
    document.addEventListener('input', (e) => {
      if (!floatState || !e.target || !e.target.closest) return;
      if (e.target.closest(OUR_UI_SEL)) return;
      if (!floatState.el.contains(e.target)) { onEditableFocus(e.target); return; }
      /* пипаме само ако полето е излязло изцяло от кутията — иначе браузърът си
         движи курсора сам и не бива да му дърпаме скрола, докато редактира */
      const ed = e.target.closest(EDITABLE_SEL) || e.target;
      if (!editableShows(floatState.el, ed)) ensureEditableVisible(ed);
    }, true);

    window.addEventListener('resize', () => {
      if (floatState) {
        const st = floatState;
        applyFloatGeom(
          clamp(st.x, 8, Math.max(8, window.innerWidth - Math.min(st.w, window.innerWidth - 16))),
          clamp(st.y, 8, Math.max(8, window.innerHeight - BAR_H - 60)),
          Math.min(st.w, Math.round(window.innerWidth * 0.94)),
          Math.min(st.h, Math.round(window.innerHeight * 0.9))
        );
      }
      document.querySelectorAll('.bcpin-panel').forEach((panel) => {
        const r = panel.getBoundingClientRect();
        panel.style.left = clamp(r.left, 60 - r.width, Math.max(0, window.innerWidth - 60)) + 'px';
        panel.style.top = clamp(r.top, 0, Math.max(0, window.innerHeight - 44)) + 'px';
      });
    });

    PT.onDomChange(() => { injectButtons(); injectComposerButtons(); checkLive(); });
    PT.onNav(() => { injectButtons(); injectComposerButtons(); checkLive(); });
    /* при преминаване на друга страница: скрий пиновете само за старата,
       покажи закачените за новата (глобалните остават) */
    PT.onNav(reconcilePins);
    /* Turbo сменя <body> и си кешира страницата — полето трябва да е на мястото си
       и без нашите стилове, преди това да стане */
    document.addEventListener('turbo:before-render', () => unpinComposerAny(true));
    document.addEventListener('turbo:before-cache', () => unpinComposerAny(true));
    window.addEventListener('pagehide', () => unpinComposerAny(true));
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') savePins();
    });
    window.addEventListener('pagehide', savePins);
    window.addEventListener('storage', (e) => {
      if (e.key === 'bcpin:panels') reconcilePins();
    });
    try {
      /* еднократна миграция от старото per-tab съхранение (v1.2) */
      if (!localStorage.getItem('bcpin:panels') && sessionStorage.getItem('bcpin:panels')) {
        localStorage.setItem('bcpin:panels', sessionStorage.getItem('bcpin:panels'));
        sessionStorage.removeItem('bcpin:panels');
      }
    } catch (e) { /* ignore */ }
    restorePins();
    injectButtons();
    injectComposerButtons();
  });
})();
