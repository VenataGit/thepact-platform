/* The Pact Tools — MAIN world мост.
 * Изолираният свят на content скриптовете не вижда JS обектите на страницата,
 * затова този файл живее в света на Basecamp и върши две неща:
 * 1) вмъква шаблони в Trix редактора през официалното му API;
 * 2) ако Basecamp изложи текущия човек в глобална променлива, я подава обратно. */
(() => {
  'use strict';
  if (window.__ptMainLoaded) return;
  window.__ptMainLoaded = true;

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.type !== 'thepact-tools:insert') return;
    const el = document.querySelector('trix-editor[data-pt-insert]');
    if (!el) return;
    el.removeAttribute('data-pt-insert');
    const html = String(e.data.html || '');
    try {
      if (el.editor && typeof el.editor.insertHTML === 'function') {
        el.focus();
        el.editor.insertHTML(html);
        return;
      }
    } catch (err) { /* пробваме резервния път */ }
    try {
      el.focus();
      document.execCommand('insertHTML', false, html);
    } catch (err) { /* ignore */ }
  });

  /* опортюнистично: текущият човек от глобалите на Basecamp (ако съществуват) */
  const probe = () => {
    try {
      const bc = window.BC || {};
      const p = bc.currentPerson || (bc.session && bc.session.currentPerson) || null;
      if (p && (p.id || p.name)) {
        window.postMessage({
          type: 'thepact-tools:person',
          id: p.id !== undefined && p.id !== null ? String(p.id) : '',
          name: p.name ? String(p.name) : ''
        }, location.origin);
        return true;
      }
    } catch (err) { /* ignore */ }
    return false;
  };
  if (!probe()) {
    let tries = 0;
    const timer = setInterval(() => {
      if (probe() || ++tries > 10) clearInterval(timer);
    }, 1000);
  }
})();
