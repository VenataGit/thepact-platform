/* The Pact Tools — MAIN world мост.
 * Изолираният свят на content скриптовете не вижда JS обектите на страницата,
 * затова този файл живее в света на Basecamp и върши две неща:
 * 1) вмъква шаблони в Trix редактора през официалното му API;
 * 2) ако Basecamp изложи текущия човек в глобална променлива, я подава обратно. */
(() => {
  'use strict';
  if (window.__ptMainLoaded) return;
  window.__ptMainLoaded = true;

  /* ---------- запис на грешките, които вижда самият Basecamp ----------
     Банерът „Basecamp isn't fully functional right now." се вдига от техния
     наблюдател на грешки. Изолираният свят на content скриптовете НЕ вижда
     грешките на страницата, затова се пазят тук — последните осем, само текст и
     източник — и се дават при поискване, за да се разбере чии са всъщност. */

  const REC = [];
  const clip = (v, n) => String(v === undefined || v === null ? '' : v).slice(0, n);
  const push = (kind, msg, src) => {
    try {
      REC.push({ kind: kind, msg: clip(msg, 300), src: clip(src, 200), at: Date.now() });
      if (REC.length > 8) REC.shift();
    } catch (err) { /* ignore */ }
  };

  try {
    const orig = console.error;
    console.error = function () {
      try {
        const parts = Array.prototype.map.call(arguments, (a) => (a && a.message) ? a.message : String(a));
        push('console', parts.join(' '), (arguments[0] && arguments[0].stack) || '');
      } catch (err) { /* ignore */ }
      return orig.apply(console, arguments);
    };
  } catch (err) { /* ignore */ }

  window.addEventListener('error', (e) => {
    push('error', (e.error && e.error.message) || e.message, (e.filename || '') + ':' + (e.lineno || ''));
  }, true);
  window.addEventListener('unhandledrejection', (e) => {
    const r = e.reason;
    push('rejection', (r && (r.message || r)) || 'неизвестна', (r && r.stack) || '');
  }, true);

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.type !== 'thepact-tools:errors?') return;
    window.postMessage({ type: 'thepact-tools:errors!', list: REC.slice() }, location.origin);
  });

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.type !== 'thepact-tools:insert') return;
    const el = document.querySelector('trix-editor[data-pt-insert]');
    if (!el) return;
    el.removeAttribute('data-pt-insert');
    const html = String(e.data.html || '');
    try {
      if (el.editor && typeof el.editor.insertHTML === 'function') {
        el.focus();
        el.editor.insertHTML(html);
        return;
      }
    } catch (err) { /* пробваме резервния път */ }
    try {
      el.focus();
      document.execCommand('insertHTML', false, html);
    } catch (err) { /* ignore */ }
  });

  /* опортюнистично: текущият човек от глобалите на Basecamp (ако съществуват) */
  const probe = () => {
    try {
      const bc = window.BC || {};
      const p = bc.currentPerson || (bc.session && bc.session.currentPerson) || null;
      if (p && (p.id || p.name)) {
        window.postMessage({
          type: 'thepact-tools:person',
          id: p.id !== undefined && p.id !== null ? String(p.id) : '',
          name: p.name ? String(p.name) : ''
        }, location.origin);
        return true;
      }
    } catch (err) { /* ignore */ }
    return false;
  };
  if (!probe()) {
    let tries = 0;
    const timer = setInterval(() => {
      if (probe() || ++tries > 10) clearInterval(timer);
    }, 1000);
  }
})();
