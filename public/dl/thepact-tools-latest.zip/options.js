/* The Pact Tools — Options страница */
'use strict';

const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(
  { displayName: '', featPin: true, featLock: true, featBar: true, featNotify: true, featTpl: true, featTime: true, featDraft: true, featNotes: true, autoName: '' },
  (st) => {
    $('displayName').value = st.displayName || '';
    $('featPin').checked = st.featPin !== false;
    $('featLock').checked = st.featLock !== false;
    $('featBar').checked = st.featBar !== false;
    $('featNotify').checked = st.featNotify !== false;
    $('featTpl').checked = st.featTpl !== false;
    $('featTime').checked = st.featTime !== false;
    $('featDraft').checked = st.featDraft !== false;
    $('featNotes').checked = st.featNotes !== false;
    $('autoName').textContent = st.autoName
      ? 'Автоматично разпознато име: ' + st.autoName
      : 'Автоматичното разпознаване се задейства при първото отваряне на Basecamp.';
  }
);

/* ако автоматичното име се е объркало веднъж — забравяме го и го взимаме наново
   от Basecamp профила при следващото отваряне на таб */
$('redetect').addEventListener('click', () => {
  chrome.storage.sync.set({ autoName: '', autoPid: '', autoV: 0, forceRedetect: Date.now() }, () => {
    $('autoName').textContent = 'Изчистено — презареди Basecamp таб (F5), за да се разпознае наново.';
  });
});

$('save').addEventListener('click', () => {
  chrome.storage.sync.set({
    displayName: $('displayName').value.trim(),
    featPin: $('featPin').checked,
    featLock: $('featLock').checked,
    featBar: $('featBar').checked,
    featNotify: $('featNotify').checked,
    featTpl: $('featTpl').checked,
    featTime: $('featTime').checked,
    featDraft: $('featDraft').checked,
    featNotes: $('featNotes').checked
  }, () => {
    $('status').textContent = 'Запазено ✓';
    setTimeout(() => { $('status').textContent = ''; }, 2500);
  });
});

/* ---------- връзка с платформата (тракване на време) ---------- */

function renderPlatform() {
  chrome.storage.sync.get({ ptToken: '', ptTokenName: '' }, (st) => {
    const connected = !!st.ptToken;
    $('platStatus').textContent = connected
      ? '⏱ Свързано с thepact.pro' + (st.ptTokenName ? ' като ' + st.ptTokenName : '') + '.'
      : '⏱ Не е свързано с платформата — таймерът ще предложи свързване при първия старт.';
    $('platConnect').style.display = connected ? 'none' : '';
    $('platDisconnect').style.display = connected ? '' : 'none';
  });
}

$('platConnect').addEventListener('click', () => {
  $('platConnect').textContent = 'Свързвам…';
  chrome.runtime.sendMessage({ type: 'pt-time', action: 'connect' }, (r) => {
    $('platConnect').textContent = 'Свържи с платформата';
    if (r && r.ok) {
      renderPlatform();
    } else {
      $('platStatus').textContent = '⚠ Първо влез в thepact.pro в този браузър, после цъкни пак „Свържи".';
      try { window.open('https://thepact.pro', '_blank'); } catch (e) { /* ignore */ }
    }
  });
});

$('platDisconnect').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'pt-time', action: 'disconnect' }, () => renderPlatform());
});

/* Коя версия върви и откъде е сложена. Ръчно сложено копие („Load unpacked")
   не се обновява само — оттам идват въпросите „защо при мен е по-стара версия".
   Chrome слага update_url в манифеста само на копията от Web Store. */
function renderVersion() {
  const mf = chrome.runtime.getManifest();
  const el = $('verInfo');
  if (!el) return;
  if (mf.update_url) {
    el.textContent = 'Версия ' + mf.version + ' · от Chrome Web Store (обновява се само).';
    return;
  }
  el.textContent = 'Версия ' + mf.version + ' · сложено на ръка — НЕ се обновява само. ' +
    'За автоматични обновявания го сложи от thepact.pro/extension.html';
  el.style.color = '#b45309';
}

renderVersion();
renderPlatform();
