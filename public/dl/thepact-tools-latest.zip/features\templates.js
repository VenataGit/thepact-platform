/* The Pact Tools — функция „Шаблони за коментари“.
 * Бутон 📋 във всяко поле за коментар/съобщение (Trix редактор) — вмъква
 * готов шаблон на екипа. Шаблоните се дефинират в config.js → templates. */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__tplLoaded) return;
  PT.__tplLoaded = true;

  let openMenu = null;

  function closeMenu() {
    if (openMenu) {
      openMenu.remove();
      openMenu = null;
    }
  }

  function templates() {
    const t = PT.cfg.templates;
    return Array.isArray(t) ? t.filter((x) => x && x.title && x.html) : [];
  }

  function injectButtons() {
    document.querySelectorAll('trix-editor').forEach((ed) => {
      const holder = ed.parentElement;
      if (!holder || holder.querySelector(':scope > .pt-tpl-btn')) return;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'pt-tpl-btn';
      btn.title = 'Вмъкни шаблон на The Pact';
      btn.setAttribute('aria-label', 'Вмъкни шаблон');
      btn.textContent = '📋';
      if (getComputedStyle(holder).position === 'static') holder.style.position = 'relative';
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleMenu(btn, ed);
      });
      holder.appendChild(btn);
    });
  }

  function toggleMenu(btn, ed) {
    if (openMenu) {
      closeMenu();
      return;
    }
    const list = templates();
    const menu = document.createElement('div');
    menu.className = 'pt-tpl-menu';
    if (!list.length) {
      const empty = document.createElement('div');
      empty.className = 'pt-tpl-empty';
      empty.textContent = 'Няма шаблони — добавят се в config.js на разширението.';
      menu.appendChild(empty);
    }
    for (const t of list) {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'pt-tpl-item';
      item.textContent = t.title;
      item.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        insertTemplate(ed, t.html);
        closeMenu();
      });
      menu.appendChild(item);
    }
    const r = btn.getBoundingClientRect();
    menu.style.left = Math.round(Math.max(8, Math.min(r.right - 260, window.innerWidth - 280))) + 'px';
    menu.style.top = Math.round(Math.min(r.bottom + 6, window.innerHeight - 60)) + 'px';
    PT.layer().appendChild(menu);
    openMenu = menu;
  }

  function insertTemplate(ed, html) {
    document.querySelectorAll('trix-editor[data-pt-insert]').forEach((x) => x.removeAttribute('data-pt-insert'));
    ed.setAttribute('data-pt-insert', '1');
    window.postMessage({ type: 'thepact-tools:insert', html: String(html) }, location.origin);
  }

  document.addEventListener('click', (e) => {
    if (openMenu && !(e.target.closest && e.target.closest('.pt-tpl-menu, .pt-tpl-btn'))) closeMenu();
  }, true);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeMenu();
  });
  window.addEventListener('scroll', closeMenu, { passive: true, capture: true });

  PT.ready.then(() => {
    if (PT.cfg.features.templates === false) return;
    PT.onDomChange(injectButtons);
    PT.onNav(() => { closeMenu(); injectButtons(); });
    injectButtons();
  });
})();
