/* The Pact Tools — background service worker.
 * 1) Системни известия (както досега).
 * 2) Мост към платформата thepact.pro за тракването на време: content
 *    скриптовете нямат право на cross-origin заявки, затова всички API
 *    извиквания минават оттук (host permission + bearer токен).
 * 3) Пулс на таймера през chrome.alarms (работи и при заспал таб) и
 *    авто-стоп, когато последният Basecamp таб бъде затворен. */
'use strict';

/* ---------- системни известия ---------- */

const tabByNotification = new Map();

function handleNotify(msg, sender) {
  const id = 'pt-' + Date.now() + '-' + Math.floor(Math.random() * 1e6);
  chrome.notifications.create(id, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: String(msg.title || 'The Pact Tools'),
    message: String(msg.message || ''),
    priority: 2
  });
  if (sender && sender.tab && sender.tab.id !== undefined) {
    tabByNotification.set(id, { tabId: sender.tab.id, windowId: sender.tab.windowId });
    if (tabByNotification.size > 50) {
      const oldest = tabByNotification.keys().next().value;
      tabByNotification.delete(oldest);
    }
  }
}

/* ---------- „излезе нова версия" ----------
   Chrome обновява разширението тихо и никой не разбира какво се е сменило.
   Затова при обновяване излиза едно известие, а кликът отваря страницата с
   възможностите и дневника на промените (там се вижда точно тази версия). */

const NEWS_URL = 'https://thepact.pro/extension.html';
const UPDATE_PREFIX = 'pt-update-';

chrome.runtime.onInstalled.addListener((details) => {
  if (!details || (details.reason !== 'update' && details.reason !== 'install')) return;
  const version = chrome.runtime.getManifest().version;
  if (details.reason === 'update' && details.previousVersion === version) return;
  const fresh = details.reason === 'install';
  chrome.notifications.create(UPDATE_PREFIX + version, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: fresh
      ? 'The Pact Tools е готов за работа'
      : 'The Pact Tools се обнови (v' + version + ')',
    message: fresh
      ? 'Цъкни, за да видиш какво може и как се ползва.'
      : 'Цъкни, за да видиш какво ново има в тази версия.',
    priority: 1
  });
});

chrome.notifications.onClicked.addListener((id) => {
  chrome.notifications.clear(id);

  if (String(id).indexOf(UPDATE_PREFIX) === 0) {
    const version = String(id).slice(UPDATE_PREFIX.length);
    try {
      chrome.tabs.create({ url: NEWS_URL + (version ? '?v=' + encodeURIComponent(version) : '') + '#novo' });
    } catch (e) { /* ignore */ }
    return;
  }

  const t = tabByNotification.get(id);
  if (!t) return;
  try {
    chrome.tabs.update(t.tabId, { active: true });
    if (t.windowId !== undefined) chrome.windows.update(t.windowId, { focused: true });
  } catch (e) { /* табът може вече да е затворен */ }
});

/* ---------- платформа API ---------- */

const API_BASE = 'https://thepact.pro';
const BEAT_ALARM = 'pt-time-beat';

async function getToken() {
  const st = await chrome.storage.sync.get({ ptToken: '' });
  return st.ptToken || '';
}

/* useCookies=true само при свързването — токенът се издава от логнатата
   сесия на thepact.pro; след това всичко върви с bearer токена. */
async function apiFetch(path, opts) {
  const o = opts || {};
  const headers = {};
  if (o.body !== undefined) headers['Content-Type'] = 'application/json';
  if (!o.useCookies) {
    const token = await getToken();
    if (!token) return { ok: false, status: 401, data: null };
    headers.Authorization = 'Bearer ' + token;
  }
  let res;
  try {
    res = await fetch(API_BASE + path, {
      method: o.method || 'GET',
      headers,
      credentials: o.useCookies ? 'include' : 'omit',
      body: o.body !== undefined ? JSON.stringify(o.body) : undefined
    });
  } catch (e) {
    return { ok: false, status: 0, data: null, error: 'network' };
  }
  let data = null;
  try { data = await res.json(); } catch (e) { /* празно тяло */ }
  return { ok: res.ok, status: res.status, data };
}

async function setRunning(entry) {
  await chrome.storage.session.set({ ptRunning: entry || null });
  if (entry) chrome.alarms.create(BEAT_ALARM, { periodInMinutes: 0.5 });
  else chrome.alarms.clear(BEAT_ALARM);
}

async function getRunningCached() {
  const st = await chrome.storage.session.get({ ptRunning: null });
  return st.ptRunning;
}

/* ---------- действия от widget-а / options ---------- */

async function timeStatus() {
  const r = await apiFetch('/api/time/running');
  if (r.status === 401) { await setRunning(null); return { connected: false }; }
  if (!r.ok) {
    // мрежова грешка — връщаме каквото знаем, без да сваляме connected
    return { connected: true, entry: await getRunningCached(), todaySeconds: null, offline: true };
  }
  await setRunning(r.data.entry);
  return { connected: true, entry: r.data.entry, todaySeconds: r.data.todaySeconds };
}

/* Кой работи в момента (всички вървящи таймери в екипа). Ползва се от прозорчето,
   за да се вижда, че по същата задача вече работи някой — и от колко време.
   Мрежова грешка не е фатална: прозорчето просто не показва списъка. */
async function timeActive() {
  const r = await apiFetch('/api/time/active');
  if (r.status === 401) return { connected: false };
  if (!r.ok) return { connected: true, active: null };
  return { connected: true, active: Array.isArray(r.data) ? r.data : [] };
}

async function timeStart(task) {
  const r = await apiFetch('/api/time/start', { method: 'POST', body: task });
  if (r.status === 401) return { connected: false };
  if (!r.ok) return { connected: true, error: (r.data && r.data.error) || 'Грешка при старт' };
  await setRunning(r.data.entry);
  return { connected: true, entry: r.data.entry, todaySeconds: r.data.todaySeconds };
}

async function timeStop(reason) {
  const r = await apiFetch('/api/time/stop', { method: 'POST', body: { reason: reason || 'user' } });
  if (r.status === 401) { await setRunning(null); return { connected: false }; }
  if (!r.ok) return { connected: true, error: (r.data && r.data.error) || 'Грешка при стоп' };
  await setRunning(null);
  return { connected: true, entry: null, todaySeconds: r.data.todaySeconds };
}

/* Ръчно добавено време — за забравен Старт. Изпратеният отрязък свършва „сега",
   а започва толкова назад, колкото е въведено; сървърът го маркира като ръчен. */
async function timeManual(entry) {
  const r = await apiFetch('/api/time/manual', { method: 'POST', body: entry || {} });
  if (r.status === 401) return { connected: false };
  if (!r.ok) return { connected: true, error: (r.data && r.data.error) || 'Грешка при добавяне' };
  return { connected: true, added: r.data || null };
}

/* ---------- бутон „✓ Готово" ----------
   Отделно от таймера: не мери време, само пази кой САМ е казал „аз я направих"
   и кога — за отчета по човек/ден/седмица/месец в платформата. */
async function taskDoneStatus(cardId) {
  const r = await apiFetch('/api/task-completions/status?bc_card_id=' + encodeURIComponent(cardId));
  if (r.status === 401) return { connected: false };
  if (!r.ok) return { connected: true, done: null };
  return { connected: true, done: Boolean(r.data && r.data.done) };
}

async function taskDoneToggle(task) {
  const r = await apiFetch('/api/task-completions/toggle', { method: 'POST', body: task || {} });
  if (r.status === 401) return { connected: false };
  if (!r.ok) return { connected: true, error: (r.data && r.data.error) || 'Грешка при отбелязване' };
  return { connected: true, done: Boolean(r.data && r.data.done) };
}

async function platformConnect() {
  const r = await apiFetch('/api/extension/token', {
    method: 'POST',
    useCookies: true,
    body: { label: 'The Pact Tools' }
  });
  if (!r.ok || !r.data || !r.data.token) {
    return { ok: false, status: r.status };
  }
  await chrome.storage.sync.set({ ptToken: r.data.token, ptTokenName: r.data.name || '' });
  return { ok: true, name: r.data.name || '' };
}

async function platformDisconnect() {
  await chrome.storage.sync.remove(['ptToken', 'ptTokenName']);
  await setRunning(null);
  return { ok: true };
}

/* ---------- пулс + авто-стоп при затворен Basecamp ---------- */

/* Има ли отворен таб с Basecamp — по ЖИВА ВРЪЗКА, не по chrome.tabs.query.
   Защо: заявката с url филтър иска права над basecamp.com, а разширението няма
   такива (в manifest-а стои само thepact.pro). Тя не гърми — връща празен
   списък. Оттам таймерът решаваше, че табът е затворен, и се спираше сам още на
   първия такт: записите излизаха с 0 секунди и stopped_by='unload'.
   Сега всеки Basecamp таб държи отворен канал (`pt-alive`). Падне ли, значи
   табът е затворен или работникът е заспал — затова се пази и последният момент
   с жив таб, а спираме чак след гратисния период (презареждане, навигация). */

const ALIVE_GRACE_MS = 90 * 1000;
const livePorts = new Set();

async function markAlive() {
  try { await chrome.storage.session.set({ ptAliveAt: Date.now() }); } catch (e) { /* ignore */ }
}

async function basecampPresent() {
  if (livePorts.size > 0) { await markAlive(); return true; }
  /* Работникът може току-що да е събуден от алармата и връзките още да не са се
     възстановили — затова решава последният известен момент с жив таб. */
  const st = await chrome.storage.session.get({ ptAliveAt: 0 });
  return (Date.now() - (Number(st.ptAliveAt) || 0)) < ALIVE_GRACE_MS;
}

async function stopIfNoTabs() {
  if (livePorts.size > 0) return;
  const running = await getRunningCached();
  if (!running) return;
  if (await basecampPresent()) return;
  await timeStop('unload');
}

chrome.runtime.onConnect.addListener((port) => {
  if (!port || port.name !== 'pt-alive') return;
  livePorts.add(port);
  markAlive();
  port.onDisconnect.addListener(() => {
    void chrome.runtime.lastError;
    livePorts.delete(port);
    if (livePorts.size === 0) setTimeout(() => { stopIfNoTabs(); }, ALIVE_GRACE_MS);
  });
});

async function beatTick() {
  const running = await getRunningCached();
  if (!running) { chrome.alarms.clear(BEAT_ALARM); return; }
  if (!(await basecampPresent())) {
    /* Няма потвърден отворен таб — но НЕ спираме насила. Табът може да е
       замразен от Chrome или тъкмо да се свързва наново след приспиване на
       работника. Просто спираме да пулсираме: върне ли се, пулсът продължава
       и таймерът си върви; ако наистина го няма, sweeper-ът затваря записа до
       ПОСЛЕДНИЯ пулс, тоест до момента, в който Basecamp е бил отворен.
       Бързото спиране при затворен таб си остава в stopIfNoTabs(). */
    return;
  }
  const r = await apiFetch('/api/time/beat', { method: 'POST' });
  if (r.status === 404 || r.status === 401) await setRunning(null); // спрян другаде / изключен
  else if (r.ok && r.data) await chrome.storage.session.set({ ptRunning: r.data.entry });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === BEAT_ALARM) beatTick();
});

/* Затварянето на таб се усеща по падналия канал (виж onConnect по-горе);
   chrome.tabs слушател не трябва — и без права над basecamp.com не върши работа. */

/* ---------- съобщения от content скриптовете ---------- */

/* ---------- кой е кой (за „кой редактира сега") ----------
   Разширението разчита имената от самия Basecamp, но това понякога пропада и в
   канала отиваше празно име — колегите виждаха „Колега". Платформата вече знае
   и мен (токенът е издаден от моята сесия), и целия екип (снапшота bc_people),
   затова питаме нея. Имената се кешират, за да не се пита при всяко рисуване. */

async function platformMe() {
  const r = await apiFetch('/api/extension/me');
  if (!r.ok || !r.data) return { name: '', basecampUserId: '' };
  return { name: r.data.name || '', basecampUserId: r.data.basecampUserId || '' };
}

async function platformPeople(ids) {
  const want = (Array.isArray(ids) ? ids : [])
    .map((x) => String(x || '').replace(/\D/g, ''))
    .filter(Boolean)
    .slice(0, 50);
  if (!want.length) return {};

  const st = await chrome.storage.session.get({ ptPeople: {} });
  const cache = st.ptPeople && typeof st.ptPeople === 'object' ? st.ptPeople : {};
  const missing = want.filter((id) => !cache[id]);
  if (missing.length) {
    const r = await apiFetch('/api/extension/people?ids=' + encodeURIComponent(missing.join(',')));
    if (r.ok && r.data && typeof r.data === 'object') {
      Object.assign(cache, r.data);
      await chrome.storage.session.set({ ptPeople: cache });
    }
  }
  const out = {};
  for (const id of want) if (cache[id]) out[id] = cache[id];
  return out;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;

  if (msg.type === 'pt-notify') {
    handleNotify(msg, sender);
    return;
  }

  if (msg.type === 'pt-who') {
    const run = async () => {
      if (msg.action === 'me') return platformMe();
      if (msg.action === 'people') return { names: await platformPeople(msg.ids) };
      return { error: 'unknown action' };
    };
    run().then(sendResponse).catch((e) => sendResponse({ error: String((e && e.message) || e) }));
    return true;
  }

  if (msg.type === 'pt-time') {
    const run = async () => {
      if (msg.action === 'status') return timeStatus();
      if (msg.action === 'active') return timeActive();
      if (msg.action === 'start') return timeStart(msg.task || {});
      if (msg.action === 'stop') return timeStop(msg.reason);
      if (msg.action === 'manual') return timeManual(msg.entry || {});
      if (msg.action === 'connect') return platformConnect();
      if (msg.action === 'disconnect') return platformDisconnect();
      return { error: 'unknown action' };
    };
    run().then(sendResponse).catch((e) => sendResponse({ error: String((e && e.message) || e) }));
    return true; // асинхронен отговор
  }

  if (msg.type === 'pt-done') {
    const run = async () => {
      if (msg.action === 'status') return taskDoneStatus(msg.bc_card_id);
      if (msg.action === 'toggle') {
        return taskDoneToggle({
          bc_project_id: msg.bc_project_id, bc_card_id: msg.bc_card_id,
          title: msg.title, url: msg.url
        });
      }
      return { error: 'unknown action' };
    };
    run().then(sendResponse).catch((e) => sendResponse({ error: String((e && e.message) || e) }));
    return true;
  }
});
