/* The Pact Tools — функция „Бутоните за запазване вървят с екрана".
 *
 * В edit режим бутоните Save / Never mind стоят чак най-долу под формата. При
 * дълга задача това значи скролване надолу за запазване и нагоре обратно.
 *
 * Затова: докато истинските бутони са извън екрана, най-долу се показва тънка
 * лента със СЪЩИТЕ бутони. Нарочно КОПИЯ, а не самите бутони — местенето на
 * чужди елементи чупи скриптовете на Basecamp (научено при закачането на полето
 * за коментар). Копието пази класовете на Basecamp, значи изглежда точно като
 * оригинала, а кликът се препраща на истинския бутон, тоест запазването минава
 * по техния път. Оригиналните бутони остават непокътнати и работят както винаги.
 */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__editBarLoaded) return;
  PT.__editBarLoaded = true;

  const BAR_ID = 'pt-editbar';
  const MAX_NAV_H = 140;   /* по-високо от това не е лента с бутони, а секция */

  /* ---------- намиране на формата и бутоните ѝ ---------- */

  const visible = (el) => {
    try { return !!el && el.getClientRects().length > 0; } catch (e) { return false; }
  };

  /* Формата за редакция: изпраща PATCH/PUT към запис (или сме на .../edit) и
     има бутон за запазване. Същият признак, по който работи и „кой редактира". */
  function editForm() {
    const onEditUrl = /\/edit$/.test(location.pathname);
    for (const f of document.querySelectorAll('form[action*="/buckets/"]')) {
      const m = f.querySelector('input[name="_method"]');
      const mv = m ? String(m.value || '').toLowerCase() : '';
      if (!onEditUrl && mv !== 'patch' && mv !== 'put') continue;
      if (!f.querySelector('input[type="submit"], button[type="submit"]')) continue;
      if (!visible(f)) continue;
      return f;
    }
    return null;
  }

  /* Редът с бутоните — при Basecamp е <footer class="submit-buttons">. Ако го
     преименуват, падаме на родителя на бутона за запазване. */
  function actionsOf(form) {
    const submit = form.querySelector('input[type="submit"], button[type="submit"]');
    if (!submit) return null;
    const box = submit.closest('.submit-buttons, .form__actions, footer');
    return (box && form.contains(box)) ? box : submit.parentElement;
  }

  const CLICKABLE = 'button, input[type="submit"], input[type="button"], a[href]';

  /* ---------- къде да застане лентата ---------- */

  /* Basecamp държи най-долу закована лента („My Tasks", „My Events", …).
     Нашата стои НАД нея, за да не я закрива. */
  function bottomNavHeight() {
    let h = 0;
    const sel = 'nav, footer, [role="navigation"], [class*="bottom"], [class*="jump"], [class*="toolbar"]';
    let nodes;
    try { nodes = document.querySelectorAll(sel); } catch (e) { return 0; }
    for (const el of nodes) {
      if (el.id === BAR_ID || el.closest('#' + BAR_ID)) continue;
      let cs;
      try { cs = getComputedStyle(el); } catch (e) { continue; }
      if (cs.position !== 'fixed' && cs.position !== 'sticky') continue;
      const r = el.getBoundingClientRect();
      if (!r.height || r.height > MAX_NAV_H || !r.width) continue;
      /* трябва да е долепена за долния ръб на екрана */
      if (r.bottom < window.innerHeight - 4 || r.top > window.innerHeight) continue;
      h = Math.max(h, Math.round(r.height));
    }
    return h;
  }

  /* Истинските бутони виждат ли се в момента (тогава лентата е излишна). */
  function actionsInView(actions) {
    const r = actions.getBoundingClientRect();
    if (!r.height) return false;
    return r.bottom > 0 && r.top < window.innerHeight - bottomNavHeight();
  }

  /* ---------- самата лента ---------- */

  let state = null;   /* { bar, form, actions, pairs } */

  function removeBar() {
    if (!state) return;
    try { state.bar.remove(); } catch (e) { /* ignore */ }
    state = null;
  }

  function buildBar(form, actions) {
    const bar = document.createElement('div');
    bar.id = BAR_ID;
    bar.className = 'pt-editbar';

    const inner = actions.cloneNode(true);
    /* копието не бива да се представя за оригинала пред скриптовете на Basecamp */
    for (const el of [inner, ...inner.querySelectorAll('*')]) {
      el.removeAttribute('id');
      el.removeAttribute('name');
      el.removeAttribute('data-turbo-submits-with');
      for (const a of [...el.attributes]) {
        if (a.name.toLowerCase().indexOf('on') === 0) el.removeAttribute(a.name);
      }
    }
    bar.appendChild(inner);

    /* всеки бутон в копието сочи към своя оригинал по ред на поява */
    const originals = [...actions.querySelectorAll(CLICKABLE)];
    const copies = [...inner.querySelectorAll(CLICKABLE)];
    const pairs = [];
    copies.forEach((copy, i) => {
      const orig = originals[i];
      if (!orig) { copy.remove(); return; }
      pairs.push({ copy, orig });
      copy.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        /* кликът минава по пътя на Basecamp — истинският бутон, истинската форма */
        try { orig.click(); } catch (err) { /* ignore */ }
      });
    });
    if (!pairs.length) return null;

    bar.style.backgroundColor = PT.pageBackground();
    (document.body || document.documentElement).appendChild(bar);
    return { bar, form, actions, pairs };
  }

  /* Лентата стои точно над оригиналната форма по ширина — „колкото е фонът на
     самата задача", а не през целия екран. */
  function place() {
    if (!state) return;
    const r = state.form.getBoundingClientRect();
    const width = Math.max(240, Math.round(r.width));
    const left = Math.round(Math.min(Math.max(r.left, 4), Math.max(4, window.innerWidth - width - 4)));
    state.bar.style.left = left + 'px';
    state.bar.style.width = width + 'px';
    state.bar.style.bottom = (bottomNavHeight() + 8) + 'px';
  }

  function sync() {
    const form = editForm();
    if (!form) { removeBar(); return; }
    const actions = actionsOf(form);
    if (!actions) { removeBar(); return; }

    /* формата е сменена (друга задача, пре-рендер) → строим наново */
    if (state && (state.form !== form || state.actions !== actions || !state.bar.isConnected)) removeBar();
    if (!state) {
      state = buildBar(form, actions);
      if (!state) return;
    }

    /* когато истинските бутони се виждат, лентата се маха — да не се дублира */
    const need = !actionsInView(actions);
    state.bar.classList.toggle('pt-editbar--on', need);
    if (need) place();
  }

  const guard = PT.safe ? PT.safe(sync) : sync;

  PT.start(() => {
    if (PT.cfg.features.editBar === false) return;
    guard();
    PT.onDomChange(guard);
    PT.onNav(guard);
    window.addEventListener('scroll', guard, { passive: true, capture: true });
    window.addEventListener('resize', guard);
    if (PT.onOrphan) PT.onOrphan(removeBar);
  });
})();
