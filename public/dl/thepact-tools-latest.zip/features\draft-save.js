/* The Pact Tools — функция „Незапазен текст“.
 *
 * Повод: колега цъкна „Never mind“ без да иска, докато пишеше в задача, и
 * изгуби всичко написано — Basecamp няма как да го върне. Тук пазим само
 * ТЕКСТА (без снимки/файлове/прикачени неща — тях няма как да върнем), докато
 * човек пише в кое да е поле на Basecamp (Trix редактор или textarea) вътре
 * във форма — работи за задачи, карти, съобщения, документи, коментари,
 * въпроси/отговори и т.н., без да гледаме от какъв тип е записът.
 *
 * Пазим локално на браузъра (chrome.storage.local — преживява и рестарт на
 * браузъра/компютъра, не само презареждане на таба), до 24 часа. Ако
 * действителният бутон за запазване се натисне (формата се изпрати), пазената
 * чернова се трие — значи е стигнала до Basecamp. „Never mind“/затворен таб/
 * забил браузър НЕ изпращат формата, затова черновата остава и следващия път,
 * когато отвориш същото поле, излиза лента „Възстанови“. */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__draftSaveLoaded) return;
  PT.__draftSaveLoaded = true;

  const TTL_MS = 24 * 3600000;
  const SAVE_DEBOUNCE_MS = 1500;
  const MIN_CHARS = 2;
  const PREFIX = 'ptDraft:';

  /* ---------- малки помощни функции ---------- */

  function hashKey(s) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h.toString(36);
  }

  function plainText(html) {
    try {
      const tmp = document.createElement('div');
      tmp.innerHTML = html || '';
      return (tmp.textContent || '').replace(/\s+/g, ' ').trim();
    } catch (e) {
      return String(html || '').trim();
    }
  }

  /* сваля прикачени файлове/снимки от HTML-а — пазим само текста */
  function stripAttachments(html) {
    try {
      const tmp = document.createElement('div');
      tmp.innerHTML = html || '';
      tmp.querySelectorAll('action-text-attachment, figure, img').forEach((n) => n.remove());
      return tmp.innerHTML;
    } catch (e) {
      return html || '';
    }
  }

  const storageGet = (key) => new Promise((resolve) => {
    try {
      chrome.storage.local.get(key, (obj) => { void chrome.runtime.lastError; resolve(obj || {}); });
    } catch (e) { resolve({}); }
  });
  const storageSet = (obj) => {
    try { chrome.storage.local.set(obj, () => { void chrome.runtime.lastError; }); } catch (e) { /* ignore */ }
  };
  const storageRemove = (keys) => {
    try { chrome.storage.local.remove(keys, () => { void chrome.runtime.lastError; }); } catch (e) { /* ignore */ }
  };

  /* ---------- кое поле какво пази ---------- */

  function fieldName(el) {
    if (el.tagName === 'TEXTAREA') return el.getAttribute('name') || el.id || '';
    const inputId = el.getAttribute('input');
    const hidden = inputId ? document.getElementById(inputId) : null;
    return (hidden && (hidden.getAttribute('name') || hidden.id)) || el.id || '';
  }

  function fieldKey(el, form) {
    const scope = (form && form.getAttribute('action')) || location.pathname;
    return hashKey(scope + '|' + fieldName(el));
  }

  function getContent(el) {
    if (el.tagName === 'TEXTAREA') return el.value || '';
    const inputId = el.getAttribute('input');
    const hidden = inputId ? document.getElementById(inputId) : null;
    return (hidden ? hidden.value : el.innerHTML) || '';
  }

  function setContent(el, html) {
    if (el.tagName === 'TEXTAREA') {
      el.value = html;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }
    try {
      if (el.editor && typeof el.editor.loadHTML === 'function') {
        el.editor.loadHTML(html);
        return;
      }
    } catch (e) { /* ignore */ }
    el.innerHTML = html;
  }

  /* ---------- лентата „Възстанови“ ---------- */

  function timeAgo(at) {
    const mins = Math.max(1, Math.round((Date.now() - at) / 60000));
    if (mins < 60) return mins + ' мин';
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return h + ' ч' + (m ? ' и ' + m + ' мин' : '');
  }

  function showBanner(el, st, rec) {
    if (st.banner && st.banner.isConnected) return;
    const bar = document.createElement('div');
    bar.className = 'pt-draft-banner';

    const text = document.createElement('span');
    text.className = 'pt-draft-text';
    text.textContent = '📝 Намерихме незапазен текст от преди ' + timeAgo(rec.at) + '.';

    const restore = document.createElement('button');
    restore.type = 'button';
    restore.className = 'pt-draft-restore';
    restore.textContent = 'Възстанови';
    restore.addEventListener('click', PT.safe((e) => {
      e.preventDefault();
      setContent(el, rec.html);
      st.baseline = stripAttachments(getContent(el));
      bar.remove();
      st.banner = null;
    }));

    const dismiss = document.createElement('button');
    dismiss.type = 'button';
    dismiss.className = 'pt-bx';
    dismiss.title = 'Скрий';
    dismiss.textContent = '✕';
    dismiss.addEventListener('click', PT.safe((e) => {
      e.preventDefault();
      removeDraft(st.key);
      bar.remove();
      st.banner = null;
    }));

    bar.append(text, restore, dismiss);
    if (el.parentNode) el.parentNode.insertBefore(bar, el);
    st.banner = bar;
  }

  function removeDraft(key) {
    storageRemove(PREFIX + key);
  }

  /* ---------- пазене на чернова ---------- */

  function saveDraft(el, st) {
    const html = stripAttachments(getContent(el));
    const text = plainText(html);
    if (text.length < MIN_CHARS) return;
    if (text === plainText(st.baseline)) { removeDraft(st.key); return; }
    storageSet({ [PREFIX + st.key]: { html: html, at: Date.now(), url: location.href } });
  }

  async function checkExistingDraft(el, st) {
    const storageKey = PREFIX + st.key;
    const obj = await storageGet(storageKey);
    const rec = obj[storageKey];
    if (!rec || !rec.html) return;
    if (Date.now() - Number(rec.at || 0) > TTL_MS) { removeDraft(st.key); return; }
    if (plainText(rec.html) === plainText(st.baseline)) return;
    if (!document.body.contains(el)) return;
    showBanner(el, st, rec);
  }

  /* ---------- закачане към полетата на страницата ---------- */

  const wired = new Map(); /* el -> state */

  function clearFormDrafts(form) {
    wired.forEach((st) => { if (st.form === form) removeDraft(st.key); });
  }

  function wire(el) {
    if (wired.has(el)) return;
    const form = el.closest('form');
    if (!form) return;

    const st = { key: fieldKey(el, form), form: form, baseline: stripAttachments(getContent(el)), timer: null, banner: null };
    wired.set(el, st);
    checkExistingDraft(el, st).catch(() => {});

    const onChange = PT.safe(() => {
      clearTimeout(st.timer);
      st.timer = setTimeout(PT.safe(() => saveDraft(el, st)), SAVE_DEBOUNCE_MS);
    });
    el.addEventListener(el.tagName === 'TEXTAREA' ? 'input' : 'trix-change', onChange);

    if (!form.__ptDraftSubmitWired) {
      form.__ptDraftSubmitWired = true;
      /* капиращо, преди Turbo да смени страницата — реалният Save мина, значи текстът стигна до Basecamp */
      form.addEventListener('submit', PT.safe(() => clearFormDrafts(form)), true);
    }
  }

  function scan() {
    wired.forEach((st, el) => { if (!document.body.contains(el)) wired.delete(el); });
    document.querySelectorAll('trix-editor, textarea').forEach(wire);
  }

  /* ---------- чистене на изтекли чернови (пазени за затворени вече страници) ---------- */

  function pruneExpired() {
    try {
      chrome.storage.local.get(null, (all) => {
        void chrome.runtime.lastError;
        if (!all) return;
        const stale = Object.keys(all).filter((k) => {
          if (k.indexOf(PREFIX) !== 0) return false;
          const rec = all[k];
          return !rec || (Date.now() - Number(rec.at || 0) > TTL_MS);
        });
        if (stale.length) storageRemove(stale);
      });
    } catch (e) { /* ignore */ }
  }

  /* ---------- старт ---------- */

  PT.start(() => {
    if (PT.cfg.features.draftSave === false) return;
    scan();
    PT.onDomChange(scan);
    PT.onNav(scan);
    pruneExpired();
    setInterval(PT.safe(pruneExpired), 3600000);
    if (PT.onOrphan) PT.onOrphan(() => { wired.forEach((st) => { if (st.banner) st.banner.remove(); }); wired.clear(); });
  });
})();
