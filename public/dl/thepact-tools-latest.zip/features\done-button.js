/* The Pact Tools — кръглата отметка „✓ Готово".
 *
 * Замени прозорчето за следене на време (Венци, 19.11.2026: „на този етап
 * преминаваме към това да следим само изпълнена задача"; избран вариант 2 от
 * thepact.pro/demo/done-designs.html). Остава само едно кръгче в ъгъла:
 *   - празно (на пунктир) = не си я отбелязал; цъкаш → става зелено ✓;
 *     цъкаш пак → маха се (превключвател, за грешно цъкване);
 *   - задържиш и влачиш → местиш го; мястото се помни за ЧОВЕКА (chrome.storage
 *     .sync върви с Chrome профила) и стои там, докато сам не го преместиш;
 *   - посочиш с мишката → кой е отбелязал задачата и от кой отдел
 *     („Pre-Production - Ventsislav Kalchev").
 * Самата отметка е лична: зеленото кръгче вижда само този, който е цъкнал.
 * Логиката е непроменена — платформата пази отметката по номер ИЛИ по заглавие,
 * затова не се губи при местене на картата в друг отдел.
 */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__doneLoaded) return;
  PT.__doneLoaded = true;

  const TRACKABLE = new Set(['todos', 'cards']);
  const PLATFORM_URL = 'https://thepact.pro';
  const POS_KEY = 'ptDonePos';

  /* ---------- връзка със service worker-а ----------
     Осиротял скрипт (разширението е обновено) — chrome.runtime е мъртъв и всяко
     извикване връща lastError. Четем го винаги, иначе Chrome сипе „Unchecked
     runtime.lastError" в конзолата и Basecamp вдига банера си за грешка. */
  let dead = false;
  const orphaned = () => {
    if (typeof PT.alive === 'function') return !PT.alive();
    try { return !(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return true; }
  };

  const send = (msg) => new Promise((resolve) => {
    if (dead) { resolve(null); return; }
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        if (chrome.runtime.lastError) {
          if (orphaned()) dead = true;   /* иначе е временно — работникът спи */
          resolve(null);
          return;
        }
        resolve(r || null);
      });
    } catch (e) {
      if (orphaned()) dead = true;
      resolve(null);
    }
  });

  /* „Пусни и забрави" async извикване не бива да остави отхвърлен Promise —
     изтича като грешка на страницата и Basecamp вдига банера „isn't fully
     functional". console.debug не е грешка. */
  const bg = (task) => Promise.resolve(task).catch((e) => {
    try { console.debug('[The Pact Tools] готово:', e); } catch (err) { /* ignore */ }
  });

  /* ---------- текущата задача ---------- */

  function pageTask() {
    const m = location.pathname.match(/\/buckets\/(\d+)\/((?:[a-z_]+\/)*[a-z_]+)\/(\d+)(?:\/edit)?$/);
    if (!m) return null;
    const segs = m[2].split('/');
    const type = segs[segs.length - 1];
    if (!TRACKABLE.has(type)) return null;
    return { bucket: m[1], type, rid: m[3] };
  }

  /* Първият <h1> НЕ става за заглавие: Basecamp държи скрит
     `section.system-degradations-banner` с <h1>„Basecamp isn't fully functional
     right now." — пръв по ред. Затова само видими заглавия, извън нашия слой и
     извън чужди известия. */
  const TITLE_SKIP = '#pt-layer, .system-degradations-banner, [class*="degradation"], [role="alert"], [role="status"]';

  function pickTitle(sel) {
    let nodes;
    try { nodes = document.querySelectorAll(sel); } catch (e) { return ''; }
    for (const el of nodes) {
      try {
        if (el.closest(TITLE_SKIP)) continue;
        if (!el.getClientRects().length) continue;
      } catch (e) { continue; }
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (t.length >= 2) return t;
    }
    return '';
  }

  function taskTitle() {
    let t = pickTitle('main h1, [data-recording-id] h1, article h1, .recording h1');
    if (!t) t = pickTitle('h1');
    if (!t) t = (document.title || '').split(/\s*[—|•|·]\s*/)[0].trim();
    return t.slice(0, 300);
  }
  PT.taskTitle = taskTitle;   /* ползва го и „Важно за всички" */

  /* ---------- състояние ---------- */

  /* connected: null = още не знаем; done: null = още не е прочетено */
  const state = { connected: null, done: null, who: [], busy: false };
  let rid = '';

  async function load(task) {
    /* заглавието идва малко след адреса — по него отметката се намира и след
       местене на картата в друг отдел, затова го чакаме до ~5 сек */
    let title = taskTitle();
    for (let i = 0; i < 5 && !title; i++) {
      await new Promise((ok) => setTimeout(ok, 1000));
      title = taskTitle();
    }
    if (rid !== task.rid) return;   /* междувременно е отворена друга задача */
    const r = await send({
      type: 'pt-done', action: 'status', bc_card_id: task.rid,
      title: title, url: location.href.split('#')[0]
    });
    if (rid !== task.rid || !r) return;
    if (r.connected === false) {
      state.connected = false;
    } else if (typeof r.done === 'boolean') {
      state.connected = true;
      state.done = r.done;
      state.who = Array.isArray(r.who) ? r.who : [];
    }
    render();
  }

  async function toggle() {
    const task = pageTask();
    if (!task || state.busy) return;
    state.busy = true;
    render();
    const r = await send({
      type: 'pt-done', action: 'toggle',
      bc_project_id: task.bucket, bc_card_id: task.rid,
      title: taskTitle(), url: location.href.split('#')[0]
    });
    state.busy = false;
    if (r && r.connected === false) state.connected = false;
    else if (r && typeof r.done === 'boolean') {
      state.done = r.done;
      if (r.done) pop = true;
      bg(load(task));   /* списъкът „кой я е отбелязал" — с мен вътре или без мен */
    }
    render();
  }

  async function connect() {
    if (state.busy) return;
    state.busy = true;
    render();
    const r = await send({ type: 'pt-time', action: 'connect' });
    state.busy = false;
    if (r && r.ok) {
      state.connected = true;
      const task = pageTask();
      if (task) bg(load(task));
    } else {
      try { window.open(PLATFORM_URL, '_blank'); } catch (e) { /* ignore */ }
    }
    render();
  }

  /* ---------- къде стои кръгчето ----------
     Пазим разстоянието до НАЙ-БЛИЗКИТЕ ръбове (напр. „24px от десния, 90px от
     долния"), а не голи координати — така на по-малък или по-голям екран
     кръгчето остава в същия ъгъл, където човекът си го е сложил. */

  const SIZE = 56;
  let pos = { h: 'right', x: 24, v: 'bottom', y: 90 };

  const prefsReady = new Promise((resolve) => {
    try {
      chrome.storage.sync.get({ [POS_KEY]: null }, (st) => {
        if (!chrome.runtime.lastError && st && st[POS_KEY] && typeof st[POS_KEY] === 'object') {
          pos = Object.assign({}, pos, st[POS_KEY]);
        }
        resolve();
      });
    } catch (e) { resolve(); }
  });

  function savePos() {
    try {
      chrome.storage.sync.set({ [POS_KEY]: pos }, () => { void chrome.runtime.lastError; });
    } catch (e) { /* ignore */ }
  }

  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  function applyPos(box) {
    const maxX = Math.max(0, window.innerWidth - SIZE);
    const maxY = Math.max(0, window.innerHeight - SIZE);
    const x = clamp(Number(pos.x) || 0, 0, maxX);
    const y = clamp(Number(pos.y) || 0, 0, maxY);
    box.style.left = (pos.h === 'right' ? maxX - x : x) + 'px';
    box.style.top = (pos.v === 'bottom' ? maxY - y : y) + 'px';
    box.classList.toggle('pt-done--left', pos.h !== 'right');
    box.classList.toggle('pt-done--top', pos.v !== 'bottom');
  }

  function posFromPoint(left, top) {
    const maxX = Math.max(0, window.innerWidth - SIZE);
    const maxY = Math.max(0, window.innerHeight - SIZE);
    left = clamp(left, 0, maxX);
    top = clamp(top, 0, maxY);
    const right = left + SIZE / 2 > window.innerWidth / 2;
    const bottom = top + SIZE / 2 > window.innerHeight / 2;
    return {
      h: right ? 'right' : 'left', x: Math.round(right ? maxX - left : left),
      v: bottom ? 'bottom' : 'top', y: Math.round(bottom ? maxY - top : top)
    };
  }

  /* задържане и влачене мести; кратък клик цъква. Местенето тръгва чак след
     4 пиксела, за да не се обърка с клик. */
  let lastDragEnd = 0;

  function enableDrag(box, handle) {
    handle.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      const r = box.getBoundingClientRect();
      const offX = e.clientX - r.left;
      const offY = e.clientY - r.top;
      let moved = false;
      const onMove = (ev) => {
        if (!moved && Math.abs(ev.clientX - e.clientX) < 4 && Math.abs(ev.clientY - e.clientY) < 4) return;
        if (!moved) { moved = true; box.classList.add('pt-done--dragging'); }
        pos = posFromPoint(ev.clientX - offX, ev.clientY - offY);
        applyPos(box);
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        box.classList.remove('pt-done--dragging');
        if (moved) { lastDragEnd = Date.now(); savePos(); }
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
      e.preventDefault();   /* без маркиране на текст, докато влачиш */
    });
  }

  /* ---------- рисуване ---------- */

  let pop = false;   /* кратко „подскачане" при отбелязване */

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function tipContent(tip) {
    tip.innerHTML = '';
    if (state.connected === false) {
      tip.append(el('div', 'pt-done__tip-head', 'Свържи с платформата'));
      tip.append(el('div', 'pt-done__tip-note', 'Цъкни, за да свържеш разширението с thepact.pro — после отбелязваш с едно цъкване.'));
      return;
    }
    tip.append(el('div', 'pt-done__tip-head', state.done
      ? '✓ Отбелязал си я като готова'
      : 'Отбележи като готово'));
    tip.append(el('div', 'pt-done__tip-note', state.done
      ? 'Цъкни пак, ако е по грешка · задръж и влачи, за да преместиш'
      : 'Цъкни, щом си свършил своята част · задръж и влачи, за да преместиш'));
    if (state.who.length) {
      const list = el('div', 'pt-done__who');
      list.append(el('div', 'pt-done__who-head', 'Отбелязали:'));
      state.who.forEach((w) => {
        const row = el('div', 'pt-done__who-row');
        const dept = String(w.department || '').trim();
        if (dept) row.append(el('span', 'pt-done__dept', dept + ' - '));
        row.append(el('span', 'pt-done__name', (w.name || 'Някой') + (w.me ? ' (ти)' : '')));
        list.append(row);
      });
      tip.append(list);
    }
  }

  function render() {
    if (PT.cfg.features.timeTracker === false) return;
    const old = document.getElementById('pt-done');
    if (dead) { if (old) old.remove(); return; }

    const task = pageTask();
    if (task && task.rid !== rid) {
      rid = task.rid;
      state.done = null;
      state.who = [];
      bg(load(task));
    } else if (!task) {
      rid = '';
    }

    /* само на задача/карта и чак когато знаем състоянието — без премигване */
    if (!task || (state.done === null && state.connected !== false)) {
      if (old) old.style.display = 'none';
      return;
    }

    const box = PT.sub('pt-done', 'pt-done');
    box.style.display = '';
    box.innerHTML = '';
    applyPos(box);

    const btn = el('button', 'pt-done__btn' +
      (state.done ? ' pt-done__btn--on' : '') +
      (state.connected === false ? ' pt-done__btn--off' : '') +
      (state.busy ? ' pt-done__btn--busy' : '') +
      (pop ? ' pt-done__btn--pop' : ''),
      state.connected === false ? '?' : '✓');
    pop = false;
    btn.type = 'button';
    btn.setAttribute('aria-label', state.done ? 'Отбелязано като готово — цъкни, за да махнеш' : 'Отбележи като готово');
    btn.setAttribute('aria-pressed', state.done ? 'true' : 'false');
    btn.addEventListener('click', () => {
      if (Date.now() - lastDragEnd < 250) return;   /* току-що го местихме */
      if (state.connected === false) bg(connect());
      else bg(toggle());
    });
    enableDrag(box, btn);

    const tip = el('div', 'pt-done__tip');
    tipContent(tip);
    box.append(tip, btn);
  }

  /* ---------- старт ---------- */

  Promise.all([PT.ready, prefsReady]).then(() => {
    if (PT.cfg.features.timeTracker === false) return;
    if (PT.onOrphan) PT.onOrphan(() => { dead = true; render(); });

    let lastPath = '';
    const onChange = () => {
      if (location.pathname === lastPath) return;
      lastPath = location.pathname;
      render();
    };
    PT.onNav(() => { lastPath = ''; onChange(); });
    PT.onDomChange(onChange);
    /* върнал си се в таба — някой колега може междувременно да е отбелязал */
    PT.onVisibility((visible) => {
      const task = pageTask();
      if (visible && task) bg(load(task));
    });
    window.addEventListener('resize', () => {
      const box = document.getElementById('pt-done');
      if (box) applyPos(box);
    });
    render();
  }).catch((e) => {
    try { console.debug('[The Pact Tools] стартът на „Готово" пропадна:', e); } catch (err) { /* ignore */ }
  });
})();
