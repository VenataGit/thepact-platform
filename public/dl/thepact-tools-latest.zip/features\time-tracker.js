/* The Pact Tools — тракване на време.
 * Плаващо прозорче долу вдясно: на страница на задача/карта дава Старт;
 * докато таймер върви, се вижда на всяка Basecamp страница с Пауза/Стоп и
 * брояч + "днес: Xч Yм". Всичко живее в платформата (thepact.pro) — заявките
 * минават през service worker-а (виж background.js). Един активен таймер на
 * човек: старт по нова задача автоматично спира предишния сегмент.
 *
 * Носи и бутона „✓ Готово" (отделен смисъл — кой САМ е казал „аз я направих",
 * независимо от таймера) — но в СЪЩОТО прозорче, не отделно (Венци,
 * 15.09.2026: много бутони на екрана, ако е разделено). */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__timeLoaded) return;
  PT.__timeLoaded = true;

  const TRACKABLE = new Set(['todos', 'cards']);
  const PLATFORM_URL = 'https://thepact.pro';

  /* Щом разширението се обнови или презареди, вече заредените content скриптове
     остават „осиротели": chrome.runtime за тях е мъртъв и всяко извикване връща
     lastError. Ако не се прочете, Chrome сипе „Unchecked runtime.lastError" в
     конзолата на страницата — а таймерът пита веднъж на 45 секунди, тоест шумът е
     постоянен. Затова четем lastError и при осиротял контекст спираме тихо и
     махаме widget-а, вместо да опитваме безкрайно. */
  let dead = false;

  /* Наистина ли е осиротял скриптът? Единственият надежден признак е дали
     `chrome.runtime` още го има.
     „Receiving end does not exist" НЕ значи това: MV3 работникът живее най-много
     5 минути и Chrome го приспива редовно, а заявка, попаднала точно в смяната,
     връща същата грешка. Докато се хващахме за текста ѝ, при първото приспиване
     скриптът се обявяваше за мъртъв: спираше да се свързва, каналът „жив таб"
     не се вдигаше и след 90 секунди работникът затваряше таймера с „затворен
     таб" — работещият таймер си спираше сам след около 5 минути. */
  const orphaned = () => {
    if (typeof PT.alive === 'function') return !PT.alive();
    try { return !(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return true; }
  };

  const send = (msg) => new Promise((resolve) => {
    if (dead) { resolve(null); return; }
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        const err = chrome.runtime.lastError;
        if (err) {
          if (orphaned()) dead = true;   /* иначе е временно — работникът спи */
          resolve(null);
          return;
        }
        resolve(r || null);
      });
    } catch (e) {
      if (orphaned()) dead = true;
      resolve(null);
    }
  });

  /* connected: null = още не знаем; false = няма токен → показваме "Свържи" */
  /* active = всички вървящи таймери в екипа (за „кой работи по тази задача"). */
  /* done: null = още не е прочетено за картата на екрана; true/false = знаем. */
  const state = { connected: null, entry: null, todaySeconds: null, busy: false, error: '', active: null, done: null };

  /* Настройките на прозорчето (свито/разгънато + къде стои) са в chrome.storage.sync:
     следват човека по машини и — за разлика от localStorage — не пишат нищо в
     собственото хранилище на Basecamp. */
  const DEFAULT_POS = { mode: 'preset', preset: 'br', x: 0, y: 0 };
  const PRESETS = {
    br: 'Долу вдясно', bl: 'Долу вляво', tr: 'Горе вдясно', tl: 'Горе вляво', bar: 'Лента горе'
  };
  const PRESET_ORDER = ['br', 'bl', 'tr', 'tl', 'bar'];

  let collapsed = false;
  let pos = Object.assign({}, DEFAULT_POS);

  const savePrefs = () => {
    /* с callback, за да не остане отхвърлен Promise при осиротял скрипт — виж PT.notify */
    try {
      chrome.storage.sync.set(
        { ptTimeCollapsed: collapsed, ptTimePos: pos },
        () => { void chrome.runtime.lastError; }
      );
    } catch (e) { /* ignore */ }
  };

  const prefsReady = new Promise((resolve) => {
    try {
      chrome.storage.sync.get({ ptTimeCollapsed: false, ptTimePos: null }, (st) => {
        if (!chrome.runtime.lastError && st) {
          collapsed = !!st.ptTimeCollapsed;
          if (st.ptTimePos && typeof st.ptTimePos === 'object') {
            pos = Object.assign({}, DEFAULT_POS, st.ptTimePos);
          }
        }
        resolve();
      });
    } catch (e) { resolve(); }
  });

  /* ---------- ръчно добавяне на време ----------
     Някой забравя да пусне Старт, а видеографите се връщат от снимки и отчитат
     наведнъж. Затова „＋ Добави" приема времето както човек го напише, а не по
     един зададен формат: 90 | 1:30 | 2ч | 2ч30 | 1.5ч. Голо число = минути. */

  function parseDuration(raw) {
    const s = String(raw || '').toLowerCase().replace(',', '.').trim();
    if (!s) return 0;

    const hm = s.match(/^(\d{1,2})\s*[:.](\d{1,2})$/);        /* 1:30 */
    if (hm) return (parseInt(hm[1], 10) * 60) + parseInt(hm[2], 10);

    const hAndM = s.match(/^(\d+(?:\.\d+)?)\s*(?:ч|h)\s*(\d{1,2})\s*(?:м|m|мин|min)?$/);   /* 2ч30 */
    if (hAndM) return Math.round(parseFloat(hAndM[1]) * 60) + parseInt(hAndM[2], 10);

    const hOnly = s.match(/^(\d+(?:\.\d+)?)\s*(?:ч|h|час|часа|hours?|hr)$/);               /* 2ч / 1.5ч */
    if (hOnly) return Math.round(parseFloat(hOnly[1]) * 60);

    const mOnly = s.match(/^(\d+(?:\.\d+)?)\s*(?:м|m|мин|min|минути)?$/);                  /* 90 / 90м */
    if (mOnly) return Math.round(parseFloat(mOnly[1]));

    return 0;
  }

  function fmtMinutes(mins) {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    if (!h) return m + ' мин';
    return h + ' ч' + (m ? ' и ' + m + ' мин' : '');
  }

  let adding = false;      /* отворено ли е полето за добавяне */
  let addError = '';
  /* Написаното се пази извън DOM-а: прозорчето се престроява на всеки 45 секунди
     (догонване със сървъра) и иначе текстът щеше да изчезва под пръстите. */
  let addRaw = '';
  let addNote = '';

  async function doAdd(raw, note) {
    const mins = parseDuration(raw);
    if (!mins) { addError = 'Напиши колко време: 90, 1:30 или 2ч.'; render(); return; }
    if (mins > 24 * 60) { addError = 'Най-много 24 часа наведнъж.'; render(); return; }

    const task = pageTask();
    if (!task) { addError = 'Отвори задачата, за която добавяш време.'; render(); return; }

    const ended = new Date();
    const started = new Date(ended.getTime() - mins * 60000);
    state.busy = true;
    addError = '';
    render();

    const r = await send({
      type: 'pt-time',
      action: 'manual',
      entry: {
        bc_project_id: task.bucket,
        bc_recording_id: task.rid,
        recording_type: task.type,
        title: taskTitle(),
        url: location.href,
        started_at: started.toISOString(),
        ended_at: ended.toISOString(),
        note: String(note || '').slice(0, 500)
      }
    });

    state.busy = false;
    if (!r) { addError = 'Няма връзка с разширението.'; render(); return; }
    if (r.connected === false) { state.connected = false; render(); return; }
    if (r.error) { addError = r.error; render(); return; }

    adding = false;
    addError = '';
    addRaw = '';
    addNote = '';
    addedNote = 'Добавени ' + fmtMinutes(mins);
    setTimeout(() => { addedNote = ''; render(); }, 6000);
    todayFetchedAt = 0;            /* днешното време да се прочете наново */
    bg(refresh());
  }

  let addedNote = '';   /* кратко потвърждение след добавяне */

  /* ---------- текущата страница ---------- */

  function pageTask() {
    const m = location.pathname.match(/\/buckets\/(\d+)\/((?:[a-z_]+\/)*[a-z_]+)\/(\d+)(?:\/edit)?$/);
    if (!m) return null;
    const segs = m[2].split('/');
    const type = segs[segs.length - 1];
    if (!TRACKABLE.has(type)) return null;
    return { bucket: m[1], type, rid: m[3] };
  }

  /* Първият <h1> в страницата НЕ става за заглавие на задачата.
     Basecamp държи в DOM-а `section.system-degradations-banner` с
     <h1>„Basecamp isn't fully functional right now."</h1> — обикновено СКРИТ
     (нулев размер), но пръв по ред. Точно него показваше прозорчето вместо името
     на задачата (и точно него пращаше към платформата при старт на таймер).
     Затова: само видими заглавия, извън нашия слой и извън чужди известия, и с
     предимство на тези в съдържанието на страницата. */

  const TITLE_SKIP = '#pt-layer, .system-degradations-banner, [class*="degradation"], [role="alert"], [role="status"]';

  function pickTitle(sel) {
    let nodes;
    try { nodes = document.querySelectorAll(sel); } catch (e) { return ''; }
    for (const el of nodes) {
      try {
        if (el.closest(TITLE_SKIP)) continue;
        if (!el.getClientRects().length) continue;   /* скрито — не е заглавие на нищо */
      } catch (e) { continue; }
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (t.length >= 2) return t;
    }
    return '';
  }

  function taskTitle() {
    let t = pickTitle('main h1, [data-recording-id] h1, article h1, .recording h1');
    if (!t) t = pickTitle('h1');
    if (!t) t = (document.title || '').split(/\s*[—|•|·]\s*/)[0].trim();
    return t.slice(0, 300);
  }
  PT.taskTitle = taskTitle;   /* ползва го и „Важно за всички" */

  /* ---------- форматиране ---------- */

  const pad = (n) => String(n).padStart(2, '0');

  function fmtClock(secs) {
    secs = Math.max(0, Math.floor(secs));
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return (h ? h + ':' : '') + pad(m) + ':' + pad(s);
  }

  function fmtToday(secs) {
    if (secs === null || secs === undefined) return '';
    secs = Math.max(0, Math.floor(secs));
    const h = Math.floor(secs / 3600);
    const m = Math.round((secs % 3600) / 60);
    if (!h && !m) return 'днес: 0м';
    return 'днес: ' + (h ? h + 'ч ' : '') + m + 'м';
  }

  function elapsedSeconds() {
    if (!state.entry) return 0;
    return (Date.now() - new Date(state.entry.startedAt).getTime()) / 1000;
  }

  /* Броячът "днес" включва вървящия таймер към момента на последния fetch;
     локално добавяме изтеклото оттогава, за да тиктака и той. */
  let todayFetchedAt = 0;

  function todayLive() {
    if (state.todaySeconds === null || state.todaySeconds === undefined) return null;
    let secs = state.todaySeconds;
    if (state.entry && todayFetchedAt) secs += (Date.now() - todayFetchedAt) / 1000;
    return secs;
  }

  /* ---------- действия ---------- */

  /* „Пусни и забрави" извикване на async функция оставя отхвърлен Promise, ако
     нещо вътре гръмне. Той изтича като грешка на страницата и Basecamp вдига
     банера „Basecamp isn’t fully functional right now." — и то на всеки 45
     секунди, защото толкова е тактът на догонването със сървъра. Затова всяко
     такова извикване минава оттук: грешката се поглъща (console.debug НЕ е
     грешка и не буди банера) и веднъж се праща в канала на екипа, за да се
     види коренът, вместо да се гадае. */
  let bgReported = false;
  const bg = (task) => Promise.resolve(task).catch((e) => {
    try { console.debug('[The Pact Tools] таймер:', e); } catch (err) { /* ignore */ }
    if (bgReported || !PT.dbRoot) return;
    bgReported = true;
    try {
      fetch(PT.dbRoot + '/timer-diag/' + encodeURIComponent(PT.personKey || 'anon') + '.json', {
        method: 'PUT',
        body: JSON.stringify({
          at: Date.now(), who: PT.myName(), ver: PT.version, host: location.host,
          page: location.pathname,
          msg: String((e && e.message) || e).slice(0, 300),
          stack: String((e && e.stack) || '').slice(0, 900)
        })
      }).catch(() => {});
    } catch (err) { /* ignore */ }
  });

  async function applyResult(r) {
    state.busy = false;
    if (!r) { state.error = 'Няма връзка с разширението'; render(); return; }
    if (r.connected === false) {
      state.connected = false;
      state.entry = null;
    } else {
      state.connected = true;
      if (!r.offline) {
        state.entry = r.entry || null;
        if (r.todaySeconds !== null && r.todaySeconds !== undefined) {
          state.todaySeconds = r.todaySeconds;
          todayFetchedAt = Date.now();
        }
      }
      state.error = r.error || '';
    }
    render();
  }

  async function refresh() {
    bg(applyResult(await send({ type: 'pt-time', action: 'status' })));
    bg(loadActive());
  }

  /* Кой работи по задачата на екрана — включително аз, ако съм пуснал таймер.
     По една задача може да работят няколко души едновременно. */
  async function loadActive() {
    if (!pageTask()) return;
    const r = await send({ type: 'pt-time', action: 'active' });
    if (!r || r.connected === false || !r.active) return;
    state.active = r.active;
    render();
  }

  /* ---------- бутон „✓ Готово" ----------
     Живее в СЪЩОТО прозорче като таймера (Венци, 15.09.2026: "иска ми се да
     бъде при бутона за таймера, защото стават много бутони на екрана") —
     отделно от таймера откъм смисъл (не мери време, само пази кой САМ е казал
     „аз я направих"), но не и откъм UI. Статусът се зарежда веднъж на смяна
     на картата (doneRid), не на всеки такт — само клик от самия човек го
     променя. */
  let doneRid = '';

  async function loadDone(task) {
    const r = await send({ type: 'pt-done', action: 'status', bc_card_id: task.rid });
    if (!r || r.connected === false) return;
    state.done = !!r.done;
    render();
  }

  async function doToggleDone() {
    const task = pageTask();
    if (!task || state.busy) return;
    state.busy = true;
    render();
    const r = await send({
      type: 'pt-done', action: 'toggle',
      bc_project_id: task.bucket, bc_card_id: task.rid,
      title: taskTitle(), url: location.href.split('#')[0]
    });
    state.busy = false;
    if (r && r.connected !== false && typeof r.done === 'boolean') state.done = r.done;
    render();
  }

  function peersFor(task) {
    if (!task || !Array.isArray(state.active)) return [];
    const meId = state.entry ? state.entry.userId : null;
    return state.active
      .filter((e) => e.bcRecordingId && String(e.bcRecordingId) === String(task.rid))
      .map((e) => ({
        name: e.userName || 'Някой',
        startedAt: e.startedAt,
        isMe: meId != null && e.userId === meId
      }));
  }

  function sinceSeconds(startedAt) {
    return Math.max(0, (Date.now() - new Date(startedAt).getTime()) / 1000);
  }

  async function doStart() {
    const task = pageTask();
    if (!task || state.busy) return;
    state.busy = true;
    render();
    applyResult(await send({
      type: 'pt-time',
      action: 'start',
      task: {
        bc_recording_id: task.rid,
        bc_project_id: task.bucket,
        recording_type: task.type,
        title: taskTitle(),
        url: location.href.split('#')[0]
      }
    }));
    bg(loadActive()); // списъкът „кой работи" да ме покаже веднага
  }

  async function doStop(reason) {
    if (state.busy) return;
    state.busy = true;
    render();
    bg(applyResult(await send({ type: 'pt-time', action: 'stop', reason })));
    bg(loadActive());
  }

  async function doConnect(btn) {
    if (state.busy) return;
    state.busy = true;
    if (btn) btn.textContent = 'Свързвам…';
    const r = await send({ type: 'pt-time', action: 'connect' });
    state.busy = false;
    if (r && r.ok) {
      state.connected = true;
      bg(refresh());
      return;
    }
    state.connected = false;
    state.error = 'Първо влез в thepact.pro, после цъкни пак „Свържи".';
    try { window.open(PLATFORM_URL, '_blank'); } catch (e) { /* ignore */ }
    render();
  }

  /* ---------- UI ---------- */

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function button(cls, label, title, onClick) {
    const b = el('button', 'pt-time__btn ' + cls, label);
    b.type = 'button';
    if (title) b.title = title;
    b.addEventListener('click', onClick);
    b.disabled = !!state.busy;
    return b;
  }

  function panel() {
    return PT.sub('pt-time', 'pt-time');
  }

  function setCollapsed(v) {
    collapsed = v;
    savePrefs();
    render();
  }

  /* ---------- къде стои прозорчето ---------- */

  const POS_CLASSES = PRESET_ORDER.map((p) => 'pt-time--' + p).concat('pt-time--free');

  function posLabel() {
    return pos.mode === 'free' ? 'свободно' : (PRESETS[pos.preset] || PRESETS.br);
  }

  function applyPos(box) {
    box.classList.remove.apply(box.classList, POS_CLASSES);
    box.style.left = '';
    box.style.top = '';
    if (pos.mode === 'free') {
      /* при по-малък екран свободната позиция може да е останала извън него */
      const x = Math.max(0, Math.min(window.innerWidth - 80, Number(pos.x) || 0));
      const y = Math.max(0, Math.min(window.innerHeight - 40, Number(pos.y) || 0));
      box.classList.add('pt-time--free');
      box.style.left = x + 'px';
      box.style.top = y + 'px';
      return;
    }
    box.classList.add('pt-time--' + (PRESETS[pos.preset] ? pos.preset : 'br'));
  }

  /* Бутонът обикаля предварителните места; влаченето на заглавието дава свободно. */
  function nextPreset() {
    const cur = pos.mode === 'preset' ? PRESET_ORDER.indexOf(pos.preset) : -1;
    pos = Object.assign({}, pos, {
      mode: 'preset',
      preset: PRESET_ORDER[(cur + 1) % PRESET_ORDER.length]
    });
    savePrefs();
    render();
  }

  /* влаченето и клик-ът тръгват от един и същ елемент (плочката), затова пазим
     кога сме пуснали, за да не се разгъне прозорчето веднага след местене */
  let lastDragEnd = 0;

  function enableDrag(box, handle) {
    handle.style.cursor = 'grab';
    handle.addEventListener('mousedown', (e) => {
      if (e.button !== 0 || (e.target.closest && e.target.closest('button'))) return;
      const r = box.getBoundingClientRect();
      const offX = e.clientX - r.left;
      const offY = e.clientY - r.top;
      let moved = false;
      const onMove = (ev) => {
        if (!moved && Math.abs(ev.clientX - e.clientX) < 3 && Math.abs(ev.clientY - e.clientY) < 3) return;
        moved = true;
        pos = { mode: 'free', preset: pos.preset, x: Math.round(ev.clientX - offX), y: Math.round(ev.clientY - offY) };
        applyPos(box);
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        handle.style.cursor = 'grab';
        if (moved) { lastDragEnd = Date.now(); savePrefs(); }
      };
      handle.style.cursor = 'grabbing';
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
      e.preventDefault();
    });
  }

  function render() {
    if (PT.cfg.features.timeTracker === false) return;
    /* осиротял content скрипт (разширението е обновено) — махаме се тихо */
    if (dead) {
      const old = document.getElementById('pt-time');
      if (old) old.remove();
      return;
    }
    const box = panel();
    const task = pageTask();
    const running = state.entry;

    /* статусът на „✓ Готово" е ПО КАРТА — зарежда се наново само когато rid-ът
       се смени, не на всеки render() (render() тръгва много пъти в секунда). */
    if (task && task.rid !== doneRid) {
      doneRid = task.rid;
      state.done = null;
      bg(loadDone(task));
    } else if (!task) {
      doneRid = '';
    }

    /* няма какво да показваме: нито задача на екрана, нито вървящ таймер */
    if (!task && !running) { box.style.display = 'none'; return; }
    if (state.connected === null) { box.style.display = 'none'; return; }
    box.style.display = '';
    box.innerHTML = '';
    applyPos(box);

    /* свит режим — малка плочка с брояча */
    if (collapsed) {
      const pill = el('div', 'pt-time__pill' + (running ? ' pt-time__pill--on' : ''));
      pill.append(el('span', '', running ? '⏱ ' + fmtClock(elapsedSeconds()) : '⏱'));
      pill.title = running ? ('Работиш по: ' + (running.title || 'задача')) : 'Тракване на време';
      pill.addEventListener('click', () => {
        if (Date.now() - lastDragEnd < 250) return; /* току-що я местихме, не разгъвай */
        setCollapsed(false);
      });
      box.append(pill);
      enableDrag(box, pill);
      return;
    }

    const card = el('div', 'pt-time__card');
    const head = el('div', 'pt-time__head');
    head.append(el('span', 'pt-time__brand', '⏱ Време'));
    const hToday = el('span', 'pt-time__today', fmtToday(todayLive()));
    head.append(hToday);
    const posBtn = el('button', 'pt-time__pos', '⤢');
    posBtn.type = 'button';
    posBtn.title = 'Мести прозорчето (сега: ' + posLabel() + ') • или влачи заглавието';
    posBtn.setAttribute('aria-label', posBtn.title);
    posBtn.addEventListener('click', nextPreset);
    head.append(posBtn);
    const min = el('button', 'pt-time__min', '—');
    min.type = 'button';
    min.title = 'Свий';
    min.addEventListener('click', () => setCollapsed(true));
    head.append(min);
    card.append(head);
    enableDrag(box, head);

    if (state.connected === false) {
      card.append(el('div', 'pt-time__hint', 'Свържи разширението с платформата, за да следиш време по задачите.'));
      const cbtn = button('pt-time__btn--start', 'Свържи с платформата', '', (e) => bg(doConnect(e.target)));
      card.append(cbtn);
      if (state.error) card.append(el('div', 'pt-time__err', state.error));
      box.append(card);
      return;
    }

    if (running) {
      const onThis = task && String(running.bcRecordingId) === String(task.rid);
      card.append(el('div', 'pt-time__task', (onThis ? '' : 'Работиш по: ') + (running.title || 'Задача')));
      card.append(el('div', 'pt-time__clock', fmtClock(elapsedSeconds())));
      const row = el('div', 'pt-time__row');
      row.append(button('pt-time__btn--pause', '⏸ Пауза', 'Затваря сегмента; продължаваш със Старт', () => bg(doStop('pause'))));
      row.append(button('pt-time__btn--stop', '⏹ Стоп', 'Приключваш работата по задачата', () => bg(doStop('user'))));
      card.append(row);
      if (task && !onThis) {
        card.append(button('pt-time__btn--switch', '▶ Старт по тази задача', 'Спира текущия таймер и почва тук', () => bg(doStart())));
      }
    } else if (task) {
      card.append(el('div', 'pt-time__task', taskTitle() || 'Задача'));
      card.append(button('pt-time__btn--start', '▶ Старт', 'Почни да отчиташ време по тази задача', () => bg(doStart())));
    }

    /* ✓ Готово — независимо от таймера, показва се щом има карта на екрана и
       статусът вече е прочетен (за да няма кратко премигване в грешно състояние). */
    if (task && state.done !== null) {
      card.append(button('pt-time__btn--done' + (state.done ? ' pt-time__btn--done-on' : ''),
        state.done ? '✓ Готово (ти)' : '✓ Отбележи като готово',
        state.done
          ? 'Ти отбеляза тази задача като готова — цъкни пак, за да махнеш отметката'
          : 'Готов си с тази задача — цъкни, за да се преброи на теб в отчета',
        () => bg(doToggleDone())));
    }

    /* „Кой работи по това" — имената и таймерите на всички по текущата задача.
       Показва се и когато аз не съм пуснал таймер: така се вижда, че някой вече
       е захванал проекта, и мога да се включа към него със Старт. */
    const peers = peersFor(task);
    if (peers.length) {
      const who = el('div', 'pt-time__who');
      who.append(el('div', 'pt-time__who-head',
        peers.length === 1 ? 'Работи по това:' : 'Работят по това (' + peers.length + '):'));
      peers.forEach((p) => {
        const row = el('div', 'pt-time__who-row');
        row.append(el('span', 'pt-time__who-name', p.name + (p.isMe ? ' (ти)' : '')));
        const c = el('span', 'pt-time__who-clock', fmtClock(sinceSeconds(p.startedAt)));
        c.dataset.since = p.startedAt;
        row.append(c);
        who.append(row);
      });
      card.append(who);
    }

    /* ＋ Добави време — за забравен Старт и за отчитане след снимки */
    if (task) {
      if (!adding) {
        card.append(button('pt-time__btn--add', '＋ Добави време',
          'Забравил си Старт? Въведи колко време ти е отнело',
          () => { adding = true; addError = ''; render(); }));
      } else {
        const form = el('div', 'pt-time__add');
        const inp = el('input', 'pt-time__in');
        inp.type = 'text';
        inp.placeholder = '90, 1:30 или 2ч';
        inp.value = addRaw;
        inp.setAttribute('aria-label', 'Колко време ти отне');
        inp.addEventListener('input', () => { addRaw = inp.value; });

        const note = el('input', 'pt-time__in pt-time__in--note');
        note.type = 'text';
        note.placeholder = 'бележка (по желание)';
        note.value = addNote;
        note.setAttribute('aria-label', 'Бележка');
        note.addEventListener('input', () => { addNote = note.value; });

        const save = () => bg(doAdd(inp.value, note.value));
        [inp, note].forEach((f) => f.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') save();
          if (e.key === 'Escape') { adding = false; addError = ''; render(); }
        }));

        const row = el('div', 'pt-time__row');
        row.append(button('pt-time__btn--start', state.busy ? 'Добавям…' : 'Запази', '', save));
        row.append(button('pt-time__btn--cancel', 'Откажи', '',
          () => { adding = false; addError = ''; render(); }));

        form.append(inp, note, row);
        form.append(el('div', 'pt-time__hint', 'Отчита се към сега, по тази задача.'));
        card.append(form);
        setTimeout(() => { try { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); } catch (e) { /* ignore */ } }, 0);
      }
      if (addError) card.append(el('div', 'pt-time__err', addError));
      if (addedNote) card.append(el('div', 'pt-time__added', '✓ ' + addedNote));
    }

    if (state.error) card.append(el('div', 'pt-time__err', state.error));
    box.append(card);
  }

  /* тик: веднъж в секунда опресняваме броячите, без да престрояваме DOM-а */
  setInterval(() => {
    if (document.visibilityState !== 'visible') return;
    const box = document.getElementById('pt-time');
    if (!box || box.style.display === 'none') return;
    /* таймерите на другите вървят и когато аз не отчитам време */
    box.querySelectorAll('.pt-time__who-clock').forEach((c) => {
      if (c.dataset.since) c.textContent = fmtClock(sinceSeconds(c.dataset.since));
    });
    if (!state.entry) return;
    const clock = box.querySelector('.pt-time__clock');
    if (clock) clock.textContent = fmtClock(elapsedSeconds());
    const pill = box.querySelector('.pt-time__pill--on span');
    if (pill) pill.textContent = '⏱ ' + fmtClock(elapsedSeconds());
    const today = box.querySelector('.pt-time__today');
    if (today) today.textContent = fmtToday(todayLive());
  }, 1000);

  /* периодично догонване със сървъра (спрян от друго устройство, sweeper и т.н.) */
  setInterval(() => {
    if (document.visibilityState === 'visible') bg(refresh());
  }, 45000);

  /* ---------- старт ---------- */

  /* Докато този таб е отворен, каналът към service worker-а стои. Пада ли —
     значи табът е затворен (или работникът е заспал и се вдига наново, затова
     веднага се свързваме пак). Това е единственият надежден признак „има ли
     отворен Basecamp": chrome.tabs.query иска права над basecamp.com, каквито
     разширението няма, и мълчаливо връщаше празно. */
  let alivePort = null;
  function keepAlive() {
    if (dead || alivePort) return;
    if (orphaned()) { dead = true; return; }
    try {
      alivePort = chrome.runtime.connect({ name: 'pt-alive' });
      alivePort.onDisconnect.addListener(() => {
        void chrome.runtime.lastError;
        alivePort = null;
        /* Работникът се приспива редовно — това е нормално, а не край. Свързваме
           се пак (самото свързване го буди); отказваме се само ако разширението
           наистина го няма. */
        if (!dead) setTimeout(keepAlive, 1500);
      });
    } catch (e) {
      if (orphaned()) dead = true;
      else setTimeout(keepAlive, 3000);   /* временно — пробваме пак */
    }
  }

  Promise.all([PT.ready, prefsReady]).then(() => {
    if (PT.cfg.features.timeTracker === false) return;

    keepAlive();
    if (PT.onOrphan) {
      PT.onOrphan(() => {
        dead = true;
        try { if (alivePort) alivePort.disconnect(); } catch (e) { /* ignore */ }
        alivePort = null;
      });
    }

    let lastPath = '';
    const onChange = () => {
      if (location.pathname === lastPath) return;
      lastPath = location.pathname;
      render();
    };
    PT.onNav(() => { lastPath = ''; onChange(); bg(refresh()); });
    PT.onDomChange(onChange);
    PT.onVisibility((visible) => { if (visible) bg(refresh()); });

    bg(refresh());
  }).catch((e) => {
    try { console.debug('[The Pact Tools] стартът на таймера пропадна:', e); } catch (err) { /* ignore */ }
  });
})();
