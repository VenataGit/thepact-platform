/* The Pact Tools — функция „Кой редактира в момента“.
 * Предупреждава, когато двама души редактират една и съща задача в Basecamp.
 * Комуникацията върви през общия Firebase канал — REST + Server-Sent Events, без SDK. */
(() => {
  'use strict';
  const PT = window.__PT;
  if (!PT || PT.__lockLoaded) return;
  PT.__lockLoaded = true;

  const TTL_MS = 150000;      /* запис без "пулс" от 2,5 мин се смята за изтекъл */
  const HEARTBEAT_MS = 25000;

  const clamp80 = (s) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 80);

  /* ---------- какво точно се редактира ---------- */

  const TYPE_LABELS = {
    todos: 'задачата',
    messages: 'съобщението',
    documents: 'документа',
    comments: 'коментара',
    cards: 'картата',
    questions: 'въпроса',
    question_answers: 'отговора',
    schedule_entries: 'събитието',
    uploads: 'файла'
  };
  const typeLabel = (type) => TYPE_LABELS[type] || 'същото нещо';

  function parseRecordingUrl(url) {
    try {
      const p = new URL(url || '', location.origin).pathname;
      const m = p.match(/\/buckets\/(\d+)\/((?:[a-z_]+\/)*[a-z_]+)\/(\d+)$/);
      if (!m) return null;
      const segs = m[2].split('/');
      return { bucket: m[1], type: segs[segs.length - 1], typePath: m[2], rid: m[3] };
    } catch (e) {
      return null;
    }
  }

  /* Едит режим = (а) URL, завършващ на /edit, или (б) форма с _method=patch/put
     към адрес на recording, съдържаща текстов редактор. */
  function findEditTargets() {
    const map = new Map();
    const um = location.pathname.match(/\/buckets\/(\d+)\/((?:[a-z_]+\/)*[a-z_]+)\/(\d+)\/edit$/);
    if (um) {
      const segs = um[2].split('/');
      map.set(um[3], { bucket: um[1], type: segs[segs.length - 1], typePath: um[2], rid: um[3] });
    }
    document.querySelectorAll('form[action*="/buckets/"]').forEach((f) => {
      const method = f.querySelector('input[name="_method"]');
      const mv = method ? String(method.value || '').toLowerCase() : '';
      if (mv !== 'patch' && mv !== 'put') return;
      if (!f.querySelector('trix-editor, textarea, input[type="text"]')) return;
      const info = parseRecordingUrl(f.getAttribute('action'));
      if (info) map.set(info.rid, info);
    });
    return map;
  }

  function guessTitle(rid) {
    for (const f of document.querySelectorAll('form[action*="/buckets/"]')) {
      const info = parseRecordingUrl(f.getAttribute('action'));
      if (!info || info.rid !== rid) continue;
      const inp = f.querySelector('input[name$="[content]"], input[name$="[title]"], input[type="text"]');
      if (inp && inp.value && inp.value.trim()) return clamp80(inp.value);
    }
    const h1 = document.querySelector('h1');
    return h1 ? clamp80(h1.textContent) : '';
  }

  /* ---------- моите активни редакции (запис в канала) ---------- */

  const active = new Map(); /* rid -> { info, timer, url } */

  function nodeUrl(acct, rid) {
    return PT.dbRoot + '/' + acct + '/' + encodeURIComponent(rid) + '/' + encodeURIComponent(PT.personKey) + '.json';
  }

  function startSession(info) {
    const acct = PT.accountId();
    if (!acct) return;
    const url = nodeUrl(acct, info.rid);
    const write = (body, method) => {
      try {
        fetch(url + '?print=silent', { method: method || 'PUT', body: JSON.stringify(body) }).catch(() => {});
      } catch (e) { /* ignore */ }
    };
    write({
      name: PT.myName(),
      pid: PT.pid || '',
      type: info.type,
      title: guessTitle(info.rid),
      url: location.href,
      started: Date.now(),
      beat: Date.now()
    });
    const timer = setInterval(() => {
      write({ beat: Date.now(), name: PT.myName(), pid: PT.pid || '' }, 'PATCH');
    }, HEARTBEAT_MS);
    active.set(info.rid, { info, timer, url, write });
    refreshState();
  }

  /* разпознаването на профила може да закъснее с няколко секунди — щом дойде,
     веднага обновяваме името в отворените вече записи */
  function republishName() {
    active.forEach((s) => {
      s.write({ name: PT.myName(), pid: PT.pid || '', beat: Date.now() }, 'PATCH');
    });
  }

  function stopSession(rid, keepalive) {
    const s = active.get(rid);
    if (!s) return;
    clearInterval(s.timer);
    active.delete(rid);
    try {
      fetch(s.url, { method: 'DELETE', keepalive: !!keepalive }).catch(() => {});
    } catch (e) { /* ignore */ }
  }

  function checkEditState() {
    const targets = findEditTargets();
    for (const rid of [...active.keys()]) {
      if (!targets.has(rid)) stopSession(rid);
    }
    targets.forEach((info, rid) => {
      if (!active.has(rid)) startSession(info);
    });
    renderAll();
  }

  /* ---------- защита от презаписване (работи и без общия канал) ----------
     Докато твоята edit форма е отворена, периодично взимаме edit формата от
     сървъра и сравняваме попълнените ѝ стойности. Разлика = някой е запазил
     промяна междувременно (дори колега БЕЗ разширението). */

  const guards = new Map(); /* rid -> { info, baseline, timer, warned } */

  function formFingerprint(doc, info) {
    let out = null;
    doc.querySelectorAll('form[action*="/buckets/"]').forEach((f) => {
      if (out !== null) return;
      const fi = parseRecordingUrl(f.getAttribute('action'));
      if (!fi || fi.rid !== info.rid) return;
      const parts = [];
      f.querySelectorAll('input, textarea').forEach((el) => {
        const n = (el.getAttribute('name') || '').toLowerCase();
        if (!n || n === '_method' || n === 'utf8' || n.indexOf('authenticity_token') >= 0) return;
        parts.push(n + '=' + String(el.value !== undefined ? el.value : (el.textContent || '')));
      });
      if (parts.length) out = parts.join('&');
    });
    return out;
  }

  async function fetchFingerprint(info) {
    try {
      const path = '/buckets/' + info.bucket + '/' + (info.typePath || info.type) + '/' + info.rid + '/edit';
      const res = await fetch(path, { credentials: 'same-origin' });
      if (!res.ok) return null;
      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      return formFingerprint(doc, info);
    } catch (e) {
      return null;
    }
  }

  function startGuard(info) {
    const g = { info, baseline: null, timer: null, warned: false };
    guards.set(info.rid, g);
    fetchFingerprint(info).then((fp) => {
      if (!guards.has(info.rid)) return;
      g.baseline = fp;
      if (fp === null) return; /* този тип няма самостоятелна /edit страница */
      g.timer = setInterval(() => {
        if (document.visibilityState !== 'visible' || g.warned) return;
        fetchFingerprint(info).then((cur) => {
          if (!guards.has(info.rid) || g.warned || cur === null || g.baseline === null) return;
          if (cur !== g.baseline) {
            g.warned = true;
            PT.upsertBanner(
              'g' + info.rid,
              'red',
              '⚠️ Междувременно някой запази промяна по ' + typeLabel(info.type) +
                ', докато редактираш! Ако сега запазиш, ще презапишеш неговата версия. ' +
                'Отвори елемента в нов таб, за да видиш новото, преди да запазиш.'
            );
            PT.notify(
              'Риск от презаписване',
              'Някой запази промяна по ' + typeLabel(info.type) + ', докато я редактираш. Виж новото, преди да запазиш.'
            );
          }
        });
      }, 40000);
    });
  }

  function stopGuard(rid) {
    const g = guards.get(rid);
    if (!g) return;
    if (g.timer) clearInterval(g.timer);
    guards.delete(rid);
    PT.dropBanner('g' + rid);
  }

  function guardCheckState() {
    const targets = findEditTargets();
    for (const rid of [...guards.keys()]) {
      if (!targets.has(rid)) stopGuard(rid);
    }
    targets.forEach((info, rid) => {
      if (!guards.has(rid)) startGuard(info);
    });
  }

  /* ---------- чуждото присъствие (четене от канала) ---------- */

  let state = {}; /* rid -> personKey -> record */
  let es = null;
  let esAcct = '';
  let retryTimer = null;

  function applyPut(path, data) {
    const segs = String(path || '').split('/').filter(Boolean);
    if (!segs.length) {
      state = (data && typeof data === 'object') ? data : {};
      return;
    }
    let node = state;
    for (let i = 0; i < segs.length - 1; i++) {
      if (typeof node[segs[i]] !== 'object' || node[segs[i]] === null) node[segs[i]] = {};
      node = node[segs[i]];
    }
    const last = segs[segs.length - 1];
    if (data === null || data === undefined) delete node[last];
    else node[last] = data;
  }

  function applyPatch(path, data) {
    if (!data || typeof data !== 'object') return;
    const base = String(path || '').replace(/\/$/, '');
    for (const k of Object.keys(data)) applyPut(base + '/' + k, data[k]);
  }

  function ensureStream() {
    const acct = PT.accountId();
    if (!acct || document.visibilityState !== 'visible') return;
    if (es && esAcct === acct) return;
    closeStream();
    esAcct = acct;
    try {
      es = new EventSource(PT.dbRoot + '/' + acct + '.json');
    } catch (e) {
      es = null;
      esAcct = '';
      return;
    }
    const restart = () => {
      closeStream();
      if (!retryTimer) {
        retryTimer = setTimeout(() => { retryTimer = null; ensureStream(); }, 8000);
      }
    };
    es.addEventListener('put', (e) => {
      try { const m = JSON.parse(e.data); applyPut(m.path, m.data); renderAll(); } catch (err) { /* ignore */ }
    });
    es.addEventListener('patch', (e) => {
      try { const m = JSON.parse(e.data); applyPatch(m.path, m.data); renderAll(); } catch (err) { /* ignore */ }
    });
    es.addEventListener('cancel', restart);
    es.addEventListener('auth_revoked', restart);
    es.onerror = () => { if (es && es.readyState === 2) restart(); };
  }

  function closeStream() {
    if (es) {
      try { es.close(); } catch (e) { /* ignore */ }
      es = null;
      esAcct = '';
    }
  }

  function refreshState() {
    const acct = PT.accountId();
    if (!acct) return;
    fetch(PT.dbRoot + '/' + acct + '.json')
      .then((r) => (r.ok ? r.text() : undefined))
      .then((txt) => {
        if (txt === undefined) return;
        try {
          const data = JSON.parse(txt);
          state = (data && typeof data === 'object') ? data : {};
          renderAll();
        } catch (e) { /* ignore */ }
      })
      .catch(() => {});
  }

  function freshOthers(rid) {
    const people = state && state[rid];
    if (!people || typeof people !== 'object') return [];
    const now = Date.now();
    const out = [];
    for (const pk of Object.keys(people)) {
      if (PT.isMe(pk)) continue;
      const rec = people[pk];
      if (!rec || typeof rec !== 'object') continue;
      /* същият човек от друг браузър/устройство — не съм си „колега“ */
      if (PT.isMyPid(rec.pid)) continue;
      const seen = Math.max(Number(rec.beat) || 0, Number(rec.started) || 0);
      if (seen && now - seen <= TTL_MS) out.push(Object.assign({ _pk: pk }, rec));
    }
    return out;
  }

  /* ---------- показване ---------- */

  function pageRid() {
    const m = location.pathname.match(/\/buckets\/(\d+)\/((?:[a-z_]+\/)*[a-z_]+)\/(\d+)(?:\/edit)?$/);
    return m ? m[3] : '';
  }

  const dismissed = new Set();
  const notifiedJoin = new Set();

  function bannerText(kind, recs) {
    const names = recs.map((r) => String(r.name || 'Колега')).join(' и ');
    const many = recs.length > 1;
    const first = recs[0] || {};
    const when = (Number(first.started) || Number(first.beat))
      ? new Date(Number(first.started) || Number(first.beat)).toLocaleTimeString('bg-BG', { hour: '2-digit', minute: '2-digit' })
      : '';
    const what = typeLabel(first.type);
    const title = first.title ? ' („' + String(first.title) + '“)' : '';
    if (kind === 'edit') {
      return '⚠️ ' + names + (many ? ' също редактират ' : ' в момента също редактира ') + what + title +
        (when ? ' — от ' + when + ' ч.' : '') + '. Ако запазиш, може да презапишете промените си!';
    }
    return '🔒 ' + names + (many ? ' редактират ' : ' в момента редактира ') + what + title +
      (when ? ' — от ' + when + ' ч.' : '') + '.';
  }

  function renderBanners() {
    const wanted = new Map(); /* bid -> { kind, recs, edit } */
    for (const rid of active.keys()) {
      const others = freshOthers(rid);
      if (others.length) wanted.set('e' + rid, { kind: 'red', recs: others, edit: true });
    }
    const pr = pageRid();
    if (pr && !active.has(pr)) {
      const others = freshOthers(pr);
      if (others.length) wanted.set('v' + pr, { kind: 'amber', recs: others, edit: false });
    }
    /* чистим само нашите банери (e…/v…) — банерът за нова версия е на ядрото */
    PT.eachBanner((b) => {
      const bid = b.getAttribute('data-bid') || '';
      if (/^[ev]\d+$/.test(bid) && !wanted.has(bid)) b.remove();
    });
    wanted.forEach((w, bid) => {
      /* системно известие при нов "съквартирант" в нещо, което редактирам */
      if (w.edit) {
        for (const rec of w.recs) {
          const nk = bid + '|' + (rec._pk || rec.name || '');
          if (!notifiedJoin.has(nk)) {
            notifiedJoin.add(nk);
            PT.notify(
              'Едновременна редакция',
              (rec.name || 'Колега') + ' също редактира ' + typeLabel(rec.type) +
                (rec.title ? ' — „' + rec.title + '“' : '') + '.'
            );
          }
        }
      }
      const key = bid + '|' + w.recs.map((r) => r.name).join(',');
      if (dismissed.has(key)) return;
      PT.upsertBanner(bid, w.kind, bannerText(w.edit ? 'edit' : 'view', w.recs), () => dismissed.add(key));
    });
  }

  function renderChips() {
    document.querySelectorAll('.bcedit-chip').forEach((c) => {
      const rid = c.getAttribute('data-rid');
      if (!rid || !freshOthers(rid).length) c.remove();
    });
    if (!state || typeof state !== 'object') return;
    for (const rid of Object.keys(state)) {
      const others = freshOthers(rid);
      if (!others.length) continue;
      const host = document.getElementById('recording_' + rid) ||
        document.getElementById('todo_' + rid) ||
        document.getElementById('message_' + rid) ||
        document.getElementById('document_' + rid) ||
        document.getElementById('card_' + rid);
      if (!host) continue;
      let chip = host.querySelector(':scope > .bcedit-chip');
      if (!chip) {
        chip = document.createElement('span');
        chip.className = 'bcedit-chip';
        chip.setAttribute('data-rid', rid);
        chip.title = 'Редактира се в момента';
        if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
        host.appendChild(chip);
      }
      const label = '🔒 ' + others.map((o) => String(o.name || 'Колега')).join(', ');
      if (chip.textContent !== label) chip.textContent = label;
    }
  }

  function renderAll() {
    renderBanners();
    renderChips();
  }

  /* ---------- старт ---------- */

  PT.ready.then(() => {
    if (PT.cfg.features.editLock === false) return;
    const hasDb = !!PT.dbRoot;
    if (!hasDb) {
      console.info('[The Pact Tools] Няма валиден dbUrl в config.js — работи само локалната защита от презаписване.');
    }

    const onPageChange = () => {
      guardCheckState();
      if (hasDb) { checkEditState(); ensureStream(); }
    };
    PT.onDomChange(onPageChange);
    PT.onNav(onPageChange);

    if (hasDb) {
      PT.onIdentity(() => { republishName(); renderAll(); });

      /* пестим връзки към Firebase: стрийм държи само видимият таб */
      PT.onVisibility((visible) => {
        if (visible) {
          ensureStream();
          refreshState();
        } else {
          closeStream();
        }
      });

      window.addEventListener('pagehide', () => {
        for (const rid of [...active.keys()]) stopSession(rid, true);
      });

      /* периодично препускане, за да гаснат изтекли записи и без събития */
      setInterval(() => {
        if (document.visibilityState === 'visible') renderAll();
      }, 15000);

      PT.resolveIdentity().finally(() => {
        checkEditState();
        ensureStream();
        refreshState();
      });
    }

    guardCheckState();
  });
})();
