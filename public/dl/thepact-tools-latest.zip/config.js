/* The Pact Tools — обща конфигурация на екипа.
 *
 * Име и включени функции могат да се задават и през Options страницата на
 * разширението (chrome://extensions → The Pact Tools → Details → Extension
 * options) — настройките оттам имат предимство пред този файл. */
window.PT_CONFIG = {
  /* Общ Firebase канал на екипа (за "кой редактира" и за известия за нова версия) */
  dbUrl: 'https://thepact-editlock-default-rtdb.europe-west1.firebasedatabase.app',
  teamKey: 'thepact',

  /* Име НЕ е нужно — разпознава се автоматично от логнатия Basecamp профил.
     Попълва се само ако някой иска ръчно да го промени (или през Options). */
  displayName: '',

  /* Кои функции са включени */
  features: {
    pinComments: true,
    editLock: true,
    notify: true,
    templates: true,
    timeTracker: true,
    draftSave: true,
    taskDone: true
  },

  /* Шаблони за коментари — бутонът 📋 до полето за коментар в Basecamp.
     Добавяй свои: { title: 'Име в менюто', html: '<strong>…</strong><br><ul><li>…</li></ul>' } */
  templates: [
    {
      title: 'QA чеклист — кратко видео (Reel/TikTok/Short)',
      html: '<strong>QA — кратко видео</strong><br>Хук и структура:<ul>' +
        '<li>Хукът хваща в първите 2 секунди</li>' +
        '<li>Ясна структура (хук → стойност → CTA)</li>' +
        '<li>CTA присъства и е ясен</li></ul>' +
        'Техническо:<ul>' +
        '<li>Правилен формат 9:16 и резолюция</li>' +
        '<li>Звук чист, без клипване, синхрон ОК</li>' +
        '<li>Субтитри/надписи точни и четими</li>' +
        '<li>Експорт по спецификация (битрейт/кодек)</li></ul>' +
        'Бранд и съответствие:<ul>' +
        '<li>Спазва бранд гайда на клиента (цветове, шрифт, лого, тон)</li>' +
        '<li>Правилни @handles / хаштагове</li>' +
        '<li>Съответства на брифа и целта</li>' +
        '<li>Без правни/чувствителни проблеми (музика/права/твърдения)</li></ul>'
    },
    {
      title: 'QA чеклист — статичен пост / карусел',
      html: '<strong>QA — статичен пост / карусел</strong><ul>' +
        '<li>Визуал по бранд гайда</li>' +
        '<li>Текст без грешки, тон по бранда</li>' +
        '<li>CTA / линк правилен</li>' +
        '<li>Правилен размер за платформата</li></ul>'
    },
    {
      title: 'Ревизия — какво да се поправи',
      html: '<strong>Ревизия</strong><ol>' +
        '<li>&nbsp;</li><li>&nbsp;</li><li>&nbsp;</li></ol>' +
        '<strong>Дедлайн за поправките:</strong> …<br><strong>Приоритет:</strong> …'
    }
  ]
};
