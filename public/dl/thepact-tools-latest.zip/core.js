/* The Pact Tools — ядро: обща инфраструктура за всички функции.
 * Тук живеят: конфигурация, слоят върху страницата, общият наблюдател на DOM-а,
 * идентичността на потребителя, банерите и проверката за нова версия. */
(() => {
  'use strict';
  if (window.__PT) return;

  const MF = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest)
    ? chrome.runtime.getManifest()
    : null;
  const fileCfg = window.PT_CONFIG || {};

  const PT = {
    version: MF ? MF.version : '0.0.0',
    cfg: {
      dbUrl: String(fileCfg.dbUrl || '').trim().replace(/\/+$/, ''),
      teamKey: String(fileCfg.teamKey || 'team').trim() || 'team',
      /* displayName = ръчно зададеното име (Options/config.js) — има предимство;
         autoName = разпознатото от Basecamp профила, презаписва се при всяко разпознаване */
      displayName: String(fileCfg.displayName || '').trim(),
      autoName: '',
      templates: Array.isArray(fileCfg.templates) ? fileCfg.templates : [],
      features: Object.assign(
        { pinComments: true, editLock: true, notify: true, templates: true, timeTracker: true },
        fileCfg.features || {}
      )
    },
    dbRoot: ''
  };
  window.__PT = PT;

  if (/^https:\/\/[^/]+\.(firebaseio\.com|firebasedatabase\.app)$/.test(PT.cfg.dbUrl)) {
    PT.dbRoot = PT.cfg.dbUrl + '/edit-presence/' + encodeURIComponent(PT.cfg.teamKey);
  }

  /* ---------- настройки от Options страницата (имат предимство) ---------- */

  PT.ready = new Promise((resolve) => {
    const finish = (st) => {
      st = st || {};
      if (st.displayName && String(st.displayName).trim()) {
        PT.cfg.displayName = String(st.displayName).trim();
      }
      if (st.featPin === false) PT.cfg.features.pinComments = false;
      if (st.featLock === false) PT.cfg.features.editLock = false;
      if (st.featNotify === false) PT.cfg.features.notify = false;
      if (st.featTpl === false) PT.cfg.features.templates = false;
      if (st.featTime === false) PT.cfg.features.timeTracker = false;

      /* автоматична идентичност: кеш от предишно разпознаване.
         Кешове от по-стара версия на разпознаването се игнорират — те може да
         съдържат чуждо име, хванато от произволен аватар в страницата. */
      const cache = meCache();
      const syncOk = Number(st.autoV) === ME_VER;
      PT._forceAt = Number(st.forceRedetect) || 0;
      PT._legacyPk = legacyKey();
      setIdentity(
        cache.pid || (syncOk ? st.autoPid : ''),
        cache.name || (syncOk ? st.autoName : '')
      );
      resolve(PT);
    };
    try {
      chrome.storage.sync.get(
        { displayName: '', featPin: true, featLock: true, featNotify: true, featTpl: true, featTime: true, autoName: '', autoPid: '', autoV: 0, forceRedetect: 0 },
        finish
      );
    } catch (e) {
      setTimeout(() => finish(null), 0);
    }
  });

  /* ---------- общи дреболии ---------- */

  PT.accountId = () => {
    const m = location.pathname.match(/^\/(\d{5,})(\/|$)/);
    return m ? m[1] : '';
  };

  PT.pageBackground = () => {
    for (const el of [document.body, document.documentElement]) {
      if (!el) continue;
      const bg = getComputedStyle(el).backgroundColor;
      if (bg && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)') return bg;
    }
    return '#ffffff';
  };

  /* ---------- слой (под <html>, преживява Turbo навигациите) ---------- */

  const LAYER_ID = 'pt-layer';
  PT.LAYER_ID = LAYER_ID;

  PT.layer = () => {
    let layer = document.getElementById(LAYER_ID);
    if (!layer) {
      layer = document.createElement('div');
      layer.id = LAYER_ID;
      document.documentElement.appendChild(layer);
    }
    return layer;
  };

  PT.sub = (id, cls) => {
    const layer = PT.layer();
    let el = document.getElementById(id);
    if (!el) {
      el = document.createElement('div');
      el.id = id;
      if (cls) el.className = cls;
      layer.appendChild(el);
    }
    return el;
  };

  /* ---------- банери (обща колона горе в центъра) ---------- */

  PT.bannerStack = () => PT.sub('pt-banners', 'pt-stack');

  PT.upsertBanner = (bid, kind, text, onDismiss) => {
    const stack = PT.bannerStack();
    let b = stack.querySelector('.pt-banner[data-bid="' + CSS.escape(bid) + '"]');
    if (!b) {
      b = document.createElement('div');
      b.className = 'pt-banner';
      b.setAttribute('data-bid', bid);
      const t = document.createElement('span');
      t.className = 'pt-btext';
      const x = document.createElement('button');
      x.type = 'button';
      x.className = 'pt-bx';
      x.textContent = '✕';
      x.title = 'Скрий';
      x.addEventListener('click', () => {
        b.remove();
        if (typeof b.__ptOnDismiss === 'function') {
          try { b.__ptOnDismiss(); } catch (e) { /* ignore */ }
        }
      });
      b.append(t, x);
      stack.appendChild(b);
    }
    b.classList.toggle('pt-red', kind === 'red');
    b.classList.toggle('pt-amber', kind === 'amber');
    b.classList.toggle('pt-info', kind === 'info');
    b.__ptOnDismiss = onDismiss || null;
    const t = b.querySelector('.pt-btext');
    if (t.textContent !== text) t.textContent = text;
    return b;
  };

  PT.dropBanner = (bid) => {
    const b = PT.bannerStack().querySelector('.pt-banner[data-bid="' + CSS.escape(bid) + '"]');
    if (b) b.remove();
  };

  PT.eachBanner = (fn) => {
    PT.bannerStack().querySelectorAll('.pt-banner').forEach(fn);
  };

  /* ---------- общ наблюдател на DOM-а + навигации + видимост ---------- */

  const domCbs = [];
  const navCbs = [];
  const visCbs = [];

  PT.onDomChange = (cb) => domCbs.push(cb);
  PT.onNav = (cb) => navCbs.push(cb);
  PT.onVisibility = (cb) => visCbs.push(cb);

  const fire = (list, arg) => {
    for (const cb of list) {
      try { cb(arg); } catch (e) { /* ignore */ }
    }
  };

  let scheduled = false;
  const observer = new MutationObserver((mutations) => {
    let relevant = false;
    for (const m of mutations) {
      const t = m.target;
      if (t && t.nodeType === 1 && t.closest && t.closest('#' + LAYER_ID)) continue;
      relevant = true;
      break;
    }
    if (!relevant || scheduled) return;
    scheduled = true;
    setTimeout(() => { scheduled = false; fire(domCbs); }, 300);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  const fireNav = () => fire(navCbs);
  document.addEventListener('turbo:load', fireNav);
  document.addEventListener('turbo:frame-load', fireNav);
  window.addEventListener('pageshow', fireNav);
  document.addEventListener('visibilitychange', () => {
    fire(visCbs, document.visibilityState === 'visible');
  });

  /* ---------- идентичност (автоматична) ----------
     Кой съм аз се взима САМО от източници, вързани за собствения ми профил:
     глобалите на Basecamp (мостът от MAIN света) → линкът „my profile“ в
     навигацията → заявка към /<акаунт>/my/profile. Никога от произволен аватар
     в страницата — там стоят аватарите на колегите и точно оттам идваше
     сгрешеното име. Ръчното име от Options има предимство пред всичко.
     Ключът "u<personId>" прави един и същ човек разпознаваем от няколко устройства. */

  const ME_KEY = 'bcedit:me';
  const ME_VER = 2; /* вдигни при промяна в разпознаването — старите кешове падат */

  const meCache = () => {
    try {
      const c = JSON.parse(localStorage.getItem(ME_KEY));
      if (c && typeof c === 'object' && Number(c.v) === ME_VER) return c;
    } catch (e) { /* ignore */ }
    return {};
  };

  /* callback-ът се чете нарочно: без него осиротял content скрипт (след
     обновяване на разширението) сипе „Unchecked runtime.lastError" в конзолата
     на Basecamp и вдига техния банер за счупена страница */
  function syncSet(obj) {
    try {
      chrome.storage.sync.set(obj, () => { void chrome.runtime.lastError; });
    } catch (e) { /* ignore */ }
  }

  function saveMe(cache) {
    cache.v = ME_VER;
    try { localStorage.setItem(ME_KEY, JSON.stringify(cache)); } catch (e) { /* ignore */ }
    syncSet({ autoName: cache.name || '', autoPid: cache.pid || '', autoV: ME_VER });
  }

  function legacyKey() {
    try {
      let k = localStorage.getItem('bcedit:pk');
      if (!k) {
        k = 'p' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
        localStorage.setItem('bcedit:pk', k);
      }
      return k;
    } catch (e) {
      return 'p' + Math.random().toString(36).slice(2, 10);
    }
  }

  PT.personKey = '';
  PT._legacyPk = '';
  PT.pid = '';

  const myKeys = new Set();
  const idCbs = [];

  /* известява функциите, че вече знаем (или сме поправили) кой е потребителят */
  PT.onIdentity = (cb) => idCbs.push(cb);

  function setIdentity(pid, name) {
    pid = String(pid || '').replace(/\D/g, '');
    name = cleanName(name);
    let changed = false;
    if (pid && pid !== PT.pid) { PT.pid = pid; changed = true; }
    if (name && name !== PT.cfg.autoName) { PT.cfg.autoName = name; changed = true; }
    PT.personKey = PT.pid ? ('u' + PT.pid) : PT._legacyPk;
    if (PT._legacyPk) myKeys.add(PT._legacyPk);
    if (PT.personKey) myKeys.add(PT.personKey);
    if (changed) fire(idCbs);
  }

  /* „мой ли е този запис“ — по ключ (вкл. стари ключове от същия браузър)
     или по Basecamp person id, който е един и същ на всички устройства */
  PT.isMe = (pk) => !!pk && myKeys.has(pk);
  PT.isMyPid = (pid) => !!pid && !!PT.pid && String(pid).replace(/\D/g, '') === PT.pid;
  PT.myName = () => PT.cfg.displayName || PT.cfg.autoName || 'Колега';

  function cleanName(s) {
    const t = String(s || '').replace(/\s+/g, ' ').trim();
    return (t.length >= 2 && t.length <= 60) ? t : '';
  }

  function pidFromUrl(u) {
    const m = String(u || '').match(/\/people\/(\d+)/);
    return m ? m[1] : '';
  }

  /* Име от текущата страница — само от елемент, вързан за МОЯ профил:
     линка „my profile“ в навигацията или аватар, сочещ моето person id. */
  function scrapeMyNameFromDom(pid) {
    const sels = ['a[href$="/my/profile"] img[alt]', 'a[href*="/my/profile"] img[alt]'];
    const id = String(pid || PT.pid || '').replace(/\D/g, '');
    if (id) {
      sels.push('a[href*="/people/' + id + '"] img[alt]');
      sels.push('[data-person-id="' + id + '"] img[alt]');
    }
    for (const s of sels) {
      try {
        const n = document.querySelector(s);
        const t = n && cleanName(n.getAttribute('alt'));
        if (t) return t;
      } catch (e) { /* ignore */ }
    }
    return '';
  }

  /* Профилът на логнатия човек — четем /<акаунт>/my/profile и вадим името от
     елемент, за който сме сигурни, че е негов (а не първото <h1> в HTML-а). */
  async function fetchProfile(acct) {
    try {
      const res = await fetch('/' + acct + '/my/profile', { credentials: 'same-origin' });
      if (!res.ok) return null;
      const doc = new DOMParser().parseFromString(await res.text(), 'text/html');

      /* кой е този профил */
      let pid = pidFromUrl(res.url);
      if (!pid) {
        const canon = doc.querySelector('link[rel="canonical"][href], meta[property="og:url"][content]');
        if (canon) pid = pidFromUrl(canon.getAttribute('href') || canon.getAttribute('content'));
      }
      if (!pid) {
        const ref = doc.querySelector('form[action*="/people/"], a[href*="/people/"]');
        if (ref) pid = pidFromUrl(ref.getAttribute('action') || ref.getAttribute('href'));
      }

      /* името, по ред на сигурност */
      let name = '';
      if (pid) {
        const av = doc.querySelector('a[href*="/people/' + pid + '"] img[alt], [data-person-id="' + pid + '"] img[alt]');
        if (av) name = cleanName(av.getAttribute('alt'));
      }
      if (!name) {
        const inp = doc.querySelector('input[name="person[name]"][value], input[name$="[name]"][value]');
        if (inp) name = cleanName(inp.getAttribute('value'));
      }
      if (!name) {
        const og = doc.querySelector('meta[property="og:title"][content]');
        if (og) name = cleanName(og.getAttribute('content'));
      }
      if (!name) {
        const h1 = doc.querySelector('main h1, #content h1, .content h1, h1');
        if (h1) name = cleanName(h1.textContent);
      }
      if (!name) {
        const t = doc.querySelector('title');
        if (t) name = cleanName(String(t.textContent).split(/\s*(?:•|—|\||·)\s*/)[0]);
      }
      return { name, pid };
    } catch (e) {
      return null;
    }
  }

  let identityRunning = false;
  PT.resolveIdentity = async (force) => {
    if (identityRunning) return;
    identityRunning = true;
    try {
      const acct = PT.accountId();
      if (!acct) return;
      let cache = meCache();
      /* презапознаваме и когато липсва id или име — иначе замръзваме с грешното */
      const fresh = !force && cache.at && cache.acct === acct && cache.pid && cache.name &&
        Number(cache.at) > (PT._forceAt || 0) &&
        (Date.now() - Number(cache.at)) < 7 * 24 * 3600000;
      if (!fresh) {
        const prof = (await fetchProfile(acct)) || {};
        const pid = String(prof.pid || cache.pid || '').replace(/\D/g, '');
        const name = prof.name || scrapeMyNameFromDom(pid) || cache.name || '';
        cache = { name: cleanName(name), pid: pid, acct: acct, at: Date.now() };
        saveMe(cache);
      }
      setIdentity(cache.pid, cache.name);
    } finally {
      identityRunning = false;
    }
  };

  /* MAIN world мостът (inject-main.js) подава текущия човек от глобалите на
     Basecamp. Това е най-сигурният източник — затова презаписва кеша, ако се
     разминава с него (така сгрешено име се поправя само). */
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.type !== 'thepact-tools:person') return;
    const id = String(e.data.id || '').replace(/\D/g, '');
    const name = cleanName(e.data.name);
    if (!id && !name) return;
    const cache = meCache();
    if ((id && id !== cache.pid) || (name && name !== cache.name)) {
      cache.pid = id || cache.pid || '';
      cache.name = name || cache.name || '';
      cache.acct = PT.accountId();
      cache.at = Date.now();
      saveMe(cache);
    }
    setIdentity(id, name);
  });

  /* ---------- системни известия (през background service worker-а) ---------- */

  PT.notify = (title, message) => {
    if (PT.cfg.features.notify === false) return;
    try {
      chrome.runtime.sendMessage({ type: 'pt-notify', title: String(title), message: String(message) });
    } catch (e) { /* ignore */ }
  };

  /* ---------- проверка за нова версия ----------
     При обновяване: вдигаш version в manifest.json и пускаш publish-version.ps1 —
     всички с по-стара версия виждат банер. */

  function isNewer(remote, local) {
    const a = String(remote).split('.').map((n) => parseInt(n, 10) || 0);
    const b = String(local).split('.').map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
      const x = a[i] || 0;
      const y = b[i] || 0;
      if (x !== y) return x > y;
    }
    return false;
  }

  function maybeCheckUpdate() {
    if (!PT.dbRoot || document.visibilityState !== 'visible') return;
    let last = 0;
    try { last = Number(localStorage.getItem('pt:vercheck') || 0); } catch (e) { /* ignore */ }
    if (Date.now() - last < 3600000) return;
    try { localStorage.setItem('pt:vercheck', String(Date.now())); } catch (e) { /* ignore */ }
    fetch(PT.dbRoot + '/meta.json')
      .then((r) => (r.ok ? r.json() : null))
      .then((meta) => {
        if (!meta || !meta.version || !isNewer(meta.version, PT.version)) return;
        try {
          if (localStorage.getItem('pt:verdismiss') === String(meta.version)) return;
        } catch (e) { /* ignore */ }
        const note = meta.note ? ' Какво ново: ' + String(meta.note) : '';
        PT.upsertBanner(
          'update',
          'info',
          '🔄 Излезе нова версия на The Pact Tools (v' + String(meta.version) + ', при теб е v' + PT.version + ').' +
            note + ' Питай Венци за обновения файл.',
          () => {
            try { localStorage.setItem('pt:verdismiss', String(meta.version)); } catch (e) { /* ignore */ }
          }
        );
      })
      .catch(() => {});
  }

  PT.ready.then(() => {
    maybeCheckUpdate();
    setInterval(maybeCheckUpdate, 4 * 3600000);
    PT.onVisibility((visible) => { if (visible) maybeCheckUpdate(); });
  });
})();
