/* The Pact Tools — ядро: обща инфраструктура за всички функции.
 * Тук живеят: конфигурация, слоят върху страницата, общият наблюдател на DOM-а,
 * идентичността на потребителя, банерите и проверката за нова версия. */
(() => {
  'use strict';
  if (window.__PT) return;

  const MF = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest)
    ? chrome.runtime.getManifest()
    : null;
  const fileCfg = window.PT_CONFIG || {};

  const PT = {
    version: MF ? MF.version : '0.0.0',
    cfg: {
      dbUrl: String(fileCfg.dbUrl || '').trim().replace(/\/+$/, ''),
      teamKey: String(fileCfg.teamKey || 'team').trim() || 'team',
      /* displayName = ръчно зададеното име (Options/config.js) — има предимство;
         autoName = разпознатото от Basecamp профила, презаписва се при всяко разпознаване */
      displayName: String(fileCfg.displayName || '').trim(),
      autoName: '',
      templates: Array.isArray(fileCfg.templates) ? fileCfg.templates : [],
      features: Object.assign(
        { pinComments: true, editLock: true, editBar: true, teamNotes: true, notify: true, templates: true, timeTracker: true, draftSave: true },
        fileCfg.features || {}
      )
    },
    dbRoot: ''
  };
  window.__PT = PT;

  if (/^https:\/\/[^/]+\.(firebaseio\.com|firebasedatabase\.app)$/.test(PT.cfg.dbUrl)) {
    PT.dbRoot = PT.cfg.dbUrl + '/edit-presence/' + encodeURIComponent(PT.cfg.teamKey);
  }

  /* ---------- настройки от Options страницата (имат предимство) ---------- */

  PT.ready = new Promise((resolve) => {
    const finish = (st) => {
      // осиротял скрипт: прочитаме грешката, за да не я сипе Chrome в конзолата.
      // В try, защото по този път се минава и когато chrome.runtime вече го няма.
      try { void chrome.runtime.lastError; } catch (e) { /* ignore */ }
      st = st || {};
      if (st.displayName && String(st.displayName).trim()) {
        PT.cfg.displayName = String(st.displayName).trim();
      }
      if (st.featPin === false) PT.cfg.features.pinComments = false;
      if (st.featLock === false) PT.cfg.features.editLock = false;
      if (st.featBar === false) PT.cfg.features.editBar = false;
      if (st.featNotify === false) PT.cfg.features.notify = false;
      if (st.featTpl === false) PT.cfg.features.templates = false;
      if (st.featTime === false) PT.cfg.features.timeTracker = false;
      if (st.featDraft === false) PT.cfg.features.draftSave = false;
      if (st.featNotes === false) PT.cfg.features.teamNotes = false;

      /* автоматична идентичност: кеш от предишно разпознаване.
         Кешове от по-стара версия на разпознаването се игнорират — те може да
         съдържат чуждо име, хванато от произволен аватар в страницата. */
      const cache = meCache();
      const syncOk = Number(st.autoV) === ME_VER;
      PT._forceAt = Number(st.forceRedetect) || 0;
      PT._legacyPk = legacyKey();
      setIdentity(
        cache.pid || (syncOk ? st.autoPid : ''),
        cache.name || (syncOk ? st.autoName : '')
      );
      resolve(PT);
    };
    try {
      chrome.storage.sync.get(
        { displayName: '', featPin: true, featLock: true, featBar: true, featNotify: true, featTpl: true, featTime: true, featDraft: true, featNotes: true, autoName: '', autoPid: '', autoV: 0, forceRedetect: 0 },
        finish
      );
    } catch (e) {
      setTimeout(() => finish(null), 0);
    }
  });

  /* ---------- общи дреболии ---------- */

  /* Номерът на акаунта е в пътя (важи и за „3.", и за „app." домейна). Ако някоя
     страница е с друга подредба, го вадим от кой да е вътрешен линк — иначе
     всичко, което виси на акаунта (присъствие, профил), тихо спира да работи. */
  PT.accountId = () => {
    const m = location.pathname.match(/^\/(\d{5,})(\/|$)/);
    if (m) return m[1];
    try {
      const a = document.querySelector('a[href^="/"][href*="/buckets/"], a[href^="/"][href*="/my/profile"]');
      const am = a && String(a.getAttribute('href') || '').match(/^\/(\d{5,})\//);
      if (am) return am[1];
    } catch (e) { /* ignore */ }
    return '';
  };

  PT.pageBackground = () => {
    for (const el of [document.body, document.documentElement]) {
      if (!el) continue;
      const bg = getComputedStyle(el).backgroundColor;
      if (bg && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)') return bg;
    }
    return '#ffffff';
  };

  /* ---------- слой (под <html>, преживява Turbo навигациите) ---------- */

  const LAYER_ID = 'pt-layer';
  PT.LAYER_ID = LAYER_ID;

  PT.layer = () => {
    let layer = document.getElementById(LAYER_ID);
    if (!layer) {
      layer = document.createElement('div');
      layer.id = LAYER_ID;
      document.documentElement.appendChild(layer);
    }
    return layer;
  };

  PT.sub = (id, cls) => {
    const layer = PT.layer();
    let el = document.getElementById(id);
    if (!el) {
      el = document.createElement('div');
      el.id = id;
      if (cls) el.className = cls;
      layer.appendChild(el);
    }
    return el;
  };

  /* ---------- банери (обща колона горе в центъра) ---------- */

  PT.bannerStack = () => PT.sub('pt-banners', 'pt-stack');

  PT.upsertBanner = (bid, kind, text, onDismiss) => {
    const stack = PT.bannerStack();
    let b = stack.querySelector('.pt-banner[data-bid="' + CSS.escape(bid) + '"]');
    if (!b) {
      b = document.createElement('div');
      b.className = 'pt-banner';
      b.setAttribute('data-bid', bid);
      const t = document.createElement('span');
      t.className = 'pt-btext';
      const x = document.createElement('button');
      x.type = 'button';
      x.className = 'pt-bx';
      x.textContent = '✕';
      x.title = 'Скрий';
      x.addEventListener('click', () => {
        b.remove();
        if (typeof b.__ptOnDismiss === 'function') {
          try { b.__ptOnDismiss(); } catch (e) { /* ignore */ }
        }
      });
      b.append(t, x);
      stack.appendChild(b);
    }
    b.classList.toggle('pt-red', kind === 'red');
    b.classList.toggle('pt-amber', kind === 'amber');
    b.classList.toggle('pt-info', kind === 'info');
    b.__ptOnDismiss = onDismiss || null;
    const t = b.querySelector('.pt-btext');
    if (t.textContent !== text) t.textContent = text;
    return b;
  };

  PT.dropBanner = (bid) => {
    const b = PT.bannerStack().querySelector('.pt-banner[data-bid="' + CSS.escape(bid) + '"]');
    if (b) b.remove();
  };

  PT.eachBanner = (fn) => {
    PT.bannerStack().querySelectorAll('.pt-banner').forEach(fn);
  };

  /* ---------- общ наблюдател на DOM-а + навигации + видимост ---------- */

  const domCbs = [];
  const navCbs = [];
  const visCbs = [];
  const orphanCbs = [];

  PT.onDomChange = (cb) => domCbs.push(cb);
  PT.onNav = (cb) => navCbs.push(cb);
  PT.onVisibility = (cb) => visCbs.push(cb);
  /* извиква се веднъж, когато разширението е обновено/презаредено, а този скрипт
     е останал в страницата — тук всяка функция си прибира нещата */
  PT.onOrphan = (cb) => orphanCbs.push(cb);

  const fire = (list, arg) => {
    for (const cb of list) {
      try { cb(arg); } catch (e) { /* ignore */ }
    }
  };

  /* ---------- безопасен старт на функциите ----------
     Всяка функция тръгва с PT.start(...), а не с PT.ready.then(...). Разликата е
     в липсващия catch: гръмне ли нещо в стартовия код на непозната страница
     (друг Basecamp домейн, страница в грешка, различна подредба на DOM-а),
     остава отхвърлен Promise. Той изтича като грешка в конзолата на Basecamp,
     а техният монитор вдига банера „Basecamp isn't fully functional right now.".
     console.debug не е грешка и не задейства банера. */

  PT.start = (fn) => PT.ready.then(fn).catch((e) => {
    try { console.debug('[The Pact Tools] стартът пропадна:', e); } catch (err) { /* ignore */ }
  });

  /* същото за периодични и еднократни задачи, които не са вързани за Promise */
  PT.safe = (fn) => function () {
    try { return fn.apply(this, arguments); } catch (e) {
      try { console.debug('[The Pact Tools]', e); } catch (err) { /* ignore */ }
      return undefined;
    }
  };

  let scheduled = false;
  const observer = new MutationObserver((mutations) => {
    let relevant = false;
    for (const m of mutations) {
      const t = m.target;
      if (t && t.nodeType === 1 && t.closest && t.closest('#' + LAYER_ID)) continue;
      relevant = true;
      break;
    }
    if (!relevant || scheduled) return;
    scheduled = true;
    setTimeout(() => { scheduled = false; fire(domCbs); }, 300);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  /* ---------- кой вдига банера „Basecamp isn't fully functional right now." ----------
     Банерът е техен и се вдига от техния наблюдател на грешки. За да не се гадае
     чия е грешката, MAIN-world мостът пази последните грешки на страницата, а тук,
     щом банерът се появи, се праща снимка в канала на екипа: текстът и мястото му,
     мястото на нашето прозорче (за да се види дали просто пада върху него) и
     самите грешки с източника им. Праща се само когато банерът наистина го има. */

  const BANNER_TEXT = 'fully functional';

  PT.pageErrors = () => new Promise((resolve) => {
    let done = false;
    const onMsg = (e) => {
      if (e.source !== window || !e.data || e.data.type !== 'thepact-tools:errors!') return;
      done = true;
      window.removeEventListener('message', onMsg);
      resolve(Array.isArray(e.data.list) ? e.data.list : []);
    };
    window.addEventListener('message', onMsg);
    try { window.postMessage({ type: 'thepact-tools:errors?' }, location.origin); } catch (e) { /* ignore */ }
    setTimeout(() => {
      if (done) return;
      window.removeEventListener('message', onMsg);
      resolve([]);
    }, 700);
  });

  function findBannerNode() {
    try {
      const res = document.evaluate(
        "//*[contains(translate(text(),'ISNTFULYCA','isntfulyca'),'" + BANNER_TEXT + "')]",
        document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
      );
      return res && res.singleNodeValue ? res.singleNodeValue : null;
    } catch (e) {
      return null;
    }
  }

  const nodeInfo = (el) => {
    if (!el) return '(няма)';
    let s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    const cls = (el.getAttribute('class') || '').trim().split(/\s+/).filter(Boolean).slice(0, 3);
    if (cls.length) s += '.' + cls.join('.');
    const r = el.getBoundingClientRect();
    return s + ' [' + Math.round(r.left) + ',' + Math.round(r.top) + ' ' +
      Math.round(r.width) + 'x' + Math.round(r.height) + ']';
  };

  let lastBannerAt = 0;
  async function watchBanner() {
    if (!PT.dbRoot || document.visibilityState !== 'visible') return;
    const node = findBannerNode();
    if (!node) return;
    if (Date.now() - lastBannerAt < 60000) return;
    lastBannerAt = Date.now();

    const widget = document.getElementById('pt-time');
    const errors = await PT.pageErrors();
    const body = {
      at: Date.now(),
      who: PT.myName(),
      ver: PT.version,
      host: location.host,
      page: location.pathname,
      banner: nodeInfo(node),
      bannerText: String(node.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 200),
      bannerParent: nodeInfo(node.parentElement),
      inOurWidget: !!(widget && widget.contains(node)),
      widget: widget ? nodeInfo(widget) : '(няма прозорче)',
      layerAlive: !!document.getElementById(LAYER_ID),
      errors: errors
    };
    try {
      fetch(PT.dbRoot + '/banner-diag/' + encodeURIComponent(PT.personKey || 'anon') + '.json',
        { method: 'PUT', body: JSON.stringify(body) }).catch(() => {});
    } catch (e) { /* ignore */ }
  }

  /* ---------- осиротял скрипт: разкарваме се тихо ----------
     След обновяване/презареждане на разширението старите content скриптове
     остават в отворената страница, но chrome.runtime е мъртъв за тях. Всяко
     следващо извикване сипе грешка в конзолата на страницата и Basecamp вдига
     банера „Basecamp isn't fully functional right now.". Проверката по-долу не
     вика нищо през chrome — само гледа дали го има — и при мъртъв контекст
     прибира всичко: слоя, наблюдателя и каквото функциите са закачили. */

  PT.alive = () => {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  };

  let orphaned = false;
  const sweepIfOrphaned = () => {
    if (orphaned || PT.alive()) return;
    orphaned = true;
    fire(orphanCbs);
    try { observer.disconnect(); } catch (e) { /* ignore */ }
    domCbs.length = 0;
    navCbs.length = 0;
    visCbs.length = 0;
    for (const id of [LAYER_ID, 'pt-pin-live']) {
      const el = document.getElementById(id);
      if (el) el.remove();
    }
  };
  setInterval(sweepIfOrphaned, 20000);
  setInterval(PT.safe(watchBanner), 15000);
  PT.onVisibility((visible) => { if (visible) watchBanner(); });
  document.addEventListener('visibilitychange', sweepIfOrphaned);

  const fireNav = () => { sweepIfOrphaned(); fire(navCbs); };
  document.addEventListener('turbo:load', fireNav);
  document.addEventListener('turbo:frame-load', fireNav);
  window.addEventListener('pageshow', fireNav);
  document.addEventListener('visibilitychange', () => {
    fire(visCbs, document.visibilityState === 'visible');
  });

  /* ---------- идентичност (автоматична) ----------
     Кой съм аз се взима САМО от източници, вързани за собствения ми профил:
     глобалите на Basecamp (мостът от MAIN света) → линкът „my profile“ в
     навигацията → заявка към /<акаунт>/my/profile. Никога от произволен аватар
     в страницата — там стоят аватарите на колегите и точно оттам идваше
     сгрешеното име. Ръчното име от Options има предимство пред всичко.
     Ключът "u<personId>" прави един и същ човек разпознаваем от няколко устройства. */

  const ME_KEY = 'bcedit:me';
  const ME_VER = 2; /* вдигни при промяна в разпознаването — старите кешове падат */

  const meCache = () => {
    try {
      const c = JSON.parse(localStorage.getItem(ME_KEY));
      if (c && typeof c === 'object' && Number(c.v) === ME_VER) return c;
    } catch (e) { /* ignore */ }
    return {};
  };

  /* callback-ът се чете нарочно: без него осиротял content скрипт (след
     обновяване на разширението) сипе „Unchecked runtime.lastError" в конзолата
     на Basecamp и вдига техния банер за счупена страница */
  function syncSet(obj) {
    try {
      chrome.storage.sync.set(obj, () => { void chrome.runtime.lastError; });
    } catch (e) { /* ignore */ }
  }

  function saveMe(cache) {
    cache.v = ME_VER;
    try { localStorage.setItem(ME_KEY, JSON.stringify(cache)); } catch (e) { /* ignore */ }
    syncSet({ autoName: cache.name || '', autoPid: cache.pid || '', autoV: ME_VER });
  }

  function legacyKey() {
    try {
      let k = localStorage.getItem('bcedit:pk');
      if (!k) {
        k = 'p' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
        localStorage.setItem('bcedit:pk', k);
      }
      return k;
    } catch (e) {
      return 'p' + Math.random().toString(36).slice(2, 10);
    }
  }

  PT.personKey = '';
  PT._legacyPk = '';
  PT.pid = '';

  const myKeys = new Set();
  const idCbs = [];

  /* известява функциите, че вече знаем (или сме поправили) кой е потребителят */
  PT.onIdentity = (cb) => idCbs.push(cb);

  function setIdentity(pid, name) {
    pid = String(pid || '').replace(/\D/g, '');
    name = cleanName(name);
    let changed = false;
    if (pid && pid !== PT.pid) { PT.pid = pid; changed = true; }
    if (name && name !== PT.cfg.autoName) { PT.cfg.autoName = name; changed = true; }
    PT.personKey = PT.pid ? ('u' + PT.pid) : PT._legacyPk;
    if (PT._legacyPk) myKeys.add(PT._legacyPk);
    if (PT.personKey) myKeys.add(PT.personKey);
    if (changed) fire(idCbs);
  }

  /* „мой ли е този запис“ — по ключ (вкл. стари ключове от същия браузър)
     или по Basecamp person id, който е един и същ на всички устройства */
  PT.isMe = (pk) => !!pk && myKeys.has(pk);
  PT.isMyPid = (pid) => !!pid && !!PT.pid && String(pid).replace(/\D/g, '') === PT.pid;
  PT.myName = () => PT.cfg.displayName || PT.cfg.autoName || 'Колега';

  function cleanName(s) {
    const t = String(s || '').replace(/\s+/g, ' ').trim();
    return (t.length >= 2 && t.length <= 60) ? t : '';
  }

  function pidFromUrl(u) {
    const m = String(u || '').match(/\/people\/(\d+)/);
    return m ? m[1] : '';
  }

  /* Име от текущата страница — само от елемент, вързан за МОЯ профил:
     линка „my profile“ в навигацията или аватар, сочещ моето person id. */
  function scrapeMyNameFromDom(pid) {
    const sels = ['a[href$="/my/profile"] img[alt]', 'a[href*="/my/profile"] img[alt]'];
    const id = String(pid || PT.pid || '').replace(/\D/g, '');
    if (id) {
      sels.push('a[href*="/people/' + id + '"] img[alt]');
      sels.push('[data-person-id="' + id + '"] img[alt]');
    }
    for (const s of sels) {
      try {
        const n = document.querySelector(s);
        const t = n && cleanName(n.getAttribute('alt'));
        if (t) return t;
      } catch (e) { /* ignore */ }
    }
    return '';
  }

  /* Име на човек по неговото Basecamp id, прочетено от отворената страница.
     Ползва се и за КОЛЕГА: аватарите на автора/изпълнителите/абонатите стоят в
     самата задача, така че дори неговото разширение да не се е разпознало,
     ние можем да покажем кой е. */
  /* ---------- имената от платформата (по-сигурният източник) ----------
     Разпознаването от самия Basecamp се проваля достатъчно често (сменена
     подредба, бавна страница, друг домейн) и тогава в канала „кой редактира"
     отива празно име — насреща виждат „Колега". Платформата знае и мен (моят
     токен е издаден от моята сесия), и целия екип (снапшота на хората), затова
     при неуспех питаме нея. Работи и когато колегата е на по-стара версия:
     неговото Basecamp id винаги пътува в канала. */

  const askWorker = (msg) => new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        void chrome.runtime.lastError;   /* спящ работник е нормално състояние */
        resolve(r || null);
      });
    } catch (e) {
      resolve(null);
    }
  });

  PT.platformIdentity = async () => {
    const r = await askWorker({ type: 'pt-who', action: 'me' });
    const name = cleanName(r && r.name);
    if (!name) return false;
    const pid = String((r && r.basecampUserId) || PT.pid || '').replace(/\D/g, '');
    setIdentity(pid, name);
    if (pid || name) saveMe({ name: name, pid: pid, acct: PT.accountId(), at: Date.now() });
    return true;
  };

  /* Научените имена живеят до презареждане на страницата; празното също се
     помни, за да не се пита за един и същ човек при всяко рисуване. */
  const learnedNames = new Map();

  PT.knownName = (pid) => learnedNames.get(String(pid || '').replace(/\D/g, '')) || '';

  PT.learnNames = async (pids) => {
    const want = [...new Set((pids || [])
      .map((p) => String(p || '').replace(/\D/g, ''))
      .filter(Boolean))]
      .filter((id) => !learnedNames.has(id));
    if (!want.length) return false;
    const r = await askWorker({ type: 'pt-who', action: 'people', ids: want });
    const names = (r && r.names) || {};
    let learned = false;
    for (const id of want) {
      const n = cleanName(names[id]);
      learnedNames.set(id, n);
      if (n) learned = true;
    }
    return learned;
  };

  PT.personName = (pid) => {
    const id = String(pid || '').replace(/\D/g, '');
    if (!id) return '';
    const sels = [
      'a[href*="/people/' + id + '"] img[alt]',
      '[data-person-id="' + id + '"] img[alt]',
      'img[alt][src*="/people/' + id + '/"]'
    ];
    for (const s of sels) {
      try {
        const n = document.querySelector(s);
        const t = n && cleanName(n.getAttribute('alt'));
        if (t) return t;
      } catch (e) { /* ignore */ }
    }
    return '';
  };

  /* името от вече прочетен документ (профилна страница), по ред на сигурност */
  function nameFromDoc(doc, pid) {
    let name = '';
    if (pid) {
      const av = doc.querySelector('a[href*="/people/' + pid + '"] img[alt], [data-person-id="' + pid + '"] img[alt]');
      if (av) name = cleanName(av.getAttribute('alt'));
    }
    if (!name) {
      const inp = doc.querySelector('input[name="person[name]"][value], input[name$="[name]"][value]');
      if (inp) name = cleanName(inp.getAttribute('value'));
    }
    if (!name) {
      const og = doc.querySelector('meta[property="og:title"][content]');
      if (og) name = cleanName(og.getAttribute('content'));
    }
    if (!name) {
      const h1 = doc.querySelector('main h1, #content h1, .content h1, h1');
      if (h1) name = cleanName(h1.textContent);
    }
    if (!name) {
      const t = doc.querySelector('title');
      if (t) name = cleanName(String(t.textContent).split(/\s*(?:•|—|\||·)\s*/)[0]);
    }
    return name;
  }

  async function fetchDoc(path) {
    try {
      const res = await fetch(path, { credentials: 'same-origin' });
      if (!res.ok) return null;
      return { doc: new DOMParser().parseFromString(await res.text(), 'text/html'), url: res.url };
    } catch (e) {
      return null;
    }
  }

  /* Профилът на логнатия човек — четем /<акаунт>/my/profile и вадим името от
     елемент, за който сме сигурни, че е негов (а не първото <h1> в HTML-а). */
  async function fetchProfile(acct) {
    const got = await fetchDoc('/' + acct + '/my/profile');
    if (!got) return null;
    const doc = got.doc;

    /* кой е този профил */
    let pid = pidFromUrl(got.url);
    if (!pid) {
      const canon = doc.querySelector('link[rel="canonical"][href], meta[property="og:url"][content]');
      if (canon) pid = pidFromUrl(canon.getAttribute('href') || canon.getAttribute('content'));
    }
    if (!pid) {
      const ref = doc.querySelector('form[action*="/people/"], a[href*="/people/"]');
      if (ref) pid = pidFromUrl(ref.getAttribute('action') || ref.getAttribute('href'));
    }
    return { name: nameFromDoc(doc, pid), pid };
  }

  /* резервен път: знаем id-то, но не и името — четем самата страница на човека */
  async function fetchPersonName(acct, pid) {
    if (!acct || !pid) return '';
    const got = await fetchDoc('/' + acct + '/people/' + pid);
    if (!got) return '';
    /* тук целият документ е за този човек, затова и общ аватар върши работа */
    const av = got.doc.querySelector('img[alt][src*="avatar"], img[alt][src*="/people/"]');
    return nameFromDoc(got.doc, pid) || (av ? cleanName(av.getAttribute('alt')) : '');
  }

  let identityRunning = false;
  PT.resolveIdentity = async (force) => {
    if (identityRunning) return;
    identityRunning = true;
    try {
      const acct = PT.accountId();
      if (!acct) return;
      let cache = meCache();
      /* презапознаваме и когато липсва id или име — иначе замръзваме с грешното */
      const fresh = !force && cache.at && cache.acct === acct && cache.pid && cache.name &&
        Number(cache.at) > (PT._forceAt || 0) &&
        (Date.now() - Number(cache.at)) < 7 * 24 * 3600000;
      if (!fresh) {
        const prof = (await fetchProfile(acct)) || {};
        const pid = String(prof.pid || cache.pid || '').replace(/\D/g, '');
        let name = cleanName(prof.name || scrapeMyNameFromDom(pid));
        if (!name && pid) name = cleanName(await fetchPersonName(acct, pid));
        if (!name) name = cleanName(cache.name || PT.cfg.autoName);
        /* празен резултат НЕ изтрива вече наученото — иначе една неуспяла
           заявка ни връща на „Колега" за цялата сесия */
        if (name || pid) {
          cache = { name: name, pid: pid, acct: acct, at: Date.now() };
          saveMe(cache);
        }
      }
      setIdentity(cache.pid, cache.name);
    } finally {
      identityRunning = false;
    }
  };

  /* Разпознаването пропада и по причини, които минават: страницата още се
     сглобява, Basecamp е върнал грешка, профилът не се е заредил. Един опит е
     малко — оттам идваше „Колега редактира…". Опитваме няколко пъти с
     нарастваща пауза и спираме в мига, в който имаме име. */
  const ID_RETRIES = 5;
  let idTries = 0;
  let idTimer = null;

  PT.haveName = () => !!(PT.cfg.displayName || PT.cfg.autoName);

  PT.ensureIdentity = () => {
    if (idTimer || PT.cfg.displayName) return;
    const attempt = async () => {
      idTimer = null;
      try { await PT.resolveIdentity(); } catch (e) { /* ignore */ }
      /* Basecamp не даде име → питаме платформата, вместо да оставаме „Колега" */
      if (!PT.haveName() || !PT.pid) {
        try { await PT.platformIdentity(); } catch (e) { /* ignore */ }
      }
      if (PT.haveName() && PT.pid) return;
      if (++idTries > ID_RETRIES) return;
      idTimer = setTimeout(() => { attempt().catch(() => {}); }, 4000 * idTries);
    };
    attempt().catch(() => {});
  };

  /* MAIN world мостът (inject-main.js) подава текущия човек от глобалите на
     Basecamp. Това е най-сигурният източник — затова презаписва кеша, ако се
     разминава с него (така сгрешено име се поправя само). */
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.type !== 'thepact-tools:person') return;
    const id = String(e.data.id || '').replace(/\D/g, '');
    const name = cleanName(e.data.name);
    if (!id && !name) return;
    const cache = meCache();
    if ((id && id !== cache.pid) || (name && name !== cache.name)) {
      cache.pid = id || cache.pid || '';
      cache.name = name || cache.name || '';
      cache.acct = PT.accountId();
      cache.at = Date.now();
      saveMe(cache);
    }
    setIdentity(id, name);
  });

  /* ---------- системни известия (през background service worker-а) ---------- */

  /* Callback-ът НЕ е излишен: без него MV3 връща Promise и при осиротял content
     скрипт (обновено разширение) той се отхвърля с „Extension context invalidated".
     try/catch не хваща отхвърлен Promise → в конзолата на страницата излиза грешка
     и Basecamp вдига банера „Basecamp isn't fully functional right now.".
     С callback грешката минава през lastError и я поглъщаме тихо. */
  PT.notify = (title, message) => {
    if (PT.cfg.features.notify === false) return;
    try {
      chrome.runtime.sendMessage(
        { type: 'pt-notify', title: String(title), message: String(message) },
        () => { void chrome.runtime.lastError; }
      );
    } catch (e) { /* контекстът вече е мъртъв — няма как и няма нужда да известяваме */ }
  };

  /* ---------- проверка за нова версия ----------
     При обновяване: вдигаш version в manifest.json и пускаш publish-version.ps1 —
     всички с по-стара версия виждат банер. */

  function isNewer(remote, local) {
    const a = String(remote).split('.').map((n) => parseInt(n, 10) || 0);
    const b = String(local).split('.').map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
      const x = a[i] || 0;
      const y = b[i] || 0;
      if (x !== y) return x > y;
    }
    return false;
  }

  function maybeCheckUpdate() {
    if (!PT.dbRoot || document.visibilityState !== 'visible') return;
    let last = 0;
    try { last = Number(localStorage.getItem('pt:vercheck') || 0); } catch (e) { /* ignore */ }
    if (Date.now() - last < 3600000) return;
    try { localStorage.setItem('pt:vercheck', String(Date.now())); } catch (e) { /* ignore */ }
    fetch(PT.dbRoot + '/meta.json')
      .then((r) => (r.ok ? r.json() : null))
      .then((meta) => {
        if (!meta || !meta.version || !isNewer(meta.version, PT.version)) return;
        try {
          if (localStorage.getItem('pt:verdismiss') === String(meta.version)) return;
        } catch (e) { /* ignore */ }
        const note = meta.note ? ' Какво ново: ' + String(meta.note) : '';
        PT.upsertBanner(
          'update',
          'info',
          /* Chrome обновява сам — затова тук вече не се иска ръчно действие,
             а се казва къде се чете какво ново има. */
          '🔄 Излезе нова версия на The Pact Tools (v' + String(meta.version) + ', при теб е v' + PT.version + ').' +
            note + ' Chrome ще я вземе сам; какво ново: thepact.pro/extension.html',
          () => {
            try { localStorage.setItem('pt:verdismiss', String(meta.version)); } catch (e) { /* ignore */ }
          }
        );
      })
      .catch(() => {});
  }

  PT.start(() => {
    maybeCheckUpdate();
    setInterval(PT.safe(maybeCheckUpdate), 4 * 3600000);
    PT.onVisibility((visible) => { if (visible) maybeCheckUpdate(); });
  });
})();
